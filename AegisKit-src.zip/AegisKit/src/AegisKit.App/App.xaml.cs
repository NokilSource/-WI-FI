using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using AegisKit.App.Views;
using AegisKit.Core.Logging;

namespace AegisKit.App;

public partial class App : Application
{
    /// <summary>Аргументы командной строки (нужны и после старта — например, для --selftest).</summary>
    public static string[] Args { get; private set; } = Array.Empty<string>();

    /// <summary>
    /// Журнал самопроверки. Пишется в файл сразу, с Flush: приложение — WinExe,
    /// консольного вывода у него нет, и без файла понять причину сбоя невозможно.
    /// </summary>
    private static string SelfTestLog =>
        Path.Combine(Path.GetTempPath(), "aegiskit_selftest.log");

    private static void Trace(string message)
    {
        try
        {
            File.AppendAllText(SelfTestLog, $"{DateTime.Now:HH:mm:ss.fff}  {message}\r\n");
        }
        catch { }
    }

    protected override void OnStartup(StartupEventArgs e)
    {
        Args = e.Args;
        if (e.Args.Contains("--selftest")) Trace("args: " + string.Join(" | ", e.Args));

        if (Core.SystemInfo.IsWinRE)
        {
            // В среде восстановления нет полноценного DWM и аппаратного ускорения:
            // без принудительного программного рендеринга окно остаётся пустым.
            try { RenderOptions.ProcessRenderMode = System.Windows.Interop.RenderMode.SoftwareOnly; }
            catch { }
        }

        // Захват UI-контекста ДО первого сообщения в журнал:
        // все записи из фоновых потоков будут переноситься в UI-поток.
        SimpleLog.CaptureUiContext();

        Trace("calling base.OnStartup");
        try
        {
            base.OnStartup(e);
        }
        catch (Exception ex)
        {
            Trace("base.OnStartup FAILED: " + ex);
            throw;
        }
        Trace("base.OnStartup returned");

        DispatcherUnhandledException += (_, args) =>
        {
            Trace("DispatcherUnhandledException: " + args.Exception);
            SimpleLog.Error($"Необработанная ошибка: {args.Exception.Message}");
            if (e.Args.Contains("--selftest"))
            {
                Environment.ExitCode = 2;
                Shutdown(2);
                args.Handled = true;
                return;
            }
            MessageBox.Show($"{args.Exception.Message}\n\n{args.Exception.StackTrace}",
                "AegisKit — ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            args.Handled = true;
        };

        SimpleLog.Info($"AegisKit {Core.AppInfo.Version} запущен. {Core.SystemInfo.WindowsVersion}");
        if (!Core.SystemInfo.IsElevated)
            SimpleLog.Warn("Запуск без прав администратора — часть функций будет недоступна.");
        if (Core.SystemInfo.IsWinRE)
            SimpleLog.Info("Среда WinRE: доступны офлайн-операции (монтаж кустов внешних систем).");

        // Служебный режим: отрендерить все страницы в PNG и завершиться (для тестов сборки).
        // StartupUri в App.xaml намеренно не задан: раньше попытка обнулить его в этом
        // месте молча падала (setter не принимает null), и самопроверка не выполнялась.
        if (e.Args.Contains("--selftest"))
        {
            RunSelfTest(e.Args.FirstOrDefault(a => a.StartsWith("--out:"))?[6..]
                        ?? Path.Combine(Path.GetTempPath(), "aegiskit_selftest"));
            return;
        }

        var window = new MainWindow();
        MainWindow = window;
        window.Show();
    }

    /// <summary>
    /// Самопроверка: по очереди открывает все страницы в настоящем окне, ждёт фоновые
    /// сканы, сохраняет PNG и печатает число строк в таблицах. Раньше страницы просто
    /// измерялись без добавления в визуальное дерево — сканы не запускались, и на
    /// картинках всегда были пустые таблицы.
    /// </summary>
    private void RunSelfTest(string outDir)
    {
        try { File.Delete(SelfTestLog); } catch { }
        Trace($"start selftest out={outDir}");
        try
        {
            Directory.CreateDirectory(outDir);
            Trace($"directory ready: {outDir}");
            var report = new List<string> { $"{Core.AppInfo.FullName} self-test {DateTime.Now:yyyy-MM-dd HH:mm:ss}" };
            Trace("creating MainWindow");
            var window = new MainWindow
            {
                Width = 1240,
                Height = 780,
                Left = -4000,
                Top = -4000,
                ShowInTaskbar = false
            };
            window.Show();
            Pump(400);
            Trace("MainWindow shown");

            int failed = 0;
            foreach (var nav in Descendants<RadioButton>(window).Where(r => r.Tag is string).ToList())
            {
                var tag = (string)nav.Tag;
                try
                {
                    nav.IsChecked = true;
                    // Ждём фоновые сканы страницы: планировщик читается через PowerShell
                    // и на первом запуске отвечает не мгновенно.
                    Pump(9000);

                    var page = Descendants<ContentControl>(window)
                        .FirstOrDefault(c => c.Name == "PageHost")?.Content as DependencyObject;
                    var grids = page == null ? new List<DataGrid>() : Descendants<DataGrid>(page).ToList();
                    var rows = grids.Count == 0 ? -1 : grids.Max(g => g.Items.Count);
                    if (rows == 0) failed++;

                    Render(window, Path.Combine(outDir, $"page_{tag.ToLowerInvariant()}.png"));
                    // Снимок только самой страницы — так вёрстку видно без навигации и журнала
                    if (page is FrameworkElement fe)
                    {
                        Render(fe, Path.Combine(outDir, $"view_{tag.ToLowerInvariant()}.png"));
                        try { File.WriteAllLines(Path.Combine(outDir, $"layout_{tag.ToLowerInvariant()}.txt"),
                                                  DumpLayout(fe), System.Text.Encoding.UTF8); }
                        catch { }
                        // Столбцы таблиц: проверяем, что они заданы в пикселях (тогда их
                        // можно тянуть и прокручивать) и что перетаскивание разрешено.
                        try { File.WriteAllLines(Path.Combine(outDir, $"columns_{tag.ToLowerInvariant()}.txt"),
                                                  DumpColumns(grids), System.Text.Encoding.UTF8); }
                        catch { }
                    }
                    var line = $"{tag,-10} таблиц={grids.Count} строк={rows} " + (rows == 0 ? "ПУСТО" : "OK");
                    report.Add(line);
                    Trace("page " + line);
                }
                catch (Exception pageEx)
                {
                    failed++;
                    report.Add($"{tag,-10} ОШИБКА: {pageEx.Message}");
                    Trace($"page {tag} FAILED: {pageEx}");
                }
            }

            // Выпадающее меню раскрываем принудительно: у системного шаблона WPF
            // подменю было светлым прямоугольником с чужой полосой выделения, поэтому
            // его вид должен попадать в отчёт, а не проверяться на глаз.
            try
            {
                var actionMenu = Descendants<MenuItem>(window)
                    .FirstOrDefault(m => (m.Header as string) == "Действие");
                if (actionMenu != null)
                {
                    // Окно смещается на экран: содержимое Popup вне экрана не
                    // раскладывается, и в отчёте оставался пустой список пунктов.
                    window.Left = 60;
                    window.Top = 60;
                    Pump(400);
                    // RaiseEvent(Click) обработчик не вызывает — меню открывает именно
                    // внутренний OpenSubmenu из OnClick, поэтому зовём его напрямую.
                    var openSubmenu = typeof(MenuItem).GetMethod("OpenSubmenu",
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                    openSubmenu?.Invoke(actionMenu, null);
                    actionMenu.IsSubmenuOpen = true;
                    Pump(900);
                    var popup = actionMenu.Template?.FindName("PART_Popup", actionMenu)
                        as System.Windows.Controls.Primitives.Popup;
                    var popupChild = popup?.Child as FrameworkElement;
                    Trace($"menu IsSubmenuOpen={actionMenu.IsSubmenuOpen} popup={popup != null} " +
                          $"open={popup?.IsOpen} child={popupChild?.GetType().Name} " +
                          $"size={popupChild?.ActualWidth:F0}x{popupChild?.ActualHeight:F0}");
                    Render(window, Path.Combine(outDir, "menu_actions.png"));
                    File.WriteAllLines(Path.Combine(outDir, "menu_actions.txt"),
                                       DumpLayout(window), System.Text.Encoding.UTF8);
                    Trace("menu opened and captured");
                    actionMenu.IsSubmenuOpen = false;
                    window.Left = -4000;
                    window.Top = -4000;
                    Pump(300);
                }
            }
            catch (Exception menuEx) { Trace($"menu capture failed: {menuEx.Message}"); }

            SimpleLog.Ok("SelfTest: страницы отрисованы");
            Environment.ExitCode = failed > 0 ? 2 : 0;
            report.Add($"страниц без данных: {failed}");
            report.Add($"{Core.SystemInfo.WindowsVersion}; права администратора: " +
                       (Core.SystemInfo.IsElevated ? "да" : "нет"));
            try { File.WriteAllLines(Path.Combine(outDir, "selftest.txt"), report, System.Text.Encoding.UTF8); }
            catch { }
            // Журнал приложения — в нём видны предупреждения источников данных
            try { File.WriteAllText(Path.Combine(outDir, "journal.txt"), SimpleLog.Export(), System.Text.Encoding.UTF8); }
            catch { }
            Trace($"done, pages without data = {failed}");
        }
        catch (Exception ex)
        {
            Trace($"FAIL: {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
            Environment.ExitCode = 2;
        }
        finally
        {
            Shutdown(Environment.ExitCode);
        }
    }

    /// <summary>
    /// Перечень столбцов всех таблиц страницы. Звёздочная ширина в этом отчёте —
    /// признак ошибки: такая таблица сжимает колонки вместо горизонтальной прокрутки,
    /// и столбцы становится невозможно растянуть и перетащить.
    /// </summary>
    private static List<string> DumpColumns(List<DataGrid> grids)
    {
        var lines = new List<string>();
        if (grids.Count == 0) return new List<string> { "таблиц на странице нет" };
        foreach (var grid in grids)
        {
            var name = string.IsNullOrEmpty(grid.Name) ? "(без имени)" : grid.Name;
            lines.Add($"{name}: столбцов {grid.Columns.Count}, " +
                      $"растягивать={grid.CanUserResizeColumns}, перетаскивать={grid.CanUserReorderColumns}");
            foreach (var column in grid.Columns)
            {
                var width = column.Width.IsAuto ? "auto"
                    : column.Width.IsStar ? "ЗВЕЗДА (плохо)"
                    : column.Width.DisplayValue.ToString("F0") + " px";
                var trim = column is DataGridTextColumn tc && tc.ElementStyle != null
                    ? "обрезка=да" : "";
                lines.Add($"    {column.Header?.ToString(),-26} {width,-16} " +
                          $"растягивать={column.CanUserResize} перетаскивать={column.CanUserReorder} {trim}");
            }
        }
        return lines;
    }

    /// <summary>
    /// Текстовый снимок вёрстки страницы: тип, имя, границы и текст каждого элемента.
    /// По нему видно, что ничего не наезжает друг на друга и не выходит за пределы страницы.
    /// </summary>
    private static List<string> DumpLayout(FrameworkElement root)
    {
        var lines = new List<string>();
        var boxes = new List<(string Label, Rect Box)>();
        Walk(root, 0, root, new Rect(0, 0, root.ActualWidth, root.ActualHeight));

        // anchor — корень текущего визуального дерева: содержимое Popup (выпадающее
        // меню, подсказки) живёт в отдельном дереве, и координаты считаются от него.
        // clip — область, которую элемент реально может закрасить: пересечение рамок
        // предков с ClipToBounds. Без этого обрезанный внутри ячейки текст выглядел
        // как «наложение» — хотя на экране он обрезан и ничего не перекрывает.
        void Walk(DependencyObject node, int depth, Visual anchor, Rect clip)
        {
            if (node is System.Windows.Controls.Primitives.Popup popup)
            {
                var content = popup.Child as FrameworkElement;
                lines.Add(new string(' ', depth * 2) +
                          $"Popup открыт={popup.IsOpen} содержимое={content?.GetType().Name ?? "нет"} " +
                          $"размер={content?.ActualWidth:F0}x{content?.ActualHeight:F0}");
                if (content != null)
                    Walk(content, depth + 1, content,
                         new Rect(0, 0, content.ActualWidth, content.ActualHeight));
                return;
            }
            // Глубины хватает на «меню → пункт → подменю → пункт»: на 12 содержимое
            // Popup обрезалось и в отчёт попадал пустой список пунктов.
            if (depth > 20) return;
            if (node is FrameworkElement fe && fe.ActualWidth > 0 && fe.ActualHeight > 0)
            {
                var text = fe switch
                {
                    TextBlock tb => tb.Text,
                    Button b => b.Content?.ToString() ?? "",
                    CheckBox cb => cb.Content?.ToString() ?? "",
                    TabItem ti => ti.Header?.ToString() ?? "",
                    TextBox tx => tx.Text,
                    System.Windows.Controls.Primitives.Popup => "",
                    _ => ""
                };
                Point p;
                try { p = fe.TransformToAncestor(anchor).Transform(new Point(0, 0)); }
                catch { p = new Point(0, 0); }
                var box = new Rect(p, new Size(fe.ActualWidth, fe.ActualHeight));
                var label = fe.GetType().Name + (string.IsNullOrEmpty(fe.Name) ? "" : $"#{fe.Name}");
                var inPopup = !ReferenceEquals(anchor, root);
                lines.Add($"{"  ".Substring(0, 1)}{new string(' ', depth * 2)}{label,-26} " +
                          $"x={p.X,7:F1} y={p.Y,7:F1} w={fe.ActualWidth,7:F1} h={fe.ActualHeight,6:F1}" +
                          (text.Length == 0 ? "" : "  «" + Truncate(text) + "»"));

                // Сравниваем только видимые элементы с текстом и кнопки — именно они
                // жаловались друг на друга в прошлых версиях интерфейса.
                if (text.Length > 0 && !(fe is Panel) && !inPopup)
                {
                    var visible = Rect.Intersect(box, clip);
                    if (!visible.IsEmpty && visible.Width > 1 && visible.Height > 1)
                        boxes.Add(($"{label} «{Truncate(text)}" + "»", visible));
                }

                if (fe.ClipToBounds)
                    clip = Rect.Intersect(clip, box);
            }
            int count = 0;
            try { count = VisualTreeHelper.GetChildrenCount(node); } catch { }
            for (int i = 0; i < count; i++)
                Walk(VisualTreeHelper.GetChild(node, i), depth + 1, anchor, clip);
        }

        lines.Add("");
        lines.Add("=== Возможные наложения (площадь пересечения > 40 px²) ===");
        int overlaps = 0;
        for (int i = 0; i < boxes.Count; i++)
            for (int j = i + 1; j < boxes.Count; j++)
            {
                var a = boxes[i];
                var b = boxes[j];
                if (!a.Box.IntersectsWith(b.Box)) continue;
                var inter = Rect.Intersect(a.Box, b.Box);
                if (inter.IsEmpty || inter.Width * inter.Height < 40) continue;
                // Вложенные элементы (например, текст внутри кнопки) — не наложение
                if (a.Box.Contains(b.Box) || b.Box.Contains(a.Box)) continue;
                lines.Add($"  {a.Label}  ×  {b.Label}   площадь={inter.Width * inter.Height:F0}");
                overlaps++;
            }
        if (overlaps == 0) lines.Add("  не найдено");
        return lines;
    }

    private static string Truncate(string s) => s.Length <= 48 ? s.Replace('\n', ' ') :
        s[..48].Replace('\n', ' ') + "…";

    private static void Render(FrameworkElement element, string path)
    {
        element.UpdateLayout();
        int w = (int)Math.Round(element.ActualWidth);
        int h = (int)Math.Round(element.ActualHeight);
        if (w <= 0 || h <= 0) return;
        var bmp = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Pbgra32);
        bmp.Render(element);
        var enc = new PngBitmapEncoder();
        enc.Frames.Add(BitmapFrame.Create(bmp));
        using var fs = File.Create(path);
        enc.Save(fs);
    }

    /// <summary>Прокачивает очередь диспетчера указанное время (для фоновых сканов).</summary>
    private static void Pump(int milliseconds)
    {
        var until = Environment.TickCount64 + milliseconds;
        while (Environment.TickCount64 < until)
        {
            var frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,
                new DispatcherOperationCallback(f =>
                {
                    ((DispatcherFrame)f).Continue = false;
                    return null;
                }), frame);
            Dispatcher.PushFrame(frame);
            Thread.Sleep(50);
        }
    }

    private static IEnumerable<T> Descendants<T>(DependencyObject root) where T : DependencyObject
    {
        int count = VisualTreeHelper.GetChildrenCount(root);
        for (int i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            if (child is T t) yield return t;
            foreach (var d in Descendants<T>(child)) yield return d;
        }
    }
}

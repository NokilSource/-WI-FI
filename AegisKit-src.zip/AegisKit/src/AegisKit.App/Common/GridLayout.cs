using System.ComponentModel;
using System.Windows;
using System.Windows.Data;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using AegisKit.Core;

namespace AegisKit.App;

/// <summary>
/// Запоминает ширину столбцов таблиц, которую пользователь выставил мышью, и
/// восстанавливает её при следующем открытии страницы. Без этого «подвинуть
/// столбики» приходилось бы заново при каждом запуске.
/// </summary>
public static class GridLayout
{
    private static readonly Dictionary<string, double> Pending = new();
    /// <summary>Столбцы, к которым сохранение уже подключено: повторный вызов Attach не должен вешать второй обработчик.</summary>
    private static readonly HashSet<DataGridColumn> Attached = new();
    /// <summary>Ширина столбца сразу после загрузки XAML: изменения в пределах пары пикселей
    /// от неё — это не перетаскивание мышью, а перерасчёт при раскладке.</summary>
    private static readonly Dictionary<DataGridColumn, double> InitialWidth = new();
    private static DispatcherTimer? _saveTimer;

    /// <summary>
    /// Подключает к странице сохранение/восстановление ширин столбцов. Обход идёт и по
    /// визуальному, и по логическому дереву, а повторный вызов безопасен — поэтому
    /// метод можно вызывать и из конструктора страницы, и после её загрузки.
    /// </summary>
    public static void Attach(FrameworkElement page, string pageKey)
    {
        void Run()
        {
            int index = 0;
            foreach (var grid in FindGrids(page))
            {
                var id = string.IsNullOrEmpty(grid.Name) ? "g" + index : grid.Name;
                Attach(grid, $"{pageKey}.{id}");
                index++;
            }
        }

        Run();
        // Часть таблиц (внутри невыбранных вкладок) появляется в дереве только после
        // загрузки страницы — повторяем попытку на Loaded, это дёшево и идемпотентно.
        try { page.Loaded += (_, _) => Run(); } catch { }
    }

    /// <summary>Явная привязка одной таблицы под собственным ключом.</summary>
    public static void Attach(DataGrid grid, string gridKey)
    {
        foreach (var column in grid.Columns)
        {
            EnableTrimming(column);
        }

        foreach (var column in grid.Columns)
        {
            if (!Attached.Add(column)) continue;

            var header = column.Header?.ToString() ?? "";
            if (header.Length == 0) continue;
            var key = $"{gridKey}.{header}";

            // Восстанавливаем только «пиксельные» ширины: звёздочную ширину сохранять
            // бессмысленно, а авторазмер пользователь и не менял.
            if (AppSettings.GetColumnWidth(key) is { } saved)
            {
                try { column.Width = new DataGridLength(saved); } catch { }
            }
            try { InitialWidth[column] = column.Width.DisplayValue; } catch { }

            // У DataGridColumn нет события изменения ширины — подписываемся на
            // само свойство Width через дескриптор зависимости.
            var captured = column;
            var capturedKey = key;
            var descriptor = DependencyPropertyDescriptor.FromProperty(
                DataGridColumn.WidthProperty, typeof(DataGridColumn));
            descriptor?.AddValueChanged(captured, (_, _) =>
            {
                if (captured.Width.IsStar || captured.Width.IsAuto) return;
                // Защита от ложных срабатываний: при первой раскладке и при смене
                // размера окна WPF сам пересчитывает ширину — записывать это как
                // «пользователь подвинул столбец» нельзя.
                if (InitialWidth.TryGetValue(captured, out var initial) &&
                    Math.Abs(initial - captured.Width.DisplayValue) < 3) return;
                QueueSave(capturedKey, captured.Width.Value);
            });
        }
    }

    /// <summary>
    /// Длинное значение (имя службы, путь, команда) должно оставаться читаемым.
    /// Обрезать его многоточием по ширине столбца в WPF нельзя: ContentPresenter
    /// отдаёт тексту всю ширину таблицы, а лишнее потом отсекает ClipToBounds ячейки.
    /// Поэтому к каждой ячейке добавляется подсказка с полным текстом — при наведении
    /// видно значение целиком, как в проводнике.
    /// </summary>
    private static void EnableTrimming(DataGridColumn column)
    {
        if (column is not DataGridTextColumn text) return;
        if (text.ElementStyle != null) return;

        var style = new Style(typeof(TextBlock));
        style.Setters.Add(new Setter(TextBlock.TextTrimmingProperty, TextTrimming.CharacterEllipsis));
        style.Setters.Add(new Setter(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center));
        style.Setters.Add(new Setter(System.Windows.Controls.ToolTipService.ToolTipProperty,
            new Binding(nameof(TextBlock.Text))
            {
                RelativeSource = new RelativeSource(RelativeSourceMode.Self)
            }));
        text.ElementStyle = style;
    }

    private static void QueueSave(string key, double width)
    {
        Pending[key] = width;
        _saveTimer ??= CreateTimer();
        _saveTimer.Stop();
        _saveTimer.Start();
    }

    private static DispatcherTimer CreateTimer()
    {
        // Пишем файл не на каждый пиксель перетаскивания, а через паузу после него
        var timer = new DispatcherTimer(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromMilliseconds(700)
        };
        timer.Tick += (_, _) =>
        {
            timer.Stop();
            foreach (var (key, width) in Pending) AppSettings.SetColumnWidth(key, width);
            Pending.Clear();
        };
        return timer;
    }

    private static List<DataGrid> FindGrids(DependencyObject root)
    {
        var found = new List<DataGrid>();
        var seen = new HashSet<DependencyObject>();
        Walk(root);
        return found;

        void Walk(DependencyObject node)
        {
            if (!seen.Add(node)) return;
            if (node is DataGrid grid && !found.Contains(grid)) found.Add(grid);
            foreach (var child in Children(node)) Walk(child);
        }

        static IEnumerable<DependencyObject> Children(DependencyObject node)
        {
            int count = 0;
            try { count = VisualTreeHelper.GetChildrenCount(node); } catch { count = 0; }
            for (int i = 0; i < count; i++)
            {
                DependencyObject? child = null;
                try { child = VisualTreeHelper.GetChild(node, i); } catch { }
                if (child != null) yield return child;
            }

            foreach (var child in LogicalTreeHelper.GetChildren(node))
                if (child is DependencyObject d) yield return d;
        }
    }
}

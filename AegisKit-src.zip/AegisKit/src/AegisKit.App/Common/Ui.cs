using System.Windows;

namespace AegisKit.App;

/// <summary>Помощник вызова кода из фоновых потоков в UI-потоке.</summary>
public static class Ui
{
    public static void Invoke(Action action)
    {
        var app = Application.Current;
        if (app?.Dispatcher.CheckAccess() == true) action();
        else app?.Dispatcher.Invoke(action);
    }
}

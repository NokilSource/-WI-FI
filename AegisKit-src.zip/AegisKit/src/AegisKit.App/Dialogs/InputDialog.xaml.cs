using System.Windows;
using System.Windows.Input;

namespace AegisKit.App.Dialogs;

public partial class InputDialog : Window
{
    public string Value => ValueBox.Text;

    public InputDialog(string title, string hint, string initialValue)
    {
        InitializeComponent();
        Title = title;
        HintText.Text = hint;
        ValueBox.Text = initialValue ?? "";
        ValueBox.SelectAll();
        ValueBox.Focus();
    }

    private void Ok_Click(object sender, RoutedEventArgs e) => DialogResult = true;

    protected override void OnKeyDown(KeyEventArgs e)
    {
        // Enter подтверждает диалог, Shift+Enter переносит строку в многострочном поле
        if (e.Key == Key.Enter && (Keyboard.Modifiers & ModifierKeys.Shift) == 0)
        {
            DialogResult = true;
            e.Handled = true;
            return;
        }
        base.OnKeyDown(e);
    }
}

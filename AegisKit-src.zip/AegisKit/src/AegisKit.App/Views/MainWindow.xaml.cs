using System.Collections.Specialized;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using AegisKit.App.Views.Pages;
using AegisKit.Core;
using AegisKit.Core.Logging;

namespace AegisKit.App.Views;

public partial class MainWindow : Window
{
    private readonly Dictionary<string, UserControl> _pages = new();
    private string _currentKey = "Processes";
    private bool _journalCollapsed;

    public MainWindow()
    {
        InitializeComponent();
        SimpleLog.CaptureUiContext();

        Title = $"{AppInfo.FullName} — {SystemInfo.ComputerName}";
        AppTitleText.Text = AppInfo.FullName;
        AdminText.Text = SystemInfo.IsElevated ? "администратор" : "без прав администратора";
        AdminText.Foreground = SystemInfo.IsElevated
            ? (System.Windows.Media.Brush)FindResource("TextDim")
            : (System.Windows.Media.Brush)FindResource("Danger");

        EnvText.Text = $"{SystemInfo.WindowsVersion}" +
                       (SystemInfo.IsWinRE ? "  ·  среда восстановления" : "");

        var log = SimpleLog.GetEntries();
        LogList.ItemsSource = log;
        ((INotifyCollectionChanged)log).CollectionChanged += (_, _) =>
        {
            LogCountText.Text = $"{log.Count} записей";
            if (log.Count > 0) LogList.ScrollIntoView(log[^1]);
        };
        LogCountText.Text = $"{log.Count} записей";

        SimpleLog.Changed += () => Ui.Invoke(() =>
        {
            StatusText.Text = SimpleLog.GetEntries().Count > 0
                ? SimpleLog.GetEntries()[^1].Message
                : "Готово";
        });

        SimpleLog.ProgressChanged += () => Ui.Invoke(UpdateProgress);

        // Восстанавливаем сохранённые параметры окна
        Width = AppSettings.WindowWidth;
        Height = AppSettings.WindowHeight;
        Topmost = AppSettings.Topmost;
        TopmostBox.IsChecked = AppSettings.Topmost;
        TopmostMenuItem.IsChecked = AppSettings.Topmost;
        JournalMenuItem.IsChecked = AppSettings.JournalVisible;
        JournalRow.Height = AppSettings.JournalVisible
            ? new GridLength(AppSettings.JournalHeight)
            : new GridLength(0);
        _journalCollapsed = !AppSettings.JournalVisible;
        ApplyJournalVisibility();
        if (AppSettings.WindowMaximized) WindowState = WindowState.Maximized;

        Nav_Checked(NavProcesses, new RoutedEventArgs());
    }

    // ===================== Журнал и ход выполнения =====================

    private void UpdateProgress()
    {
        var percent = SimpleLog.Progress;
        var text = SimpleLog.ProgressText;
        if (percent == null && string.IsNullOrEmpty(text))
        {
            Progress.Visibility = Visibility.Collapsed;
            Progress.IsIndeterminate = false;
            ProgressText.Text = "";
            return;
        }
        Progress.Visibility = Visibility.Visible;
        if (percent == null)
        {
            // Процент неизвестен (например, sfc /scannow) — показываем бегунок
            Progress.IsIndeterminate = true;
        }
        else
        {
            Progress.IsIndeterminate = false;
            Progress.Value = percent.Value;
        }
        ProgressText.Text = percent is { } p ? $"{text} — {p}%" : text;
    }

    private void ApplyJournalVisibility()
    {
        var visible = !_journalCollapsed;
        JournalPanel.Visibility = visible ? Visibility.Visible : Visibility.Collapsed;
        JournalSplitter.Visibility = visible ? Visibility.Visible : Visibility.Collapsed;
        JournalSplitRow.Height = visible ? GridLength.Auto : new GridLength(0);
        JournalRow.Height = visible
            ? new GridLength(AppSettings.JournalHeight)
            : new GridLength(0);
        CollapseJournalBtn.Content = visible ? "Свернуть" : "Развернуть";
        JournalMenuItem.IsChecked = visible;
    }

    private void CollapseJournal_Click(object sender, RoutedEventArgs e)
    {
        _journalCollapsed = !_journalCollapsed;
        if (!_journalCollapsed && JournalRow.Height.Value < 60)
            JournalRow.Height = new GridLength(AppSettings.JournalHeight);
        ApplyJournalVisibility();
        AppSettings.JournalVisible = !_journalCollapsed;
    }

    private void JournalMenu_Click(object sender, RoutedEventArgs e)
    {
        _journalCollapsed = !JournalMenuItem.IsChecked;
        ApplyJournalVisibility();
        AppSettings.JournalVisible = !_journalCollapsed;
    }

    // ===================== Меню =====================

    private void Topmost_Changed(object sender, RoutedEventArgs e)
    {
        var on = TopmostBox.IsChecked == true;
        Topmost = on;
        TopmostMenuItem.IsChecked = on;
        AppSettings.Topmost = on;
    }

    private void TopmostMenu_Click(object sender, RoutedEventArgs e)
    {
        var on = TopmostMenuItem.IsChecked;
        Topmost = on;
        TopmostBox.IsChecked = on;
        AppSettings.Topmost = on;
    }

    private void RefreshPage_Click(object sender, RoutedEventArgs e) => ReloadCurrentPage();

    private void ToggleMaximize_Click(object sender, RoutedEventArgs e) =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

    private void Exit_Click(object sender, RoutedEventArgs e) => Close();

    private void ClearLog_Click(object sender, RoutedEventArgs e)
    {
        SimpleLog.Clear();
        SimpleLog.Info("Журнал очищен");
    }

    private void OpenSettingsFolder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var dir = System.IO.Path.GetDirectoryName(AppSettings.Path);
            if (!string.IsNullOrEmpty(dir))
                Core.Native.NativeMethods.ShowInExplorer(dir);
        }
        catch (Exception ex) { SimpleLog.Error($"Папка настроек: {ex.Message}"); }
    }

    private void OpenCmd_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("cmd.exe") { UseShellExecute = true });
            SimpleLog.Info("Открыта командная строка");
        }
        catch (Exception ex) { SimpleLog.Error($"cmd.exe: {ex.Message}"); }
    }

    private void OpenRegedit_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("regedit.exe") { UseShellExecute = true });
            SimpleLog.Info("Открыт Редактор реестра");
        }
        catch (Exception ex) { SimpleLog.Error($"regedit.exe: {ex.Message}"); }
    }

    private void RunSfc_Click(object sender, RoutedEventArgs e)
    {
        if (!SystemInfo.IsElevated)
        {
            MessageBox.Show("Проверка целостности требует прав администратора.", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        SimpleLog.Info("Запуск sfc /scannow (вывод — в журнале)");
        SimpleLog.SetProgress(null, "Проверка целостности системных файлов (sfc /scannow)");
        Core.Recovery.RecoveryOps.RunSfc(line =>
        {
            if (ProgressParser.PercentFrom(line) is { } p)
                SimpleLog.SetProgress(p, "Проверка целостности системных файлов");
            SimpleLog.Info("   " + line);
        }, code =>
        {
            SimpleLog.ClearProgress();
            SimpleLog.Ok($"sfc завершён с кодом {code}");
        });
    }

    private void About_Click(object sender, RoutedEventArgs e)
    {
        var text =
            $"{AppInfo.FullName}\r\n\r\n" +
            "Диагностика, аудит автозапуска и восстановление Windows.\r\n" +
            "Работает офлайн, включая среду восстановления (WinRE).\r\n\r\n" +
            $"Система:   {SystemInfo.WindowsVersion}\r\n" +
            $"Компьютер: {SystemInfo.ComputerName}\\{SystemInfo.UserName}\r\n" +
            $"Права:     {(SystemInfo.IsElevated ? "администратор" : "пользователь")}\r\n" +
            $"Среда:     {(SystemInfo.IsWinRE ? "WinRE / WinPE" : "обычная загрузка")}\r\n" +
            $".NET:      {Environment.Version}\r\n\r\n" +
            $"Настройки: {AppSettings.Path}";
        MessageBox.Show(text, "О программе AegisKit", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void Hotkeys_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show(
            "F5                 — обновить текущий раздел\r\n" +
            "Ctrl+L             — очистить журнал\r\n" +
            "Ctrl+S             — сохранить журнал в файл\r\n" +
            "Delete             — удалить выбранную запись (в таблицах)\r\n\r\n" +
            "Столбцы таблиц меняют ширину перетаскиванием их границ.",
            "Горячие клавиши", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    // ===================== Страницы =====================

    private void Nav_Checked(object sender, RoutedEventArgs e)
    {
        if (sender is not RadioButton rb || rb.Tag is not string key) return;
        _currentKey = key;
        ShowPage(key);
    }

    private void ShowPage(string key)
    {
        try
        {
            if (!_pages.TryGetValue(key, out var page))
            {
                page = CreatePage(key);
                _pages[key] = page;
                GridLayout.Attach(page, key);
            }
            PageHost.Content = page;
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"Открытие страницы {key}: {ex.Message}");
        }
    }

    /// <summary>Пересоздаёт текущую страницу — данные перечитываются заново.</summary>
    private void ReloadCurrentPage()
    {
        try
        {
            _pages.Remove(_currentKey);
            PageHost.Content = null;
            ShowPage(_currentKey);
            SimpleLog.Info($"Раздел «{_currentKey}» обновлён");
        }
        catch (Exception ex) { SimpleLog.Error($"Обновление раздела: {ex.Message}"); }
    }

    private static UserControl CreatePage(string key) => key switch
    {
        "Processes" => new ProcessesPage(),
        "Autostart" => new AutostartPage(),
        "Registry" => new RegistryPage(),
        "Scheduler" => new SchedulerPage(),
        "Services" => new ServicesPage(),
        "Files" => new FilesPage(),
        "Recovery" => new RecoveryPage(),
        "System" => new SystemPage(),
        _ => throw new ArgumentException($"Неизвестный раздел: {key}")
    };

    // ===================== Горячие клавиши =====================

    private void Window_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        bool ctrl = (System.Windows.Input.Keyboard.Modifiers & System.Windows.Input.ModifierKeys.Control) != 0;
        if (e.Key == System.Windows.Input.Key.F5 && !ctrl)
        {
            ReloadCurrentPage();
            e.Handled = true;
        }
        else if (ctrl && e.Key == System.Windows.Input.Key.L)
        {
            SimpleLog.Clear();
            SimpleLog.Info("Журнал очищен");
            e.Handled = true;
        }
        else if (ctrl && e.Key == System.Windows.Input.Key.S)
        {
            SaveLog_Click(sender, e);
            e.Handled = true;
        }
    }

    // ===================== Прочее =====================

    private void SaveLog_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.SaveFileDialog
        {
            Filter = "Текстовый журнал (*.log)|*.log|Все файлы (*.*)|*.*",
            FileName = $"AegisKit_{DateTime.Now:yyyyMMdd_HHmmss}.log"
        };
        if (dlg.ShowDialog(this) == true)
        {
            System.IO.File.WriteAllText(dlg.FileName, SimpleLog.Export(), System.Text.Encoding.UTF8);
            SimpleLog.Ok($"Журнал сохранён: {dlg.FileName}");
        }
    }

    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
    {
        try
        {
            if (WindowState == WindowState.Normal)
            {
                AppSettings.WindowWidth = Width;
                AppSettings.WindowHeight = Height;
            }
            AppSettings.WindowMaximized = WindowState == WindowState.Maximized;
            if (JournalRow.Height.Value > 60) AppSettings.JournalHeight = JournalRow.Height.Value;
            AppSettings.Save();
        }
        catch { }
        base.OnClosing(e);
    }
}

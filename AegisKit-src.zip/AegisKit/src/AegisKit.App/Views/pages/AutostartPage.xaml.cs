using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using AegisKit.Core.Autostart;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;
using AegisKit.Core.Processes;
using AegisKit.Core.RegOps;

namespace AegisKit.App.Views.Pages;

public partial class AutostartPage : PageBase
{
    private List<AutostartEntry> _source = new();
    private bool _busy;

    private DataGrid CurrentGrid => Tabs.SelectedIndex switch
    {
        1 => GridBoot,
        2 => GridHooks,
        3 => GridFolders,
        _ => GridRun
    };

    public AutostartPage()
    {
        InitializeComponent();
        // Каждая таблица хранит свои ширины столбцов отдельно. Привязываемся явно:
        // таблицы невыбранных вкладок отсутствуют в визуальном дереве, и общий обход
        // по странице их бы не нашёл.
        GridLayout.Attach(GridRun, "Autostart.Run");
        GridLayout.Attach(GridBoot, "Autostart.Shell");
        GridLayout.Attach(GridHooks, "Autostart.Hooks");
        GridLayout.Attach(GridFolders, "Autostart.Folders");
        Loaded += async (_, _) => await RefreshAsync();
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAsync();

    private async Task RefreshAsync()
    {
        if (_busy) return;
        _busy = true;
        RefreshBtn.IsEnabled = false;
        try
        {
            _source = await Task.Run(() => AutorunScanner.Scan());
            SimpleLog.Info($"Записей автозагрузки: {_source.Count}");
            ApplyFilter();
        }
        finally
        {
            _busy = false;
            RefreshBtn.IsEnabled = true;
        }
    }

    private void ApplyFilter()
    {
        // Тег вкладки совпадает с категорией AutostartCategory.Of; запасной вариант —
        // сопоставление по индексу, чтобы смена XAML не могла дать пустой список.
        var category = (Tabs.SelectedItem as TabItem)?.Tag as string;
        if (string.IsNullOrEmpty(category))
            category = Tabs.SelectedIndex switch
            {
                1 => AutostartCategory.Shell,
                2 => AutostartCategory.Hooks,
                3 => AutostartCategory.Folders,
                _ => AutostartCategory.Run
            };
        string? search = SearchBox.Text?.Trim();

        IEnumerable<AutostartEntry> rows = _source.Where(e => AutostartCategory.Of(e.Kind) == category);
        if (OnlySuspicious.IsChecked == true)
            rows = rows.Where(e => e.Suspicious);
        if (!string.IsNullOrEmpty(search))
            rows = rows.Where(e =>
                e.ValueName.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                e.Command.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                e.Location.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                e.Company.Contains(search, StringComparison.OrdinalIgnoreCase));

        var list = rows.ToList();
        CurrentGrid.ItemsSource = list;

        var total = _source.Count(e => AutostartCategory.Of(e.Kind) == category);
        var susp = list.Count(e => e.Suspicious);
        var changed = list.Count(e => e.Modified && !e.Suspicious);
        SummaryText.Text = $"Записей: {total} · подозрительных: {susp}" +
                           (changed > 0 ? $" · изменённых: {changed}" : "");
    }

    private void Filter_Changed(object sender, RoutedEventArgs e) => ApplyFilter();
    private void Search_Changed(object sender, System.Windows.Controls.TextChangedEventArgs e) => ApplyFilter();
    private void Tab_Changed(object sender, System.Windows.Controls.SelectionChangedEventArgs e) => ApplyFilter();

    private AutostartEntry? Selected => CurrentGrid.SelectedItem as AutostartEntry;

    /// <summary>Все выделенные строки: удалять можно сразу пачку, а не по одной.</summary>
    private List<AutostartEntry> SelectedRows =>
        CurrentGrid.SelectedItems.Cast<AutostartEntry>().ToList();

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        var rows = SelectedRows;
        if (rows.Count == 0) return;

        string msg;
        if (rows.Count == 1)
        {
            var r = rows[0];
            msg = r.Kind switch
            {
                AutostartKind.BootExecute => "Восстановить эталонное значение BootExecute (autocheck autochk *)?",
                AutostartKind.Winlogon when r.ValueName is "Shell" or "Userinit" or "UIHost" =>
                    $"Восстановить эталонное значение {r.ValueName}? Текущее: {r.Command}",
                AutostartKind.StartupFolder => $"Удалить файл автозагрузки?\n{r.Command}",
                _ => $"Удалить запись автозапуска?\n{r.Location}\\{r.ValueName} = {r.Command}"
            };
        }
        else
        {
            var preview = string.Join("\n", rows.Take(12).Select(r => "• " + r.ValueName));
            if (rows.Count > 12) preview += $"\n…и ещё {rows.Count - 12}";
            msg = $"Удалить выделенные записи ({rows.Count})?\n\n{preview}";
        }

        if (MessageBox.Show(msg, "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        int done = 0, failed = 0;
        foreach (var r in rows)
        {
            if (AutorunScanner.DeleteEntry(r)) { _source.Remove(r); done++; }
            else failed++;
        }
        SimpleLog.Info($"Удаление автозапуска: успешно {done}" + (failed > 0 ? $", не удалось {failed}" : ""));
        ApplyFilter();
    }

    private void Edit_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null) return;
        if (r.IsFileItem || r.Kind == AutostartKind.StartupFolder)
        {
            MessageBox.Show("Файлы папок Startup редактируются вручную: " + r.Command,
                "AegisKit", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var dlg = new Dialogs.InputDialog($"Изменение автозапуска · {r.ValueName}",
            $"{r.RegHive}\\{r.RegKey}\nПараметр: {r.ValueKey ?? r.ValueName}", r.Command);
        if (dlg.ShowDialog() == true)
        {
            if (AutorunScanner.EditEntry(r, dlg.Value))
            {
                r.Command = dlg.Value;
                r.ResolvedPath = AutorunScanner.ExtractExecutable(dlg.Value);
                RefreshRow(r);
            }
        }
    }

    /// <summary>Объясняет, почему строка выделена — без отдельного столбца «Вердикт».</summary>
    private void WhyMarked_Click(object sender, RoutedEventArgs e)
    {
        var rows = SelectedRows;
        if (rows.Count == 0) return;
        var lines = rows.Select(r =>
        {
            var state = r.Modified && !r.Suspicious ? "изменённая системная запись" :
                        r.Suspicious ? "подозрительная запись" : "признаков не найдено";
            var reasons = string.IsNullOrWhiteSpace(r.Reasons) ? "—" : r.Reasons;
            return $"• {r.ValueName} — {state}\n   {r.Location}\n   {reasons}";
        });
        MessageBox.Show(string.Join("\n\n", lines), "Почему помечено",
            MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void OpenRegedit_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.RegKey)) return;
        var full = $"{r.RegHive}\\{r.RegKey}".ToUpperInvariant()
            .Replace("HKLM", "HKEY_LOCAL_MACHINE").Replace("HKCU", "HKEY_CURRENT_USER");
        RegistryEditor.OpenInRegedit(full);
    }

    private void OpenFolder_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.ResolvedPath))
        {
            SimpleLog.Warn("Не удалось определить файл записи");
            return;
        }
        NativeMethods.ShowInExplorer(r.ResolvedPath);
    }

    private void CopyCommand_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.Command)) return;
        try
        {
            Clipboard.SetText(r.Command);
            SimpleLog.Ok($"Скопировано: {r.ValueName}");
        }
        catch (Exception ex) { SimpleLog.Error($"Буфер обмена: {ex.Message}"); }
    }

    private void VerifyOne_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.ResolvedPath)) return;
        if (!File.Exists(r.ResolvedPath))
        {
            SimpleLog.Warn($"{r.ValueName}: файл не найден ({r.ResolvedPath})");
            return;
        }
        try { r.Signed = NativeMethods.VerifyFileSignature(r.ResolvedPath); }
        catch { r.Signed = false; }
        r.SignatureChecked = true;
        AutorunScanner.Reevaluate(r);
        SimpleLog.Info($"{r.ValueName}: {(r.Signed ? "подпись действительна" : "действительной подписи нет")}" +
                       (!string.IsNullOrEmpty(r.Reasons) ? " · " + r.Reasons : ""));
        ApplyFilter();
    }

    private async void VerifyAll_Click(object sender, RoutedEventArgs e)
    {
        var targets = _source.Where(x => !string.IsNullOrEmpty(x.ResolvedPath) && File.Exists(x.ResolvedPath)).ToList();
        if (targets.Count == 0)
        {
            SimpleLog.Info("Нет файлов автозагрузки для проверки подписи");
            return;
        }
        SimpleLog.Info($"Проверка подписей автозагрузки: {targets.Count} файлов…");
        VerifyBtn.IsEnabled = false;
        try
        {
            int signed = 0;
            await Task.Run(() =>
            {
                Parallel.ForEach(targets, new ParallelOptions { MaxDegreeOfParallelism = 4 }, r =>
                {
                    try { r.Signed = NativeMethods.VerifyFileSignature(r.ResolvedPath); }
                    catch { r.Signed = false; }
                    r.SignatureChecked = true;
                    if (r.Signed) System.Threading.Interlocked.Increment(ref signed);
                });
            });
            // пересчитать вердикты с учётом подписей
            foreach (var r in targets)
                AutorunScanner.Reevaluate(r);
            ApplyFilter();
            SimpleLog.Ok($"Проверка подписей завершена: подписано {signed}/{targets.Count}");
        }
        finally { VerifyBtn.IsEnabled = true; }
    }

    private async void FindSimilar_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.ResolvedPath)) return;
        var found = await Task.Run(() => ProcessService.FindSimilarFiles(r.ResolvedPath));
        MessageBox.Show(found.Count == 0
            ? "Похожих файлов не найдено."
            : $"Найдено: {found.Count}\n\n{string.Join("\n", found.Take(40))}",
            "Похожие файлы", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    /// <summary>
    /// Одиночный пересчёт при переключении вкладки/фильтра. Раньше здесь был
    /// «RefreshRow», который присваивал ItemsSource сам себе и ничего не делал —
    /// изменённая запись оставалась на экране со старым текстом.
    /// </summary>
    private void RefreshRow(AutostartEntry r) => ApplyFilter();
}

using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using AegisKit.App.Dialogs;
using AegisKit.Core.Files;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;
using Microsoft.Win32;

namespace AegisKit.App.Views.Pages;

public partial class FilesPage : PageBase
{
    private CancellationTokenSource? _scanCts;
    /// <summary>Полный результат последнего скана (для фильтра «только подозрительные»).</summary>
    private List<RecentFileRow> _recent = new();

    /// <summary>История переходов — как «назад» в настоящем проводнике.</summary>
    private readonly List<string> _history = new();
    private int _historyIndex = -1;
    private bool _navigating;

    private sealed class FileVm
    {
        public string Name { get; set; } = "";
        public string FullPath { get; set; } = "";
        public string Type { get; set; } = "";
        public bool IsFolder { get; set; }
        public long Size { get; set; }
        public DateTime Modified { get; set; }
        public string Attributes { get; set; } = "";
        public string SizeText => IsFolder ? "" :
            Size >= 1L << 30 ? $"{Size / 1073741824.0:F2} ГБ" :
            Size >= 1 << 20 ? $"{Size / 1048576.0:F1} МБ" :
            Size >= 1024 ? $"{Size / 1024.0:F1} КБ" : $"{Size} Б";
        public string ModifiedText => Modified.ToString("dd.MM.yyyy HH:mm:ss");
    }

    public FilesPage()
    {
        InitializeComponent();
        GridLayout.Attach(FileGrid, "Files.Explorer");
        GridLayout.Attach(RecentGrid, "Files.Recent");
        foreach (var loc in RecentFilesScanner.CommonLocations)
            RootsList.Items.Add(loc);
        RootsList.SelectAll();
        LoadDrives();
        string start = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        if (string.IsNullOrEmpty(start) || !Directory.Exists(start)) start = "C:\\";
        Loaded += (_, _) => Navigate(start);
    }

    // ================= Проводник =================

    private void LoadDrives()
    {
        var items = new List<string>();
        try
        {
            foreach (var d in DriveInfo.GetDrives())
            {
                try
                {
                    if (!d.IsReady) continue;
                    items.Add(d.Name);
                }
                catch { }
            }
        }
        catch (Exception ex) { SimpleLog.Warn($"Список дисков: {ex.Message}"); }
        DriveCombo.ItemsSource = items;
    }

    private void Navigate(string path, bool addToHistory = true)
    {
        var full = NormalizePath(path);
        if (full == null) return;

        _navigating = true;
        try
        {
            if (addToHistory)
            {
                if (_historyIndex >= 0 && _historyIndex < _history.Count - 1)
                    _history.RemoveRange(_historyIndex + 1, _history.Count - _historyIndex - 1);
                if (_history.Count == 0 || !_history[^1].Equals(full, StringComparison.OrdinalIgnoreCase))
                    _history.Add(full);
                _historyIndex = _history.Count - 1;
            }
            LoadFolder(full);
            PathBox.Text = full;
            BuildBreadcrumb(full);
            BackBtn.IsEnabled = _historyIndex > 0;
            UpBtn.IsEnabled = ParentOf(full) != null;
            var root = Path.GetPathRoot(full);
            if (root != null) DriveCombo.SelectedItem = root;
        }
        finally { _navigating = false; }
    }

    private static string? NormalizePath(string path)
    {
        try
        {
            var p = path.Trim().Trim('"');
            if (p.Length == 0) return null;
            if (p.StartsWith("Куст: ", StringComparison.OrdinalIgnoreCase)) p = p[6..];
            if (!Directory.Exists(p)) return null;
            return Path.GetFullPath(p).TrimEnd(Path.DirectorySeparatorChar) is { Length: > 0 } t
                ? (t.Length == 2 && t[1] == ':' ? t + "\\" : t)
                : p;
        }
        catch { return null; }
    }

    private static string? ParentOf(string path)
    {
        try
        {
            var parent = Directory.GetParent(path);
            return parent?.FullName;
        }
        catch { return null; }
    }

    private void BuildBreadcrumb(string full)
    {
        BreadcrumbPanel.Children.Clear();
        var segments = new List<(string Label, string Path)>();
        try
        {
            var current = full;
            while (!string.IsNullOrEmpty(current))
            {
                var name = Path.GetFileName(current);
                segments.Insert(0, (string.IsNullOrEmpty(name) ? current : name, current));
                var parent = Directory.GetParent(current)?.FullName;
                if (parent == null || parent == current) break;
                current = parent;
            }
        }
        catch { }

        foreach (var (label, segmentPath) in segments)
        {
            if (BreadcrumbPanel.Children.Count > 0)
            {
                BreadcrumbPanel.Children.Add(new TextBlock
                {
                    Text = "›",
                    Margin = new Thickness(5, 0, 5, 0),
                    VerticalAlignment = VerticalAlignment.Center,
                    Foreground = (Brush)FindResource("TextDim")
                });
            }
            var target = segmentPath;
            var btn = new Button
            {
                Content = label,
                Padding = new Thickness(7, 2, 7, 2),
                FontSize = 11.5,
                ToolTip = target
            };
            btn.Click += (_, _) => Navigate(target);
            BreadcrumbPanel.Children.Add(btn);
        }
    }

    private void LoadFolder(string path)
    {
        try
        {
            var items = new List<FileVm>();
            foreach (var d in Directory.EnumerateDirectories(path))
            {
                try
                {
                    var di = new DirectoryInfo(d);
                    bool hidden = di.Attributes.HasFlag(FileAttributes.Hidden) ||
                                  di.Attributes.HasFlag(FileAttributes.System);
                    items.Add(new FileVm
                    {
                        Name = di.Name,
                        FullPath = di.FullName,
                        Type = hidden ? "Папка (скрытая)" : "Папка",
                        IsFolder = true,
                        Modified = di.LastWriteTime,
                        Attributes = DescribeAttributes(di.Attributes)
                    });
                }
                catch { }
            }
            foreach (var f in Directory.EnumerateFiles(path))
            {
                try
                {
                    var fi = new FileInfo(f);
                    items.Add(new FileVm
                    {
                        Name = fi.Name,
                        FullPath = fi.FullName,
                        Type = string.IsNullOrEmpty(fi.Extension) ? "Файл" : fi.Extension.TrimStart('.').ToUpperInvariant(),
                        Size = fi.Length,
                        Modified = fi.LastWriteTime,
                        Attributes = DescribeAttributes(fi.Attributes)
                    });
                }
                catch { }
            }
            var ordered = items.OrderBy(i => i.IsFolder ? 0 : 1)
                               .ThenBy(i => i.Name, StringComparer.OrdinalIgnoreCase)
                               .ToList();
            FileGrid.ItemsSource = ordered;
            long totalSize = ordered.Where(i => !i.IsFolder).Sum(i => i.Size);
            SummaryText.Text = $"Объектов: {ordered.Count} · папок: {ordered.Count(i => i.IsFolder)} · " +
                               $"размер файлов: {totalSize / 1048576.0:F1} МБ";
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"Чтение папки: {ex.Message}");
        }
    }

    private static string DescribeAttributes(FileAttributes a)
    {
        var parts = new List<string>();
        if (a.HasFlag(FileAttributes.ReadOnly)) parts.Add("только чтение");
        if (a.HasFlag(FileAttributes.Hidden)) parts.Add("скрытый");
        if (a.HasFlag(FileAttributes.System)) parts.Add("системный");
        if (a.HasFlag(FileAttributes.Archive)) parts.Add("архивный");
        if (a.HasFlag(FileAttributes.ReparsePoint)) parts.Add("ссылка");
        if (a.HasFlag(FileAttributes.Compressed)) parts.Add("сжатый");
        return parts.Count == 0 ? "обычный" : string.Join(", ", parts);
    }

    private void Back_Click(object sender, RoutedEventArgs e)
    {
        if (_historyIndex <= 0) return;
        _historyIndex--;
        Navigate(_history[_historyIndex], addToHistory: false);
    }

    private void Up_Click(object sender, RoutedEventArgs e)
    {
        if (ParentOf(PathBox.Text.Trim()) is { } parent) Navigate(parent);
        else SimpleLog.Info("Выше корня диска подняться нельзя");
    }

    private void Refresh_Click(object sender, RoutedEventArgs e) => Navigate(PathBox.Text.Trim(), addToHistory: false);

    private void Go_Click(object sender, RoutedEventArgs e) => Navigate(PathBox.Text.Trim());

    private void PathBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) Navigate(PathBox.Text.Trim());
    }

    private void DriveCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_navigating) return;
        if (DriveCombo.SelectedItem is string drive) Navigate(drive);
    }

    private void FileGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e) => FileOpen_Click(sender, e);

    private void FileGrid_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) FileOpen_Click(sender, e);
        if (e.Key == Key.Back && ParentOf(PathBox.Text.Trim()) is { } parent) Navigate(parent);
    }

    private void NewFolder_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new InputDialog("Новая папка", $"Разместить в:\n{PathBox.Text.Trim()}", "Новая папка");
        if (dlg.ShowDialog() != true) return;
        var name = dlg.Value.Trim();
        if (name.Length == 0 || name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
        {
            MessageBox.Show("Недопустимое имя папки.", "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        try
        {
            var target = Path.Combine(PathBox.Text.Trim(), name);
            Directory.CreateDirectory(target);
            SimpleLog.Ok($"Создана папка: {target}");
            LoadFolder(PathBox.Text.Trim());
        }
        catch (Exception ex) { SimpleLog.Error($"Создание папки: {ex.Message}"); }
    }

    private void Rename_Click(object sender, RoutedEventArgs e)
    {
        if (FileGrid.SelectedItem is not FileVm f) return;
        var dlg = new InputDialog(f.IsFolder ? "Переименовать папку" : "Переименовать файл",
            f.FullPath, f.Name);
        if (dlg.ShowDialog() != true) return;
        var newName = dlg.Value.Trim();
        if (newName.Length == 0 || newName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
        {
            MessageBox.Show("Недопустимое имя.", "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        try
        {
            var dir = Path.GetDirectoryName(f.FullPath) ?? PathBox.Text.Trim();
            var target = Path.Combine(dir, newName);
            if (f.IsFolder) Directory.Move(f.FullPath, target);
            else File.Move(f.FullPath, target);
            SimpleLog.Ok($"Переименовано: {f.Name} → {newName}");
            LoadFolder(PathBox.Text.Trim());
        }
        catch (Exception ex) { SimpleLog.Error($"Переименование: {ex.Message}"); }
    }

    // ================= Эвристика =================

    private async void Scan_Click(object sender, RoutedEventArgs e)
    {
        if (!int.TryParse(MinutesBox.Text, out int minutes) || minutes <= 0)
        {
            MessageBox.Show("Укажите количество минут (целое число > 0).", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var roots = RootsList.SelectedItems.OfType<string>().ToList();
        if (roots.Count == 0)
        {
            MessageBox.Show("Не выбрано ни одной директории.", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        _scanCts = new CancellationTokenSource();
        ScanBtn.IsEnabled = false;
        CancelBtn.IsEnabled = true;
        _recent = new List<RecentFileRow>();
        RecentGrid.ItemsSource = null;
        ScanStatus.Text = $"Сканирование {roots.Count} каталогов, окно {minutes} мин…";
        SimpleLog.Info($"Сканирование недавних файлов: {roots.Count} корней, окно {minutes} мин…");
        SimpleLog.SetProgress(null, "Сканирование недавних файлов");

        try
        {
            var ct = _scanCts.Token;
            // Отчёт о ходе — в строку состояния страницы: скан идёт десятки
            // секунд, и без него интерфейс выглядит зависшим.
            var progress = new Progress<string>(text =>
            {
                ScanStatus.Text = text;
                SimpleLog.SetProgress(null, text);
            });
            var results = await Task.Run(() =>
                RecentFilesScanner.Scan(roots.ToArray(), minutes, t => ((IProgress<string>)progress).Report(t), ct));
            _recent = results;
            ApplyFilter();
            var suspicious = results.Count(r => r.Suspicious);
            ScanStatus.Text = $"Файлов за {minutes} мин: {results.Count}, с признаками: {suspicious}"
                              + (results.Count == 0 ? " — в выбранных каталогах ничего не менялось" : "");
            SimpleLog.Ok($"Найдено {results.Count} файлов за {minutes} мин (подозрительных: {suspicious})");
        }
        catch (OperationCanceledException)
        {
            ScanStatus.Text = "Сканирование отменено";
            SimpleLog.Warn("Сканирование отменено");
        }
        catch (Exception ex)
        {
            ScanStatus.Text = "Ошибка сканирования: " + ex.Message;
            SimpleLog.Error($"Сканирование: {ex.Message}");
        }
        finally
        {
            ScanBtn.IsEnabled = true;
            CancelBtn.IsEnabled = false;
            SimpleLog.ClearProgress();
        }
    }

    private void Filter_Changed(object sender, RoutedEventArgs e) => ApplyFilter();

    private void ApplyFilter()
    {
        var rows = OnlySuspiciousBox.IsChecked == true
            ? _recent.Where(r => r.Suspicious).ToList()
            : _recent;
        RecentGrid.ItemsSource = rows;
    }

    private void CancelScan_Click(object sender, RoutedEventArgs e) => _scanCts?.Cancel();

    private void AllRoots_Click(object sender, RoutedEventArgs e) => RootsList.SelectAll();

    private void ClearRoots_Click(object sender, RoutedEventArgs e) => RootsList.SelectedItems.Clear();

    // ================= Операции с файлами =================

    private List<string> SelectedFiles => FileGrid.SelectedItems?.Cast<FileVm>()
        .Select(f => f.FullPath).ToList() ?? new();

    private List<string> SelectedRecent => RecentGrid.SelectedItems?.Cast<RecentFileRow>()
        .Select(r => r.Path).ToList() ?? new();

    private void FileOpen_Click(object sender, RoutedEventArgs e)
    {
        if (FileGrid.SelectedItem is not FileVm f) return;
        try
        {
            if (f.IsFolder) Navigate(f.FullPath);
            else Process.Start(new ProcessStartInfo(f.FullPath) { UseShellExecute = true });
        }
        catch (Exception ex) { SimpleLog.Error($"Открытие: {ex.Message}"); }
    }

    private void FileShow_Click(object sender, RoutedEventArgs e)
    {
        if (FileGrid.SelectedItem is not FileVm f) return;
        NativeMethods.ShowInExplorer(f.FullPath);
    }

    private void RecentOpen_Click(object sender, RoutedEventArgs e)
    {
        if (RecentGrid.SelectedItem is not RecentFileRow r) return;
        NativeMethods.ShowInExplorer(r.Path);
    }

    private void RecentQuarantine_Click(object sender, RoutedEventArgs e) => QuarantineSelected_Click(sender, e);

    private void RecentForceDelete_Click(object sender, RoutedEventArgs e) => ForceDeleteSelected_Click(sender, e);

    private void CopySelected_Click(object sender, RoutedEventArgs e)
    {
        var files = SelectedFiles;
        if (files.Count == 0) return;
        var dlg = new OpenFolderDialog { Title = "Куда скопировать?" };
        if (dlg.ShowDialog() == true)
        {
            int ok = FileOperations.CopyTo(files, dlg.FolderName);
            SimpleLog.Ok($"Скопировано: {ok}/{files.Count}");
        }
    }

    private void MoveSelected_Click(object sender, RoutedEventArgs e)
    {
        var files = SelectedFiles;
        if (files.Count == 0) return;
        var dlg = new OpenFolderDialog { Title = "Куда переместить?" };
        if (dlg.ShowDialog() == true)
        {
            int ok = FileOperations.MoveTo(files, dlg.FolderName);
            SimpleLog.Ok($"Перемещено: {ok}/{files.Count}");
            LoadFolder(PathBox.Text.Trim());
        }
    }

    private void QuarantineSelected_Click(object sender, RoutedEventArgs e)
    {
        var files = SelectedFiles.Concat(SelectedRecent).Distinct().ToList();
        if (files.Count == 0) return;
        if (MessageBox.Show($"Отправить в карантин файлов: {files.Count}?\n(файлы будут перемещены в {FileOperations.QuarantineFolder})",
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        int ok = FileOperations.Quarantine(files);
        SimpleLog.Ok($"В карантине: {ok}/{files.Count}");
        LoadFolder(PathBox.Text.Trim());
    }

    private void ForceDeleteSelected_Click(object sender, RoutedEventArgs e)
    {
        var files = SelectedFiles.Concat(SelectedRecent).Distinct().ToList();
        if (files.Count == 0) return;
        if (MessageBox.Show($"Принудительно удалить файлов: {files.Count}?\n" +
                            "Блокирующие процессы будут завершены; при невозможности — файл удалится при перезагрузке.",
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        foreach (var f in files)
            FileOperations.ForceDelete(f);
        LoadFolder(PathBox.Text.Trim());
        _recent.RemoveAll(r => files.Contains(r.Path));
        ApplyFilter();
    }

    private async void WhoLocks_Click(object sender, RoutedEventArgs e)
    {
        var files = SelectedFiles;
        if (files.Count == 0) return;
        foreach (var f in files)
        {
            var lockers = await Task.Run(() => NativeMethods.GetFileLockers(f));
            if (lockers.Count == 0)
                SimpleLog.Info($"Файл не заблокирован: {f}");
            else
                SimpleLog.Warn($"Файл блокируют процессы PID: {string.Join(", ", lockers)} ({f})");
        }
    }
}

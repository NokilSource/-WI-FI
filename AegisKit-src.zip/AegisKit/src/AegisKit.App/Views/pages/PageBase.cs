using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace AegisKit.App.Views.Pages;

/// <summary>
/// Базовый класс страниц. Явно задаёт фон темы — стандартный
/// белый фон UserControl в тёмной теме недопустим.
/// </summary>
public class PageBase : UserControl
{
    public PageBase()
    {
        // Сплошной фон темы вместо Transparent: любая щель (PageHost, скроллбары,
        // пустые зоны DataGrid) остаётся тёмной, а не вспыхивает белым.
        try
        {
            if (System.Windows.Application.Current?.TryFindResource("Bg") is Brush bg)
                Background = bg;
            else
                Background = new SolidColorBrush(Color.FromRgb(0x14, 0x17, 0x1C));
        }
        catch
        {
            Background = Brushes.Transparent;
        }
    }

    public string? Title
    {
        get => (string?)GetValue(TitleProperty);
        set => SetValue(TitleProperty, value);
    }

    public static readonly DependencyProperty TitleProperty =
        DependencyProperty.Register(nameof(Title), typeof(string), typeof(PageBase), new PropertyMetadata(""));
}

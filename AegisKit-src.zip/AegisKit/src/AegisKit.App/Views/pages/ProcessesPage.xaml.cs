using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;
using AegisKit.Core.Processes;

namespace AegisKit.App.Views.Pages;

public partial class ProcessesPage : PageBase
{
    private readonly ObservableCollection<ProcessRow> _all = new();
    private List<ProcessRow> _source = new();
    private bool _busy;

    public ProcessesPage()
    {
        InitializeComponent();
        Grid.ItemsSource = _all;
        DataContext = _all;
        GridLayout.Attach(Grid, "Processes.Grid");
        Loaded += async (_, _) => await RefreshAsync();
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAsync();

    private async Task RefreshAsync()
    {
        if (_busy) return;
        _busy = true;
        RefreshBtn.IsEnabled = false;
        StatusText("Получение списка процессов…");
        try
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            _source = await Task.Run(ProcessService.Snapshot);
            SimpleLog.Info($"Снимок процессов готов за {sw.ElapsedMilliseconds} мс");
            ApplyFilter();
        }
        finally
        {
            _busy = false;
            RefreshBtn.IsEnabled = true;
            StatusClear();
        }

        // Проверка подписей — после отрисовки списка: раньше WinVerifyTrust для десятков
        // файлов выполнялся до первого показа таблицы и снимок «висел» пустым.
        await VerifySuspectsAsync();
    }

    private async Task VerifySuspectsAsync()
    {
        var suspects = ProcessService.SignatureCandidates(_source);
        if (suspects.Count == 0) return;
        try
        {
            int signed = await Task.Run(() => ProcessService.VerifySuspectSignatures(suspects));
            var keep = Selected;
            ApplyFilter();
            if (keep != null && _all.Contains(keep))
            {
                Grid.SelectedItem = keep;
                Grid.ScrollIntoView(keep);
            }
            SimpleLog.Info($"Подписи уточнены: проверено {suspects.Count}, подписано {signed}");
        }
        catch (Exception ex)
        {
            SimpleLog.Warn($"Проверка подписей: {ex.Message}");
        }
    }

    private ProcessRow? Selected =>
        Grid.SelectedItem as ProcessRow ?? Grid.SelectedItems?.Cast<ProcessRow>().FirstOrDefault();

    private List<ProcessRow> SelectedRows =>
        Grid.SelectedItems?.Cast<ProcessRow>().ToList() ?? new List<ProcessRow>();

    // ---------- Фильтры ----------

    private void ApplyFilter()
    {
        string? search = SearchBox.Text?.Trim();

        IEnumerable<ProcessRow> rows = _source;
        if (HideTrusted.IsChecked == true)
            rows = rows.Where(r => !SuspicionRules.IsTrustedPublisher(r.Company));
        if (OnlySuspicious.IsChecked == true)
            rows = rows.Where(r => r.Suspicious);
        if (!string.IsNullOrEmpty(search))
        {
            rows = rows.Where(r =>
                r.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                r.Pid.ToString() == search ||
                r.Company.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                r.Path.Contains(search, StringComparison.OrdinalIgnoreCase));
        }

        _all.Clear();
        foreach (var r in rows) _all.Add(r);
        SummaryText.Text = $"Показано: {_all.Count} · всего процессов: {_source.Count} · " +
                           $"подозрительных: {_source.Count(r => r.Suspicious)}";
    }

    private void Filter_Changed(object sender, RoutedEventArgs e) => ApplyFilter();
    private void Search_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();

    // ---------- Подписи ----------

    private async void VerifySignatures_Click(object sender, RoutedEventArgs e)
    {
        var rows = _all.ToList();
        if (rows.Count == 0)
        {
            SimpleLog.Info("Список процессов пуст — сначала нажмите «Обновить»");
            return;
        }
        SimpleLog.Info($"Проверка подписей: {rows.Count} файлов…");
        VerifyBtn.IsEnabled = false;
        int signed = 0, checkedCount = 0;
        try
        {
            await Task.Run(() =>
                Parallel.ForEach(rows, new ParallelOptions { MaxDegreeOfParallelism = 4 }, r =>
                {
                    if (string.IsNullOrEmpty(r.Path) || !File.Exists(r.Path)) return;
                    try { r.Signed = NativeMethods.VerifyFileSignature(r.Path); }
                    catch { r.Signed = false; }
                    r.SignatureChecked = true;
                    Interlocked.Increment(ref checkedCount);
                    if (r.Signed) Interlocked.Increment(ref signed);
                }));
            // Пересчёт вердиктов одним проходом: раньше таблица перерисовывалась
            // на каждую строку прямо из Parallel.ForEach
            foreach (var r in rows) Reevaluate(r);
            ApplyFilter();
            SimpleLog.Ok($"Проверка завершена: подписано {signed} из {checkedCount} проверенных файлов");
        }
        finally { VerifyBtn.IsEnabled = true; }
    }

    private void VerifyOne_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.Path)) return;
        if (!File.Exists(r.Path))
        {
            SimpleLog.Warn($"{r.Name}: файл недоступен ({r.Path})");
            return;
        }
        try { r.Signed = NativeMethods.VerifyFileSignature(r.Path); }
        catch { r.Signed = false; }
        r.SignatureChecked = true;
        try
        {
            var vi = System.Diagnostics.FileVersionInfo.GetVersionInfo(r.Path);
            r.Company = vi.CompanyName ?? "";
        }
        catch { }
        Reevaluate(r);
        SimpleLog.Info($"{r.Name}: {(r.Signed ? "подпись действительна" : "действительной подписи нет")}" +
                       (r.SuspiciousReasons.Length > 0 ? " · " + r.SuspiciousReasons : ""));
        RefreshRow(r);
    }

    /// <summary>Единая переоценка вердикта строки (сильные/слабые признаки).</summary>
    private static void Reevaluate(ProcessRow r)
    {
        if (string.IsNullOrEmpty(r.Path)) return;
        var signals = SuspicionRules.Analyze(r.Path, r.Company, r.SignatureChecked, r.Signed, r.CommandLine);
        r.Suspicious = signals.Any(s => s.Strength == SignalStrength.Strong);
        r.SuspiciousReasons = string.Join("; ", signals
            .Select(s => s.Strength == SignalStrength.Strong ? s.Text : s.Text + " (слабый признак)"));
    }

    private void CopyPath_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.Path)) return;
        try { Clipboard.SetText(r.Path); SimpleLog.Ok("Путь скопирован в буфер обмена"); }
        catch (Exception ex) { SimpleLog.Error($"Буфер обмена: {ex.Message}"); }
    }

    // ---------- Действия ----------

    private void Kill_Click(object sender, RoutedEventArgs e)
    {
        var rows = SelectedRows;
        if (rows.Count == 0) { WarnNoSelection(); return; }
        if (rows.Count == 1 && MessageBox.Show(
                $"Завершить процесс {rows[0].Name} (PID {rows[0].Pid})?",
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;
        if (rows.Count > 1 && MessageBox.Show(
                $"Завершить процессов: {rows.Count}?\n{string.Join("\n", rows.Take(10).Select(r => $"{r.Name} (PID {r.Pid})"))}" +
                (rows.Count > 10 ? $"\n…и ещё {rows.Count - 10}" : ""),
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        foreach (var r in rows)
        {
            if (r.IsSystem) { SimpleLog.Warn($"{r.Name} (PID {r.Pid}): системный процесс не завершается из AegisKit"); continue; }
            if (r.IsCritical && MessageBox.Show(
                    $"PID {r.Pid} помечен как критический — его завершение приведёт к СИНИМ ЭКРАНОМ. Продолжить?",
                    "Критический процесс", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                continue;
            if (ProcessService.Kill(r)) SimpleLog.Ok($"Завершён {r.Name} (PID {r.Pid})");
        }
        _ = RefreshAsync();
    }

    private void KillTree_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null) { WarnNoSelection(); return; }
        if (MessageBox.Show($"Завершить дерево процессов от {r.Name} (PID {r.Pid})?",
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;
        int killed = ProcessService.KillTree(r.Pid);
        SimpleLog.Ok($"Дерево {r.Name}: завершено процессов — {killed}");
        _ = RefreshAsync();
    }

    private void Suspend_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null) { WarnNoSelection(); return; }
        r.IsSuspended = ProcessService.Suspend(r);
        RefreshRow(r);
    }

    private void Resume_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null) { WarnNoSelection(); return; }
        ProcessService.Resume(r);
        r.IsSuspended = false;
        RefreshRow(r);
    }

    private void ToggleCritical_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null) { WarnNoSelection(); return; }
        if (ProcessService.SetCritical(r, !r.IsCritical))
        {
            r.IsCritical = !r.IsCritical;
            RefreshRow(r);
        }
    }

    private void OpenFolder_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.Path)) return;
        NativeMethods.ShowInExplorer(r.Path);
    }

    private void Properties_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.Path)) return;
        try
        {
            System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{r.Path}\"");
        }
        catch { }
    }

    private async void FindSimilar_Click(object sender, RoutedEventArgs e)
    {
        var r = Selected;
        if (r == null || string.IsNullOrEmpty(r.Path)) return;
        SimpleLog.Info($"Поиск файлов с именем «{System.IO.Path.GetFileName(r.Path)}» в типичных местах…");
        var found = await Task.Run(() => ProcessService.FindSimilarFiles(r.Path));
        if (found.Count == 0)
        {
            MessageBox.Show("Похожих файлов не найдено.", "AegisKit", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var list = string.Join("\n", found.Take(50));
        if (MessageBox.Show($"Найдено файлов: {found.Count}:\n\n{list}\n\nПоказать в Проводнике первый?",
                "Похожие файлы", MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
            NativeMethods.ShowInExplorer(found[0]);
    }

    private void RefreshRow(ProcessRow r)
    {
        var idx = _all.IndexOf(r);
        if (idx >= 0) { _all.RemoveAt(idx); _all.Insert(idx, r); }
    }

    private void WarnNoSelection() =>
        MessageBox.Show("Выберите процесс в таблице.", "AegisKit", MessageBoxButton.OK, MessageBoxImage.Information);

    private void StatusText(string s) => SimpleLog.Info(s);
    private void StatusClear() { }
}

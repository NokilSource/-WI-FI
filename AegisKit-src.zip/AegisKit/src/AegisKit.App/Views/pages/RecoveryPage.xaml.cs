using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using AegisKit.Core;
using AegisKit.Core.Logging;
using AegisKit.Core.Recovery;
using Microsoft.Win32;

namespace AegisKit.App.Views.Pages;

/// <summary>Пункт восстановления с галочкой для выборочного выполнения.</summary>
public sealed class RecoveryChoice : INotifyPropertyChanged
{
    private bool _isChecked;

    public RecoveryChoice(RecoveryItem item, bool isChecked)
    {
        Item = item;
        _isChecked = isChecked;
    }

    public RecoveryItem Item { get; }
    public string Title => Item.Title;
    public string Details => $"{Item.Group}: {Item.Title}. {Item.Details}";

    public bool IsChecked
    {
        get => _isChecked;
        set
        {
            if (_isChecked == value) return;
            _isChecked = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsChecked)));
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
}

public partial class RecoveryPage : PageBase
{
    private readonly StringBuilder _consoleOutput = new();
    private readonly List<RecoveryChoice> _choices = new();
    private bool _busy;

    /// <summary>Пункты, которые чаще всего восстанавливают доступ к системе.</summary>
    private static readonly HashSet<string> Recommended = new(StringComparer.OrdinalIgnoreCase)
    {
        "taskmgr", "regedit", "cmd", "run", "controlpanel", "folderopts", "gpedit", "devmgr",
        "hotkeys", "ifeo", "appinit", "lsa", "notify", "shell", "bootexec", "disallow",
        "desktop", "power", "logoff", "drives", "assoc", "uac"
    };

    public RecoveryPage()
    {
        InitializeComponent();
        BuildChoices();
        Loaded += (_, _) => UpdateSummary();
    }

    private void BuildChoices()
    {
        var saved = AppSettings.RecoverySelection;
        foreach (var item in RecoveryCatalog.Items)
        {
            // При первом запуске отмечаем базовый набор; дальше — то, что выбрал пользователь.
            bool initial = saved.Count == 0 ? Recommended.Contains(item.Id) : saved.Contains(item.Id);
            _choices.Add(new RecoveryChoice(item, initial));
        }
        RecoveryList.ItemsSource = _choices;
    }

    private void Choice_Changed(object sender, RoutedEventArgs e)
    {
        UpdateSummary();
        AppSettings.RecoverySelection = _choices.Where(c => c.IsChecked).Select(c => c.Item.Id).ToList();
    }

    private void UpdateSummary()
    {
        int total = _choices.Count;
        int selected = _choices.Count(c => c.IsChecked);
        SelectionInfo.Text = $"Отмечено: {selected} из {total}";
        SummaryText.Text = SystemInfo.IsElevated
            ? "Права администратора есть"
            : "Без прав администратора — часть операций будет недоступна";
        FullRestoreHint.Text = $"Будет выполнено пунктов: {selected}.";
        FullRestoreBtn.IsEnabled = selected > 0 && !_busy;
    }

    private void SelectAll_Click(object sender, RoutedEventArgs e) => SetAll(true);
    private void SelectNone_Click(object sender, RoutedEventArgs e) => SetAll(false);

    private void SelectRecommended_Click(object sender, RoutedEventArgs e)
    {
        foreach (var c in _choices) c.IsChecked = Recommended.Contains(c.Item.Id);
        OnSelectionChanged();
    }

    private void SetAll(bool value)
    {
        foreach (var c in _choices) c.IsChecked = value;
        OnSelectionChanged();
    }

    private void OnSelectionChanged()
    {
        AppSettings.RecoverySelection = _choices.Where(c => c.IsChecked).Select(c => c.Item.Id).ToList();
        UpdateSummary();
    }

    // ================= Полное восстановление =================

    private async void FullRestore_Click(object sender, RoutedEventArgs e)
    {
        var items = _choices.Where(c => c.IsChecked).Select(c => c.Item).ToList();
        if (items.Count == 0) return;

        var preview = string.Join("\n", items.Take(12).Select(i => "• " + i.Title));
        if (items.Count > 12) preview += $"\n…и ещё {items.Count - 12}";

        if (MessageBox.Show(
                $"Выполнить восстановление по {items.Count} пунктам?\n\n{preview}\n\n" +
                "Операция меняет системный реестр. Рекомендуется создать точку восстановления заранее.",
                "Полное восстановление", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        _busy = true;
        UpdateSummary();
        try
        {
            await Task.Run(() => RecoveryOps.RestoreItems(items,
                (done, total, title) => SimpleLog.SetProgress((int)Math.Round(done * 100.0 / total),
                    $"Восстановление: {title} ({done + 1} из {total})")));
        }
        finally
        {
            _busy = false;
            UpdateSummary();
        }
    }

    private async void UnlockHooks_Click(object sender, RoutedEventArgs e)
    {
        var ids = new[] { "ifeo", "appinit", "lsa", "notify", "shell", "bootexec" };
        var items = ids.Select(RecoveryCatalog.Find).Where(i => i != null).Select(i => i!).ToList();
        if (MessageBox.Show(
                "Снять перехваты запуска?\n\n" +
                "• IFEO Debugger и тихие перехваты (GlobalFlag, VerifierDlls)\n" +
                "• AppInit_DLLs\n• посторонние пакеты LSA\n• Winlogon Notify\n" +
                "• Shell / Userinit / UIHost\n• BootExecute",
                "Разблокировка отладчиков", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        _busy = true;
        UpdateSummary();
        try
        {
            await Task.Run(() => RecoveryOps.RestoreItems(items,
                (done, total, title) => SimpleLog.SetProgress((int)Math.Round(done * 100.0 / total),
                    $"Перехваты: {title} ({done + 1} из {total})")));
        }
        finally
        {
            _busy = false;
            UpdateSummary();
        }
    }

    // ================= Одиночные пункты =================

    private void RunQuiet(string name, Action action)
    {
        SimpleLog.Info($"Запуск: {name}");
        Task.Run(action);
    }

    private void Ifeo_Click(object sender, RoutedEventArgs e) =>
        Task.Run(() =>
        {
            SimpleLog.SetProgress(null, "Очистка IFEO Debugger");
            try { RecoveryOps.CleanIfeoDebuggersDetailed(out _, out _); }
            finally { SimpleLog.ClearProgress(); }
        });

    private void AppInit_Click(object sender, RoutedEventArgs e) => RunQuiet("AppInit_DLLs", RecoveryOps.CleanAppInitDlls);
    private void Lsa_Click(object sender, RoutedEventArgs e) => RunQuiet("Пакеты LSA", RecoveryOps.CleanLsaNotificationPackages);
    private void Notify_Click(object sender, RoutedEventArgs e) => RunQuiet("Winlogon Notify", RecoveryOps.CleanWinlogonNotify);
    private void Shell_Click(object sender, RoutedEventArgs e) => RunQuiet("Оболочка Winlogon", RecoveryOps.RestoreShellAndWinlogon);
    private void BootExecute_Click(object sender, RoutedEventArgs e) => RunQuiet("BootExecute", RecoveryOps.RestoreBootExecute);
    private void Disallow_Click(object sender, RoutedEventArgs e) => RunQuiet("Запрет запуска программ", RecoveryOps.RepairDisallowRestrict);
    private void Theme_Click(object sender, RoutedEventArgs e) => RunQuiet("Цветовая тема", RecoveryOps.RepairThemeColors);
    private void Assoc_Click(object sender, RoutedEventArgs e) => RunQuiet("Ассоциации файлов", RecoveryOps.RepairFileAssociations);
    private void Explorer_Click(object sender, RoutedEventArgs e) => RunQuiet("Перезапуск Проводника", RecoveryOps.RunExplorerRestart);

    // ================= Инструменты =================

    private static void StartShell(string file, string args = "")
    {
        try
        {
            Process.Start(new ProcessStartInfo(file, args) { UseShellExecute = true });
            SimpleLog.Info($"Открыто: {file} {args}".Trim());
        }
        catch (Exception ex) { SimpleLog.Error($"{file}: {ex.Message}"); }
    }

    private void OpenDrives_Click(object sender, RoutedEventArgs e) => StartShell("explorer.exe");
    private void OpenRegedit_Click(object sender, RoutedEventArgs e) => StartShell("regedit.exe");
    private void OpenTaskMgr_Click(object sender, RoutedEventArgs e) => StartShell("taskmgr.exe");
    private void OpenCmd_Click(object sender, RoutedEventArgs e) => StartShell("cmd.exe");
    private void OpenServices_Click(object sender, RoutedEventArgs e) => StartShell("services.msc");
    private void OpenDiskMgmt_Click(object sender, RoutedEventArgs e) => StartShell("diskmgmt.msc");
    private void OpenMsconfig_Click(object sender, RoutedEventArgs e) => StartShell("msconfig.exe");
    private void OpenFolderOptions_Click(object sender, RoutedEventArgs e)
    {
        // Отдельного исполняемого файла для параметров папок нет — открываем через rundll32.
        StartShell("rundll32.exe", "shell32.dll,Options_RunDLL 7");
    }

    private void OpenFonts_Click(object sender, RoutedEventArgs e)
    {
        var fonts = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Fonts");
        StartShell("explorer.exe", $"\"{fonts}\"");
    }

    // ================= Обслуживание =================

    private async void TempClean_Click(object sender, RoutedEventArgs e)
    {
        if (MessageBox.Show("Очистить временные каталоги (%TEMP%, Windows\\Temp, Prefetch)?",
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;
        SimpleLog.SetProgress(null, "Очистка временных файлов");
        try { await Task.Run(TempCleaner.CleanAll); }
        finally { SimpleLog.ClearProgress(); }
    }

    private async void CalcTemp_Click(object sender, RoutedEventArgs e)
    {
        TempSizeText.Text = "Расчёт…";
        long user = 0, win = 0, pf = 0;
        await Task.Run(() =>
        {
            user = TempCleaner.GetFolderSize(TempCleaner.UserTemp);
            win = TempCleaner.GetFolderSize(TempCleaner.WindowsTemp);
            pf = TempCleaner.GetFolderSize(TempCleaner.Prefetch);
        });
        TempSizeText.Text = $"Временных файлов: {(user + win + pf) / 1048576.0:F1} МБ " +
                            $"(пользователь {user / 1048576.0:F1} · система {win / 1048576.0:F1} · Prefetch {pf / 1048576.0:F1})";
    }

    // ================= SFC / DISM =================

    private void Sfc_Click(object sender, RoutedEventArgs e) =>
        RunSystemCheck("sfc.exe", "/scannow", "Проверка целостности системных файлов (sfc /scannow)");

    private void Dism_Click(object sender, RoutedEventArgs e) =>
        RunSystemCheck("dism.exe", "/Online /Cleanup-Image /RestoreHealth", "Восстановление образа (DISM RestoreHealth)");

    private void RunSystemCheck(string exe, string args, string title)
    {
        if (!SystemInfo.IsElevated)
        {
            MessageBox.Show("Проверка целостности требует прав администратора.", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (_busy) { SimpleLog.Warn("Другая операция уже выполняется"); return; }
        if (MessageBox.Show($"Запустить {exe} {args}?\nЭто может занять продолжительное время.",
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        _consoleOutput.Clear();
        SaveConsoleBtn.IsEnabled = false;
        SimpleLog.Command($"{exe} {args}");
        SimpleLog.SetProgress(null, title);

        RecoveryOps.RunSfc2(exe, args, line =>
        {
            lock (_consoleOutput) _consoleOutput.AppendLine(line);
            // Проценты есть только у DISM; для sfc остаётся бегунок.
            if (ProgressParser.PercentFrom(line) is { } p)
                SimpleLog.SetProgress(p, title);
            SimpleLog.Info("   " + line);
        }, code =>
        {
            SimpleLog.ClearProgress();
            SimpleLog.Ok($"{exe} завершён с кодом {code}. Вывод можно сохранить в файл.");
            Ui.Invoke(() => SaveConsoleBtn.IsEnabled = true);
        });
    }

    private void SaveConsole_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new SaveFileDialog
        {
            Filter = "Текстовые файлы|*.txt|Все файлы|*.*",
            FileName = $"system_check_{DateTime.Now:yyyyMMdd_HHmmss}.txt"
        };
        if (dlg.ShowDialog() == true)
        {
            string text;
            lock (_consoleOutput) text = _consoleOutput.ToString();
            File.WriteAllText(dlg.FileName, text, Encoding.UTF8);
            SimpleLog.Ok($"Вывод сохранён: {dlg.FileName}");
        }
    }
}

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using AegisKit.App.Dialogs;
using AegisKit.Core.Logging;
using AegisKit.Core.RegOps;
using Microsoft.Win32;

namespace AegisKit.App.Views.Pages;

public partial class RegistryPage : PageBase
{
    /// <summary>Ключ, с которым работают действия (дерево или поле адреса).</summary>
    private string? _currentPath;
    /// <summary>Параметры текущего раздела — для счётчика и проверок перед записью.</summary>
    private List<RegValue> _currentValues = new();
    /// <summary>Подавляет реакцию на смену выбора в списке кустов при его перестройке.</summary>
    private bool _suspendHiveEvents;

    public RegistryPage()
    {
        InitializeComponent();
        GridLayout.Attach(ValuesGrid, "Registry.Values");
        Loaded += async (_, _) =>
        {
            LoadRoots();
            RefreshHives();
            BuildBreadcrumb(null);
            // Открываем раздел, у которого точно есть параметры: пустой HKLM\SOFTWARE
            // выглядел как «реестр не работает».
            await NavigateAsync(
                @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion", selectInTree: true);
        };
    }

    // ===================== Корни и кусты =====================

    private void LoadRoots()
    {
        Tree.ItemsSource = RegistryEditor.GetRootNodes();
    }

    private void RefreshHives()
    {
        var mounted = RegistryHiveService.GetMounted();
        _suspendHiveEvents = true;
        try
        {
            var previouslySelected = (HiveCombo.SelectedItem as MountedHive)?.MountName;
            HiveCombo.ItemsSource = null;
            HiveCombo.ItemsSource = mounted;
            HiveCombo.DisplayMemberPath = nameof(MountedHive.MountName);
            if (mounted.Count > 0)
            {
                HiveCombo.SelectedItem = mounted.FirstOrDefault(m => m.MountName == previouslySelected)
                                         ?? mounted[0];
                HiveCombo.Items.Refresh();
            }
        }
        finally
        {
            _suspendHiveEvents = false;
        }

        bool has = mounted.Count > 0;
        // Кнопка «Отключить куст» недоступна, пока ни один куст не подключён —
        // раньше она открывала диалог и сообщала «куст не найден».
        UnmountBtn.IsEnabled = has;
        AuditBtn.IsEnabled = has;
        HiveCombo.IsEnabled = has;
        HiveCombo.ToolTip = has
            ? "Подключённые кусты реестра"
            : "Кусты не подключены — нажмите «Подключить куст реестра…»";
        StatusSummary.Text = has
            ? $"Кустов подключено: {mounted.Count}"
            : "Кустов не подключено";
    }

    private void HiveCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suspendHiveEvents) return;
    }

    // ===================== Путь и «хлебные крошки» =====================

    /// <summary>Строит навигационную строку: «Компьютер › HKEY_LOCAL_MACHINE › SOFTWARE».</summary>
    private void BuildBreadcrumb(string? path)
    {
        BreadcrumbPanel.Children.Clear();
        foreach (var (label, segmentPath) in RegistryEditor.Breadcrumb(path ?? ""))
        {
            if (BreadcrumbPanel.Children.Count > 0)
            {
                BreadcrumbPanel.Children.Add(new TextBlock
                {
                    Text = "›",
                    Margin = new Thickness(5, 0, 5, 0),
                    VerticalAlignment = VerticalAlignment.Center,
                    Foreground = (Brush)FindResource("TextDim")
                });
            }

            var target = segmentPath;
            bool isLast = label == RegistryEditor.Breadcrumb(path ?? "")[^1].Label;
            var btn = new Button
            {
                Content = label,
                Padding = new Thickness(7, 2, 7, 2),
                Margin = new Thickness(0),
                FontSize = 11.5,
                FontWeight = isLast ? FontWeights.SemiBold : FontWeights.Normal,
                IsEnabled = target.Length > 0,
                ToolTip = RegistryEditor.DisplayPath(target)
            };
            if (target.Length > 0)
                btn.Click += async (_, _) => await NavigateAsync(target);
            BreadcrumbPanel.Children.Add(btn);
        }
    }

    private string? SelectedPath
    {
        get
        {
            if (Tree.SelectedItem is not RegNode node) return null;
            if (node.FullPath == "DUMMY") return null;
            return node.FullPath;
        }
    }

    private static string? ParentOf(string path)
    {
        if (path.StartsWith(RegistryEditor.MountPrefix, StringComparison.OrdinalIgnoreCase))
        {
            var rest = path[RegistryEditor.MountPrefix.Length..];
            if (rest.Split('\\').Length <= 3) return null;   // корень куста — выше некуда
        }
        int idx = path.LastIndexOf('\\');
        if (idx <= 0) return null;
        var parent = path[..idx];
        return parent.Contains('\\') || !parent.Contains("HKEY_") ? parent : null;
    }

    private void GoUp_Click(object sender, RoutedEventArgs e)
    {
        var parent = _currentPath is null ? null : ParentOf(_currentPath);
        if (parent is null)
        {
            SimpleLog.Info("Выше корня реестра подняться нельзя");
            return;
        }
        _ = NavigateAsync(parent, selectInTree: true);
    }

    private void KeyPathBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) GoToKey_Click(sender, e);
    }

    /// <summary>Открывает раздел по пути: обновляет параметры, путь и дерево.</summary>
    private async Task NavigateAsync(string path, bool selectInTree = false)
    {
        var normalized = RegistryEditor.NormalizeHiveName(path.Trim());
        if (string.IsNullOrEmpty(normalized)) return;

        bool exists = await Task.Run(() =>
        {
            if (normalized.StartsWith(RegistryEditor.MountPrefix, StringComparison.OrdinalIgnoreCase))
                return RegistryHiveService.OpenMounted(normalized[RegistryEditor.MountPrefix.Length..]) != null;
            using var key = RegistryEditor.OpenKey(normalized);
            return key != null;
        });

        if (!exists)
        {
            SimpleLog.Warn($"Раздел недоступен: {RegistryEditor.DisplayPath(normalized)}");
            return;
        }

        if (selectInTree) await TrySelectInTreeAsync(normalized);
        await LoadValuesAsync(normalized);
    }

    private async void Tree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
        if (e.NewValue is RegNode node && node.FullPath != "DUMMY")
            await LoadValuesAsync(node.FullPath);
    }

    private async Task LoadValuesAsync(string path)
    {
        KeyPathBox.Text = RegistryEditor.DisplayPath(path);
        CurrentKeyText.Text = RegistryEditor.DisplayPath(path);
        BuildBreadcrumb(path);
        _currentPath = path;
        _currentValues = new List<RegValue>();
        ValuesGrid.ItemsSource = null;
        ValuesGridStatus.Text = "Чтение параметров…";
        var values = await Task.Run(() => RegistryEditor.GetValues(path));
        // Возврат в UI-поток делаем явно: обработчик асинхронный, а коллекции привязаны к UI
        Ui.Invoke(() =>
        {
            _currentValues = values;
            ValuesGrid.ItemsSource = values;
            // Пустой список у HKLM\SOFTWARE — это норма (в разделе нет параметров),
            // но выглядел он как «реестр не работает». Показываем пояснение.
            ValuesGridStatus.Text = values.Count == 0
                ? "В этом разделе нет параметров (только подразделы) — выберите раздел слева или введите путь"
                : $"Параметров: {values.Count}";
            CurrentKeyText.Text = values.Count == 0
                ? RegistryEditor.DisplayPath(path) + "   ·   параметров нет"
                : RegistryEditor.DisplayPath(path) + $"   ·   параметров: {values.Count}";
        });
    }

    /// <summary>Повторное чтение параметров текущего раздела (без выбора в дереве).</summary>
    private void RefreshValues_Click(object sender, RoutedEventArgs e)
    {
        if (_currentPath is { Length: > 0 } path) _ = LoadValuesAsync(path);
        else LoadRoots();
        RefreshHives();
    }

    private async void TreeViewItem_Expanded(object sender, RoutedEventArgs e)
    {
        if (e.OriginalSource is not TreeViewItem tvi || tvi.DataContext is not RegNode node) return;
        if (await EnsureChildrenAsync(node)) { }
    }

    /// <summary>Подгружает подключи узла, если вместо них стоит заглушка.</summary>
    private static async Task<bool> EnsureChildrenAsync(RegNode node)
    {
        if (!node.HasDummyChild) return false;
        var children = await Task.Run(() => RegistryEditor.GetSubKeys(node.FullPath));
        Ui.Invoke(() =>
        {
            // Замена заглушки на реальные подключи — только в UI-потоке
            node.Children.Clear();
            foreach (var c in children) node.Children.Add(c);
            node.HasDummyChild = false;
        });
        return true;
    }

    /// <summary>
    /// Раскрывает дерево до указанного пути и выделяет узел. Работает «мягко»:
    /// если какой-то уровень недоступен, просто прекращает раскрытие.
    /// </summary>
    private async Task TrySelectInTreeAsync(string path)
    {
        try
        {
            if (Tree.ItemsSource is not IEnumerable<RegNode> roots) return;
            var segments = path.Split('\\');
            var node = roots.FirstOrDefault(r =>
                r.FullPath.Equals(segments[0], StringComparison.OrdinalIgnoreCase));
            if (node == null) return;

            for (int i = 1; i < segments.Length; i++)
            {
                if (segments[i].Length == 0) continue;
                SetExpanded(node, true);
                await EnsureChildrenAsync(node);
                var next = node.Children.FirstOrDefault(c =>
                    c.Name.Equals(segments[i], StringComparison.OrdinalIgnoreCase));
                if (next == null) break;
                node = next;
            }
            SetExpanded(node, true);
            SetSelected(node);
        }
        catch (Exception ex)
        {
            SimpleLog.Warn($"Синхронизация дерева: {ex.Message}");
        }
    }

    private void SetExpanded(RegNode node, bool expanded)
    {
        if (FindContainer(node) is { } tvi) tvi.IsExpanded = expanded;
    }

    private void SetSelected(RegNode node)
    {
        if (FindContainer(node) is { } tvi)
        {
            tvi.IsSelected = true;
            tvi.BringIntoView();
        }
    }

    private TreeViewItem? FindContainer(RegNode target)
    {
        var stack = new Stack<TreeViewItem>();
        foreach (var item in Tree.Items)
            if (Tree.ItemContainerGenerator.ContainerFromItem(item) is TreeViewItem t) stack.Push(t);

        while (stack.Count > 0)
        {
            var tvi = stack.Pop();
            if (ReferenceEquals(tvi.DataContext, target)) return tvi;
            if (!tvi.IsExpanded) continue;
            tvi.UpdateLayout();
            foreach (var item in tvi.Items)
                if (tvi.ItemContainerGenerator.ContainerFromItem(item) is TreeViewItem child) stack.Push(child);
        }
        return null;
    }

    // ===================== Переход =====================

    private async void GoToKey_Click(object sender, RoutedEventArgs e)
    {
        var raw = KeyPathBox.Text.Trim();
        if (raw.Length == 0) return;
        // Пользователь может вставить путь в стиле Проводника — «Компьютер\HKEY_...».
        raw = raw.Replace("Куст: ", "").Trim();
        var path = RegistryEditor.NormalizeHiveName(raw) ?? "";
        if (path.Length == 0) return;
        await NavigateAsync(path, selectInTree: true);
    }

    // ===================== Кусты =====================

    private async void Mount_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Title = "Выберите файл куста реестра (SYSTEM, SOFTWARE, SAM, NTUSER.DAT…)",
            Filter = "Кусты реестра|SYSTEM;SYSTEM.*;SOFTWARE;SOFTWARE.*;SAM;SAM.*;SECURITY;SECURITY.*;NTUSER.DAT;NTUSER.DAT*;USRCLASS.DAT|Все файлы|*.*"
        };
        if (dlg.ShowDialog() != true) return;

        var mh = await Task.Run(() => RegistryHiveService.Mount(dlg.FileName));
        if (mh != null)
        {
            LoadRoots();
            RefreshHives();
            SimpleLog.Ok($"Куст подключён: {mh.MountName} → {mh.MountPoint}");
            await NavigateAsync(RegistryEditor.MountPrefix + mh.MountPoint, selectInTree: true);
        }
        else
        {
            MessageBox.Show(
                "Не удалось подключить куст.\n\n" +
                "Нужны права администратора и привилегии SeBackup/SeRestore, " +
                "а файл не должен быть занят другой системой.",
                "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private async void Unmount_Click(object sender, RoutedEventArgs e)
    {
        if (HiveCombo.SelectedItem is not MountedHive hive)
        {
            SimpleLog.Info("Кустов не подключено");
            return;
        }
        if (MessageBox.Show($"Отключить куст «{hive.MountName}»?\n{hive.HiveFile}",
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        bool ok = await Task.Run(() => RegistryHiveService.Unmount(hive));
        if (ok)
        {
            if (_currentPath != null &&
                _currentPath.StartsWith(RegistryEditor.MountPrefix, StringComparison.OrdinalIgnoreCase))
                _currentPath = null;
            LoadRoots();
            RefreshHives();
            await NavigateAsync("HKEY_LOCAL_MACHINE", selectInTree: true);
        }
    }

    private async void AuditHive_Click(object sender, RoutedEventArgs e)
    {
        if (HiveCombo.SelectedItem is not MountedHive hive)
        {
            SimpleLog.Info("Кусты не подключены — сначала подключите SYSTEM-куст");
            return;
        }
        SimpleLog.SetProgress(null, $"Проверка куста {hive.MountName}");
        try
        {
            var findings = await Task.Run(() => RegistryHiveService.AuditMountedSystem(hive));
            if (findings.Count == 0)
                SimpleLog.Ok($"[{hive.MountName}] Подозрительных драйверов и служб не найдено");
            else
                foreach (var f in findings)
                    SimpleLog.Warn($"[{hive.MountName}] {f}");
        }
        finally { SimpleLog.ClearProgress(); }
    }

    // ===================== Разделы и параметры =====================

    private async void CreateKey_Click(object sender, RoutedEventArgs e)
    {
        var parent = SelectedPath ?? _currentPath;
        if (parent == null)
        {
            MessageBox.Show("Выберите раздел-родитель в дереве.", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var dlg = new InputDialog("Создание раздела",
            $"Раздел-родитель:\n{RegistryEditor.DisplayPath(parent)}", "Новый раздел");
        if (dlg.ShowDialog() != true) return;
        var name = dlg.Value.Trim();
        if (name.Length == 0 || name.IndexOfAny(new[] { '\\', '/' }) >= 0)
        {
            MessageBox.Show("Имя раздела не должно быть пустым и не должно содержать \\ или /.",
                "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        bool ok = await Task.Run(() => RegistryEditor.CreateKey(parent, name));
        if (ok)
        {
            await RefreshNodeChildrenAsync(parent);
            await NavigateAsync(parent + "\\" + name, selectInTree: true);
        }
        else
        {
            MessageBox.Show("Не удалось создать раздел. Возможно, нужны права администратора.",
                "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private async void DeleteKey_Click(object sender, RoutedEventArgs e)
    {
        var path = SelectedPath ?? _currentPath;
        if (path == null)
        {
            MessageBox.Show("Выберите раздел в дереве.", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (MessageBox.Show($"Удалить раздел со всеми подразделами?\n{RegistryEditor.DisplayPath(path)}",
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        bool ok = await Task.Run(() => RegistryEditor.DeleteKey(path));
        if (ok)
        {
            ValuesGrid.ItemsSource = null;
            var parent = ParentOf(path);
            if (parent != null)
            {
                await RefreshNodeChildrenAsync(parent);
                await NavigateAsync(parent, selectInTree: true);
            }
            else LoadRoots();
        }
        else
        {
            MessageBox.Show("Не удалось удалить раздел. Возможно, нужны права администратора.",
                "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private async void DeleteValue_Click(object sender, RoutedEventArgs e)
    {
        var path = SelectedPath ?? _currentPath;
        if (ValuesGrid.SelectedItem is not RegValue v || path == null) return;
        if (MessageBox.Show($"Удалить параметр «{v.Name}»?", "AegisKit",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        bool ok = await Task.Run(() => RegistryEditor.DeleteValue(path, v.Name));
        if (ok) await LoadValuesAsync(path);
        else MessageBox.Show("Не удалось удалить параметр. Возможно, нужны права администратора.",
            "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
    }

    private async void EditValue_Click(object sender, RoutedEventArgs e)
    {
        var path = SelectedPath ?? _currentPath;
        if (path == null)
        {
            MessageBox.Show("Выберите раздел в дереве или введите путь.", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var v = ValuesGrid.SelectedItem as RegValue;

        // Новый параметр: сначала имя, потом тип, и только затем значение.
        if (v == null)
        {
            var nameDlg = new InputDialog("Имя нового параметра",
                $"Раздел:\n{RegistryEditor.DisplayPath(path)}", "");
            if (nameDlg.ShowDialog() != true) return;
            var newName = nameDlg.Value.Trim();
            if (newName.Length == 0)
            {
                MessageBox.Show("Имя параметра не должно быть пустым.", "AegisKit",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (_currentValues.Any(x => x.Name.Equals(newName, StringComparison.OrdinalIgnoreCase)) &&
                MessageBox.Show($"Параметр «{newName}» уже есть в разделе — перезаписать его?", "AegisKit",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;
            var typeDlg = new InputDialog("Тип нового параметра",
                "Введите тип: SZ (строка), EXPAND (расширяемая строка), DWORD, QWORD, MULTI (многострочный), BINARY.", "SZ");
            if (typeDlg.ShowDialog() != true) return;
            var type = typeDlg.Value.Trim().ToUpperInvariant();
            var valueDlg = new InputDialog($"Значение: {newName}",
                $"Раздел:\n{RegistryEditor.DisplayPath(path)}\nТип: {type}", "");
            if (valueDlg.ShowDialog() != true) return;
            try
            {
                bool created = await Task.Run(() => CreateTypedValue(path, newName, valueDlg.Value, type));
                if (created) await LoadValuesAsync(path);
                else MessageBox.Show("Не удалось записать значение. Возможно, нужны права администратора.",
                    "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Некорректное значение: {ex.Message}", "AegisKit",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            return;
        }

        var dlg = new InputDialog($"Изменение: {v.Name}",
            $"Раздел:\n{RegistryEditor.DisplayPath(path)}\nТип: {v.KindName}", v.Data switch
            {
                byte[] b => Convert.ToHexString(b),
                null => "",
                _ => v.DisplayData
            } ?? "");
        if (dlg.ShowDialog() != true) return;

        try
        {
            bool ok;
            {
                ok = v.Kind switch
                {
                    RegistryValueKind.DWord => await Task.Run(() =>
                    {
                        var num = Convert.ToUInt32(dlg.Value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
                            ? Convert.ToUInt64(dlg.Value, 16) : Convert.ToUInt64(dlg.Value));
                        return RegistryEditor.SetDword(path, v.Name, num);
                    }),
                    RegistryValueKind.QWord => await Task.Run(() =>
                    {
                        var num = dlg.Value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
                            ? Convert.ToUInt64(dlg.Value, 16) : Convert.ToUInt64(dlg.Value);
                        return RegistryEditor.SetQword(path, v.Name, num);
                    }),
                    RegistryValueKind.MultiString => await Task.Run(() =>
                    {
                        using var k = RegistryEditor.OpenKey(path, writable: true);
                        if (k == null) return false;
                        var name = v.Name == "(По умолчанию)" ? "" : v.Name;
                        k.SetValue(name, dlg.Value.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None),
                            RegistryValueKind.MultiString);
                        SimpleLog.Ok($"Записано: {path}\\{v.Name}");
                        return true;
                    }),
                    RegistryValueKind.Binary => await Task.Run(() =>
                    {
                        using var k = RegistryEditor.OpenKey(path, writable: true);
                        if (k == null) return false;
                        var name = v.Name == "(По умолчанию)" ? "" : v.Name;
                        k.SetValue(name, Convert.FromHexString(dlg.Value.Trim()), RegistryValueKind.Binary);
                        SimpleLog.Ok($"Записано: {path}\\{v.Name}");
                        return true;
                    }),
                    _ => await Task.Run(() => RegistryEditor.SetStringValue(path, v.Name, dlg.Value,
                        v.Kind == RegistryValueKind.ExpandString
                            ? RegistryValueKind.ExpandString
                            : RegistryValueKind.String)),
                };
            }
            if (ok) await LoadValuesAsync(path);
            else MessageBox.Show("Не удалось записать значение. Возможно, нужны права администратора.",
                "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Некорректное значение: {ex.Message}", "AegisKit", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private static bool CreateTypedValue(string path, string name, string value, string type)
    {
        return type switch
        {
            "DWORD" => RegistryEditor.SetDword(path, name,
                value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
                    ? Convert.ToUInt32(value, 16) : Convert.ToUInt32(value)),
            "QWORD" => RegistryEditor.SetQword(path, name,
                value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
                    ? Convert.ToUInt64(value, 16) : Convert.ToUInt64(value)),
            "EXPAND" => RegistryEditor.SetStringValue(path, name, value, RegistryValueKind.ExpandString),
            "MULTI" => SetMulti(path, name, value),
            "BINARY" => SetBinary(path, name, value),
            "DWORD_HEX" => RegistryEditor.SetDword(path, name, Convert.ToUInt32(value, 16)),
            _ => RegistryEditor.SetStringValue(path, name, value, RegistryValueKind.String),
        };
    }

    private static bool SetBinary(string path, string name, string hex)
    {
        try
        {
            using var k = RegistryEditor.OpenKey(path, writable: true);
            if (k == null) return false;
            var clean = new string(hex.Where(c => Uri.IsHexDigit(c)).ToArray());
            if (clean.Length % 2 != 0)
                throw new FormatException("шестнадцатеричная строка должна содержать чётное число символов");
            k.SetValue(name, Convert.FromHexString(clean), RegistryValueKind.Binary);
            SimpleLog.Ok($"Записано: {path}\\{name} (REG_BINARY, {clean.Length / 2} байт)");
            return true;
        }
        catch (Exception ex) { SimpleLog.Error($"Запись REG_BINARY: {ex.Message}"); return false; }
    }

    private static bool SetMulti(string path, string name, string value)
    {
        try
        {
            using var k = RegistryEditor.OpenKey(path, writable: true);
            if (k == null) return false;
            k.SetValue(name, value.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None),
                RegistryValueKind.MultiString);
            SimpleLog.Ok($"Записано: {path}\\{name}");
            return true;
        }
        catch (Exception ex) { SimpleLog.Error($"Запись параметра: {ex.Message}"); return false; }
    }

    private void ValuesGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (ValuesGrid.SelectedItem != null) EditValue_Click(sender, e);
    }

    private void ValuesGrid_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Delete && ValuesGrid.SelectedItem != null)
            DeleteValue_Click(sender, e);
    }

    private void OpenRegedit_Click(object sender, RoutedEventArgs e)
    {
        // Для смонтированного куста OpenInRegedit сам сообщит, что он не виден
        // в штатном Regedit — префикс MOUNT: не срезаем.
        if ((SelectedPath ?? _currentPath) is { } p)
            RegistryEditor.OpenInRegedit(p);
    }

    /// <summary>Обновляет детей узла-родителя, не схлопывая всё дерево.</summary>
    private async Task RefreshNodeChildrenAsync(string parentPath)
    {
        var children = await Task.Run(() => RegistryEditor.GetSubKeys(parentPath));
        Ui.Invoke(() =>
        {
            var node = FindNode(parentPath);
            if (node != null)
            {
                node.Children.Clear();
                foreach (var c in children) node.Children.Add(c);
                node.HasDummyChild = false;
            }
            else
            {
                LoadRoots();
            }
        });
    }

    private RegNode? FindNode(string fullPath)
    {
        if (Tree.ItemsSource is not IEnumerable<RegNode> roots) return null;
        var queue = new Queue<RegNode>();
        foreach (var r in roots) queue.Enqueue(r);
        while (queue.Count > 0)
        {
            var n = queue.Dequeue();
            if (n.FullPath.Equals(fullPath, StringComparison.OrdinalIgnoreCase)) return n;
            if (!n.HasDummyChild)
                foreach (var c in n.Children) queue.Enqueue(c);
        }
        return null;
    }
}

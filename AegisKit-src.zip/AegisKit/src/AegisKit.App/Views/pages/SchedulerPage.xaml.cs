using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using AegisKit.Core;
using AegisKit.Core.Logging;
using AegisKit.Core.Scheduler;

namespace AegisKit.App.Views.Pages;

public partial class SchedulerPage : PageBase
{
    private readonly ObservableCollection<TaskRow> _tasks = new();
    private List<TaskRow> _source = new();
    private bool _busy;
    /// <summary>Подавляет обработку Checked/Unchecked при программной перерисовке строк.</summary>
    private bool _suppressToggle;
    /// <summary>Последнее применённое состояние задач (FullPath → Enabled).</summary>
    private readonly Dictionary<string, bool> _appliedState = new(StringComparer.OrdinalIgnoreCase);
    private string? _selectedFolder = "\\";

    public SchedulerPage()
    {
        InitializeComponent();
        Grid.ItemsSource = _tasks;
        GridLayout.Attach(Grid, "Scheduler.Tasks");
        ShowAllFolders.IsChecked = AppSettings.ShowAllTaskFolders;
        Loaded += async (_, _) => await RefreshAsync();
    }

    private sealed class FolderNode
    {
        public string Name { get; set; } = "";
        public string Path { get; set; } = "";
        public List<FolderNode> Children { get; } = new();
        public override string ToString() => Name;
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAsync();

    private async Task RefreshAsync()
    {
        if (_busy) return;
        _busy = true;
        RefreshBtn.IsEnabled = false;
        SimpleLog.SetProgress(null, "Чтение задач планировщика");
        try
        {
            _source = await Task.Run(TaskSchedulerService.ListTasks);
            SimpleLog.Info($"Задач всего: {_source.Count} (в корне: " +
                           $"{_source.Count(t => t.FolderPath == "\\")})");
            _appliedState.Clear();
            foreach (var t in _source) _appliedState[t.FullPath] = t.Enabled;
            BuildTree();
            ApplyFilter();
        }
        finally
        {
            _busy = false;
            RefreshBtn.IsEnabled = true;
            SimpleLog.ClearProgress();
        }
    }

    private void BuildTree()
    {
        var root = new FolderNode { Name = @"\  (корень, все задачи)", Path = "\\" };
        var map = new Dictionary<string, FolderNode> { ["\\"] = root };

        foreach (var path in _source.Select(t => t.FolderPath).Distinct()
                     .OrderBy(p => p, StringComparer.OrdinalIgnoreCase))
        {
            var parts = path.Split('\\', StringSplitOptions.RemoveEmptyEntries);
            var current = "\\";
            var node = root;
            foreach (var part in parts)
            {
                current = current == "\\" ? "\\" + part : current + "\\" + part;
                if (!map.TryGetValue(current, out var child))
                {
                    child = new FolderNode { Name = part, Path = current };
                    map[current] = child;
                    node.Children.Add(child);
                }
                node = child;
            }
        }
        SortTree(root);
        Tree.ItemsSource = new List<FolderNode> { root };

        // Корень выбирается сразу: список задач не должен показывать сразу все папки —
        // иначе в таблице оказываются сотни задач Windows вместо задач текущей папки.
        // Контейнеры генерируются отложенно, поэтому подтверждаем выбор через Dispatcher:
        // синхронный ContainerFromIndex(0) почти всегда возвращал null и корень оставался
        // невыделенным, а фильтр — в неопределённом состоянии.
        Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Loaded, () =>
        {
            if (Tree.ItemContainerGenerator.ContainerFromIndex(0) is not TreeViewItem rootItem) return;
            rootItem.IsExpanded = true;
            rootItem.IsSelected = true;
        });
    }

    private static void SortTree(FolderNode node)
    {
        node.Children.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
        foreach (var c in node.Children) SortTree(c);
    }

    private void Tree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
        if (Tree.SelectedItem is FolderNode f)
        {
            _selectedFolder = f.Path;
            ApplyFilter();
        }
    }

    private void ApplyFilter()
    {
        IEnumerable<TaskRow> rows = _source;

        bool allFolders = ShowAllFolders.IsChecked == true;
        if (!allFolders)
        {
            var folder = _selectedFolder ?? "\\";
            rows = folder == "\\"
                ? rows.Where(t => t.FolderPath == "\\")
                : rows.Where(t => t.FolderPath.StartsWith(folder, StringComparison.OrdinalIgnoreCase));
        }
        if (HideMicrosoft.IsChecked == true)
            rows = rows.Where(t => !t.IsMicrosoft);
        if (OnlySuspicious.IsChecked == true)
            rows = rows.Where(t => t.Suspicious);

        string? search = SearchBox.Text?.Trim();
        if (!string.IsNullOrEmpty(search))
            rows = rows.Where(t =>
                t.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                t.Command.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                t.Author.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                t.FolderPath.Contains(search, StringComparison.OrdinalIgnoreCase));

        var list = rows.OrderBy(t => t.Name, StringComparer.OrdinalIgnoreCase).ToList();
        _suppressToggle = true;
        try
        {
            _tasks.Clear();
            foreach (var r in list) _tasks.Add(r);
        }
        finally { _suppressToggle = false; }

        int suspicious = _source.Count(t => t.Suspicious);
        SummaryText.Text = $"Показано: {list.Count} · всего задач: {_source.Count} · подозрительных: {suspicious}";
    }

    private void Filter_Changed(object sender, RoutedEventArgs e)
    {
        AppSettings.ShowAllTaskFolders = ShowAllFolders.IsChecked == true;
        ApplyFilter();
    }

    private void Search_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();

    private TaskRow? Selected => Grid.SelectedItem as TaskRow;

    private async void TaskEnable_Changed(object sender, RoutedEventArgs e)
    {
        if (_suppressToggle) return;
        if (sender is not CheckBox { DataContext: TaskRow t } box) return;
        // Намерение пользователя — текущее положение чекбокса; t.Enabled уже обновлён
        // двусторонней привязкой, поэтому сравниваем с последним применённым состоянием.
        bool newState = box.IsChecked == true;
        if (_appliedState.TryGetValue(t.FullPath, out bool applied) && applied == newState) return;
        await ApplyEnabledAsync(t, newState);
    }

    private async void ToggleEnabled_Click(object sender, RoutedEventArgs e)
    {
        var t = Selected;
        if (t == null)
        {
            MessageBox.Show("Выберите задачу в таблице.", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        await ApplyEnabledAsync(t, !t.Enabled);
    }

    private async Task ApplyEnabledAsync(TaskRow t, bool newState)
    {
        var ok = await Task.Run(() => TaskSchedulerService.SetEnabled(t, newState));
        _suppressToggle = true;
        try
        {
            if (ok)
            {
                t.Enabled = newState;
                _appliedState[t.FullPath] = newState;
            }
            else
            {
                t.Enabled = !newState;   // откат визуального состояния при неуспехе
            }
            var idx = _tasks.IndexOf(t);
            if (idx >= 0) { _tasks.RemoveAt(idx); _tasks.Insert(idx, t); }
        }
        finally { _suppressToggle = false; }
    }

    private async void RunNow_Click(object sender, RoutedEventArgs e)
    {
        var t = Selected;
        if (t == null)
        {
            MessageBox.Show("Выберите задачу в таблице.", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        await Task.Run(() => TaskSchedulerService.RunNow(t));
    }

    /// <summary>Все выделенные строки таблицы — удалять можно сразу пачку задач.</summary>
    private List<TaskRow> SelectedRows => Grid.SelectedItems.Cast<TaskRow>().ToList();

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        var rows = SelectedRows;
        if (rows.Count == 0)
        {
            MessageBox.Show("Выделите задачи в таблице.", "AegisKit",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var question = rows.Count == 1
            ? $"Удалить задачу «{rows[0].FullPath}»?"
            : $"Удалить выделенные задачи ({rows.Count})?\n\n" +
              string.Join("\n", rows.Take(12).Select(r => "• " + r.FullPath)) +
              (rows.Count > 12 ? $"\n…и ещё {rows.Count - 12}" : "");
        if (MessageBox.Show(question, "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning)
            != MessageBoxResult.Yes) return;

        int done = 0, failed = 0;
        foreach (var t in rows)
        {
            if (await Task.Run(() => TaskSchedulerService.Delete(t)))
            {
                _source.Remove(t);
                _tasks.Remove(t);
                _appliedState.Remove(t.FullPath);
                done++;
            }
            else failed++;
        }
        SimpleLog.Info($"Удаление задач: успешно {done}" + (failed > 0 ? $", не удалось {failed}" : ""));
        ApplyFilter();
    }

    /// <summary>Показывает, где именно лежит файл задачи и что такое «папка задачи».</summary>
    private void ShowTaskFile_Click(object sender, RoutedEventArgs e)
    {
        var rows = SelectedRows;
        if (rows.Count == 0) return;
        var text = string.Join("\n\n", rows.Select(t =>
            $"Задача: {t.Name}\nПапка задачи: {t.FolderPath}\nФайл: {(string.IsNullOrEmpty(t.TaskFile) ? TaskSchedulerService.TaskFilePath(t) : t.TaskFile)}"));
        MessageBox.Show(
            "Планировщик хранит каждое задание отдельным XML-файлом в C:\\Windows\\System32\\Tasks.\n" +
            "«Папка задачи» — это подкаталог внутри Tasks, он же путь задачи в планировщике.\n\n" + text,
            "Файл задачи", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    /// <summary>Объясняет красную подсветку строки без отдельного столбца «Вердикт».</summary>
    private void WhyMarked_Click(object sender, RoutedEventArgs e)
    {
        var rows = SelectedRows;
        if (rows.Count == 0) return;
        var lines = rows.Select(t =>
            $"• {t.FullPath} — {(t.Suspicious ? "подозрительная задача" : "признаков не найдено")}\n" +
            $"   {(string.IsNullOrWhiteSpace(t.Reasons) ? "—" : t.Reasons)}");
        MessageBox.Show(string.Join("\n\n", lines), "Почему помечено",
            MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void OpenXml_Click(object sender, RoutedEventArgs e)
    {
        var t = Selected;
        if (t == null) return;
        TaskSchedulerService.OpenTaskFile(t);
    }
}

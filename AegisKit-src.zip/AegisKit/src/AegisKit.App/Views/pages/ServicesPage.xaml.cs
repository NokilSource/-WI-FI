using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;
using AegisKit.Core.ServicesMan;

namespace AegisKit.App.Views.Pages;

public partial class ServicesPage : PageBase
{
    private readonly ObservableCollection<ServiceRow> _all = new();
    private List<ServiceRow> _source = new();
    private bool _busy;

    public ServicesPage()
    {
        InitializeComponent();
        Grid.ItemsSource = _all;
        DataContext = _all;
        GridLayout.Attach(Grid, "Services.Grid");
        Loaded += async (_, _) => await RefreshAsync();
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAsync();

    private async Task RefreshAsync()
    {
        if (_busy) return;
        _busy = true;
        RefreshBtn.IsEnabled = false;
        try
        {
            _source = await Task.Run(ServiceManager.Enumerate);
            // Подпись проверяем только у тех служб, где расположение файла уже вызывает
            // вопросы: сплошной WinVerifyTrust по 300 файлам на каждой загрузке — лишние секунды.
            await Task.Run(() =>
            {
                foreach (var s in _source)
                {
                    var probe = ServiceManager.EvaluateSuspicious(s);
                    if (probe.Count > 0 && !s.SignatureChecked) ServiceManager.VerifySignature(s);
                }
            });
            foreach (var s in _source) ApplyVerdict(s);
            SimpleLog.Info($"Служб: {_source.Count}" +
                           (_source.Count == 0 ? " — не удалось прочитать базу служб (нужны права администратора)" : ""));
            ApplyFilter();
        }
        finally
        {
            _busy = false;
            RefreshBtn.IsEnabled = true;
        }
    }

    /// <summary>Единая переоценка вердикта службы.</summary>
    private static void ApplyVerdict(ServiceRow s)
    {
        var reasons = ServiceManager.EvaluateSuspicious(s);
        s.Reasons = string.Join("; ", reasons);
        s.Suspicious = reasons.Count > 0;
    }

    private void ApplyFilter()
    {
        IEnumerable<ServiceRow> rows = _source;
        if (OnlySuspicious.IsChecked == true)
            rows = rows.Where(s => s.Suspicious);
        if (HideDrivers.IsChecked == true)
            rows = rows.Where(s => !s.IsDriver);
        string? search = SearchBox.Text?.Trim();
        if (!string.IsNullOrEmpty(search))
            rows = rows.Where(s =>
                s.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                s.DisplayName.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                s.Description.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                s.BinaryPath.Contains(search, StringComparison.OrdinalIgnoreCase));
        _all.Clear();
        foreach (var r in rows) _all.Add(r);
        SummaryText.Text = $"Показано: {_all.Count} · всего: {_source.Count} · " +
                           $"подозрительных: {_source.Count(s => s.Suspicious)}";
    }

    private void Filter_Changed(object sender, RoutedEventArgs e) => ApplyFilter();
    private void Search_Changed(object sender, System.Windows.Controls.TextChangedEventArgs e) => ApplyFilter();

    private ServiceRow? Selected => Grid.SelectedItem as ServiceRow;

    /// <summary>Все выделенные строки: действия применяются сразу к пачке служб.</summary>
    private List<ServiceRow> SelectedRows => Grid.SelectedItems.Cast<ServiceRow>().ToList();

    private async void Start_Click(object sender, RoutedEventArgs e)
    {
        var rows = SelectedRows;
        if (rows.Count == 0) return;
        SimpleLog.Info($"Запуск служб: {rows.Count}…");
        int done = 0;
        foreach (var s in rows)
        {
            if (await Task.Run(() => ServiceManager.Start(s.Name))) { RefreshRowState(s); done++; }
        }
        SimpleLog.Ok($"Запущено служб: {done} из {rows.Count}");
    }

    private async void Stop_Click(object sender, RoutedEventArgs e)
    {
        var rows = SelectedRows;
        if (rows.Count == 0) return;
        // Критичные для работы системы службы останавливать пачкой опаснее, чем по одной:
        // спрашиваем подтверждение и перечисляем, что именно будет остановлено.
        if (rows.Count > 1 && MessageBox.Show(
                $"Остановить выбранные службы ({rows.Count})?\n\n" +
                string.Join("\n", rows.Take(12).Select(r => "• " + r.Name)) +
                (rows.Count > 12 ? $"\n…и ещё {rows.Count - 12}" : ""),
                "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        SimpleLog.Info($"Остановка служб: {rows.Count}…");
        int done = 0;
        foreach (var s in rows)
        {
            if (await Task.Run(() => ServiceManager.Stop(s.Name))) { RefreshRowState(s); done++; }
        }
        SimpleLog.Ok($"Остановлено служб: {done} из {rows.Count}");
    }

    private void ChangeStartType_Click(object sender, RoutedEventArgs e)
    {
        var s = Selected;
        if (s == null) return;
        var menu = new ContextMenu
        {
            Items =
            {
                new MenuItem { Header = "Авто", Tag = NativeMethods.SERVICE_AUTO_START },
                new MenuItem { Header = "Авто (отложенный)", Tag = 98 },
                new MenuItem { Header = "Вручную", Tag = NativeMethods.SERVICE_DEMAND_START },
                new MenuItem { Header = "Отключена", Tag = NativeMethods.SERVICE_DISABLED }
            }
        };
        foreach (MenuItem mi in menu.Items)
            mi.Click += async (_, _) =>
            {
                int startType = (int)mi.Tag;
                if (startType == 98)
                {
                    // Отложенный автозапуск: настроить через реестр DelayedAutostart
                    await Task.Run(() =>
                    {
                        ServiceManager.SetStartType(s.Name, NativeMethods.SERVICE_AUTO_START);
                        try
                        {
                            using var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                                $@"SYSTEM\CurrentControlSet\Services\{s.Name}", true);
                            key?.SetValue("DelayedAutostart", 1, Microsoft.Win32.RegistryValueKind.DWord);
                            SimpleLog.Ok($"{s.Name}: отложенный автозапуск включён");
                        }
                        catch (Exception ex) { SimpleLog.Error($"DelayedAutostart: {ex.Message}"); }
                    });
                    return;
                }
                if (await Task.Run(() => ServiceManager.SetStartType(s.Name, startType)))
                {
                    s.StartType = startType;
                    RefreshRowState(s);
                }
            };
        menu.PlacementTarget = sender as Button;
        menu.IsOpen = true;
    }

    private void SetAuto_Click(object sender, RoutedEventArgs e) => ChangeType(NativeMethods.SERVICE_AUTO_START);
    private void SetManual_Click(object sender, RoutedEventArgs e) => ChangeType(NativeMethods.SERVICE_DEMAND_START);
    private void SetDisabled_Click(object sender, RoutedEventArgs e) => ChangeType(NativeMethods.SERVICE_DISABLED);

    private void ChangeType(int type)
    {
        var s = Selected;
        if (s == null) return;
        _ = ChangeTypeAsync(s, type);
    }

    private async Task ChangeTypeAsync(ServiceRow s, int type)
    {
        if (await Task.Run(() => ServiceManager.SetStartType(s.Name, type)))
        {
            s.StartType = type;
            RefreshRowState(s);
        }
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        var rows = SelectedRows;
        if (rows.Count == 0) return;
        var question = rows.Count == 1
            ? $"Удалить службу «{rows[0].Name}» ({rows[0].DisplayName})?\n" +
              "Служба будет помечена к удалению (физически исчезнет после перезагрузки)."
            : $"Удалить выбранные службы ({rows.Count})?\n\n" +
              string.Join("\n", rows.Take(12).Select(r => $"• {r.Name}")) +
              (rows.Count > 12 ? $"\n…и ещё {rows.Count - 12}" : "") +
              "\n\nСлужбы будут помечены к удалению (исчезнут после перезагрузки).";
        if (MessageBox.Show(question, "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning)
            != MessageBoxResult.Yes) return;

        int done = 0;
        foreach (var s in rows)
        {
            if (await Task.Run(() => ServiceManager.Delete(s.Name)))
            {
                _source.Remove(s);
                _all.Remove(s);
                done++;
            }
        }
        SimpleLog.Info($"Удаление служб: помечено {done} из {rows.Count}");
    }

    private void OpenFolder_Click(object sender, RoutedEventArgs e)
    {
        var s = Selected;
        if (s == null || string.IsNullOrEmpty(s.BinaryPath)) return;
        var exe = ServiceManager.ExtractExe(s.BinaryPath);
        if (!string.IsNullOrEmpty(exe)) NativeMethods.ShowInExplorer(exe);
    }

    private async void VerifyOne_Click(object sender, RoutedEventArgs e)
    {
        var s = Selected;
        if (s == null || string.IsNullOrEmpty(s.BinaryPath)) return;
        var exe = ServiceManager.ExtractExe(s.BinaryPath);
        if (string.IsNullOrEmpty(exe) || !File.Exists(exe))
        {
            SimpleLog.Warn($"{s.Name}: двоичный файл не найден ({exe})");
            return;
        }
        await Task.Run(() => ServiceManager.VerifySignature(s));
        ApplyVerdict(s);
        SimpleLog.Info($"{s.Name} → {exe}: {(s.Signed ? "подпись действительна" : "действительной подписи нет")}" +
                       (s.Reasons.Length > 0 ? " · " + s.Reasons : ""));
        RefreshRowState(s);
    }

    private async void RefreshRowState(ServiceRow s)
    {
        await Task.Delay(700);
        var fresh = (await Task.Run(ServiceManager.Enumerate))
            .FirstOrDefault(x => x.Name == s.Name);
        if (fresh == null) return;
        fresh.SignatureChecked = s.SignatureChecked;
        fresh.Signed = s.Signed;
        ApplyVerdict(fresh);
        var idx = _all.IndexOf(s);
        if (idx >= 0) { _all[idx] = fresh; }
        var srcIdx = _source.FindIndex(x => x.Name == s.Name);
        if (srcIdx >= 0) _source[srcIdx] = fresh;
    }
}

using System.Windows;
using AegisKit.Core.Logging;
using AegisKit.Core.SystemOps;

namespace AegisKit.App.Views.Pages;

public partial class SystemPage : PageBase
{
    public SystemPage()
    {
        InitializeComponent();
        EnvInfo.Text = $"{Core.SystemInfo.WindowsVersion}\n" +
                       $"Компьютер: {Core.SystemInfo.ComputerName}   Пользователь: {Core.SystemInfo.UserName}\n" +
                       $"Права администратора: {(Core.SystemInfo.IsElevated ? "ДА" : "НЕТ")}" +
                       (Core.SystemInfo.IsWinRE ? "\nСреда: WinRE/WinPE" : "");
    }

    private bool Confirm(string msg)
    {
        return MessageBox.Show(msg, "AegisKit", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
    }

    private void SafeMode_Click(object sender, RoutedEventArgs e)
    {
        if (!Confirm("Включить безопасный режим при следующей загрузке?"))
            return;
        BootActions.EnableSafeMode(withNetwork: false);
    }

    private void SafeModeNet_Click(object sender, RoutedEventArgs e)
    {
        if (!Confirm("Включить безопасный режим С СЕТЬЮ при следующей загрузке?"))
            return;
        BootActions.EnableSafeMode(withNetwork: true);
    }

    private void NormalBoot_Click(object sender, RoutedEventArgs e)
    {
        BootActions.DisableSafeMode();
    }

    private void Winre_Click(object sender, RoutedEventArgs e)
    {
        if (!Confirm("Перезагрузить компьютер в среду восстановления (WinRE)?\nРабота будет завершена немедленно."))
            return;
        BootActions.RebootToWinre();
    }

    private void Uefi_Click(object sender, RoutedEventArgs e)
    {
        if (!Confirm("Перезагрузить компьютер в UEFI/BIOS?\nРаботает только на системах, установленных в UEFI-режиме."))
            return;
        BootActions.RebootToUefi();
    }

    private void Reboot_Click(object sender, RoutedEventArgs e)
    {
        if (!Confirm("Перезагрузить компьютер сейчас?")) return;
        BootActions.RebootNow();
    }

    private void Shutdown_Click(object sender, RoutedEventArgs e)
    {
        if (!Confirm("Завершить работу компьютера?")) return;
        BootActions.ShutdownNow();
    }

    private void DiskMgmt_Click(object sender, RoutedEventArgs e) => BootActions.OpenDiskManagement();
    private void TaskMgr_Click(object sender, RoutedEventArgs e) => BootActions.OpenTaskManager();
    private void Msconfig_Click(object sender, RoutedEventArgs e) => BootActions.OpenMsconfig();
    private void Msinfo_Click(object sender, RoutedEventArgs e) => BootActions.OpenSystemInfo();
    private void Update_Click(object sender, RoutedEventArgs e) => BootActions.OpenWindowsUpdate();
    private void Defender_Click(object sender, RoutedEventArgs e) => BootActions.OpenDefender();

    private void ReAgentInfo_Click(object sender, RoutedEventArgs e)
    {
        SimpleLog.Command("reagentc /info");
        Task.Run(() =>
        {
            try
            {
                var psi = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "reagentc.exe",
                    Arguments = "/info",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true,
                    // reagentc локализован и пишет в OEM-кодировке консоли (cp866)
                    StandardOutputEncoding = Core.Compat.CodePages.Oem
                };
                var p = System.Diagnostics.Process.Start(psi)!;
                var output = p.StandardOutput.ReadToEnd();
                p.WaitForExit(15000);
                foreach (var line in output.Split('\n', StringSplitOptions.RemoveEmptyEntries))
                    SimpleLog.Info("   " + line.TrimEnd());
            }
            catch (Exception ex)
            {
                SimpleLog.Error($"reagentc: {ex.Message}");
            }
        });
    }
}

namespace AegisKit.Core;

/// <summary>Название и версия продукта — единый источник для заголовков и журнала.</summary>
public static class AppInfo
{
    public const string Name = "AegisKit";
    public const string Version = "1.2";
    public const string FullName = Name + " " + Version;
}

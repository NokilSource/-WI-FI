using System.Text.Json;

namespace AegisKit.Core;

/// <summary>
/// Небольшие настройки интерфейса, переживающие перезапуск:
/// окно «поверх всех», нижняя панель журнала, геометрия окна и
/// ширины столбцов таблиц (ключ вида «Processes.Grid.Имя»).
/// Файл лежит рядом с профилем пользователя, а в WinRE — в %TEMP%.
/// </summary>
public static class AppSettings
{
    private static readonly object Gate = new();
    private static SettingsData _data = new();
    private static bool _loaded;

    /// <summary>Версия формата настроек: растёт, когда старые значения надо пересчитать.</summary>
    public const int CurrentVersion = 2;

    public sealed class SettingsData
    {
        public int Version { get; set; }
        public bool Topmost { get; set; }
        public bool JournalVisible { get; set; } = true;
        public double JournalHeight { get; set; } = 170;
        public double WindowWidth { get; set; } = 1280;
        public double WindowHeight { get; set; } = 820;
        public bool WindowMaximized { get; set; }
        public bool ShowAllTaskFolders { get; set; }
        public List<string> RecoverySelection { get; set; } = new();
        public Dictionary<string, double> ColumnWidths { get; set; } = new();
    }

    public static string Path { get; } = BuildPath();

    private static string BuildPath()
    {
        try
        {
            var root = SystemInfo.IsWinRE
                ? System.IO.Path.GetTempPath()
                : Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var dir = System.IO.Path.Combine(root, "AegisKit");
            System.IO.Directory.CreateDirectory(dir);
            return System.IO.Path.Combine(dir, "settings.json");
        }
        catch
        {
            return System.IO.Path.Combine(System.IO.Path.GetTempPath(), "AegisKit-settings.json");
        }
    }

    private static SettingsData Data
    {
        get
        {
            lock (Gate)
            {
                if (!_loaded) Load_NoLock();
                return _data;
            }
        }
    }

    private static void Load_NoLock()
    {
        _loaded = true;
        try
        {
            if (File.Exists(Path))
                _data = JsonSerializer.Deserialize<SettingsData>(File.ReadAllText(Path)) ?? new SettingsData();
        }
        catch
        {
            _data = new SettingsData();
        }

        // Миграция: в первых сборках ширина столбцов сохранялась при любом пересчёте
        // раскладки, поэтому в файле могли оказаться случайные значения (например,
        // «Расположение» шире, чем в XAML). Один раз сбрасываем их — дальше ширина
        // пишется только при реальном перетаскивании мышью.
        if (_data.Version < CurrentVersion)
        {
            _data.ColumnWidths.Clear();
            _data.Version = CurrentVersion;
        }
    }

    public static bool Topmost
    {
        get => Data.Topmost;
        set { Data.Topmost = value; Save(); }
    }

    public static bool JournalVisible
    {
        get => Data.JournalVisible;
        set { Data.JournalVisible = value; Save(); }
    }

    public static double JournalHeight
    {
        get => Data.JournalHeight;
        set { Data.JournalHeight = Math.Clamp(value, 90, 600); Save(); }
    }

    public static double WindowWidth
    {
        get => Data.WindowWidth;
        set { Data.WindowWidth = value; Save(); }
    }

    public static double WindowHeight
    {
        get => Data.WindowHeight;
        set { Data.WindowHeight = value; Save(); }
    }

    public static bool WindowMaximized
    {
        get => Data.WindowMaximized;
        set { Data.WindowMaximized = value; Save(); }
    }

    public static bool ShowAllTaskFolders
    {
        get => Data.ShowAllTaskFolders;
        set { Data.ShowAllTaskFolders = value; Save(); }
    }

    public static List<string> RecoverySelection
    {
        get => Data.RecoverySelection;
        set { Data.RecoverySelection = value; Save(); }
    }

    public static double? GetColumnWidth(string key)
    {
        var d = Data;
        return d.ColumnWidths.TryGetValue(key, out var w) && w > 20 ? w : null;
    }

    /// <summary>Сохраняет ширину столбца только при заметном изменении — чтобы не писать файл на каждый пиксель.</summary>
    public static void SetColumnWidth(string key, double width)
    {
        if (width < 20) return;
        var d = Data;
        if (d.ColumnWidths.TryGetValue(key, out var old) && Math.Abs(old - width) < 2) return;
        d.ColumnWidths[key] = width;
        Save();
    }

    public static void Save()
    {
        lock (Gate)
        {
            try
            {
                File.WriteAllText(Path, JsonSerializer.Serialize(_data,
                    new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { /* настройки не критичны */ }
        }
    }
}

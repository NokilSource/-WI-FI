using Microsoft.Win32;
using System.Diagnostics;
using AegisKit.Core.Logging;
using AegisKit.Core.Processes;
using AegisKit.Core.RegOps;

namespace AegisKit.Core.Autostart;

public enum AutostartKind
{
    RunKey, RunOnceKey, Winlogon, BootExecute, CmdAutoRun, PolicyRun, StartupFolder,
    AppInit, IfeoDebugger, LsaPackage, WinlogonNotify, ServiceDll, CmdLine
}

/// <summary>
/// Категория для вкладок интерфейса. Названия намеренно короткие и прикладные —
/// «Run / RunOnce», «Winlogon / Shell» и т.д., без расплывчатых формулировок.
/// </summary>
public static class AutostartCategory
{
    public const string Run = "Run / RunOnce";
    public const string Shell = "Winlogon / Shell";
    public const string Hooks = "AppInit / CmdLine / Перехваты";
    public const string Folders = "Папки автозагрузки";

    public static string Of(AutostartKind kind) => kind switch
    {
        AutostartKind.RunKey or AutostartKind.RunOnceKey or AutostartKind.PolicyRun
            or AutostartKind.CmdAutoRun => Run,
        AutostartKind.StartupFolder => Folders,
        AutostartKind.Winlogon or AutostartKind.WinlogonNotify or AutostartKind.BootExecute => Shell,
        _ => Hooks
    };
}

/// <summary>Одна запись автозапуска.</summary>
public class AutostartEntry
{
    public AutostartKind Kind { get; set; }
    public string Location { get; set; } = "";
    public string RegHive { get; set; } = "";
    public string RegKey { get; set; } = "";
    public string ValueName { get; set; } = "";
    /// <summary>Реальное имя параметра реестра, если ValueName — понятное пользователю имя.</summary>
    public string? ValueKey { get; set; }
    public string Command { get; set; } = "";
    public string ResolvedPath { get; set; } = "";
    public string Company { get; set; } = "";
    public bool Signed { get; set; }
    public bool SignatureChecked { get; set; }
    public bool Suspicious { get; set; }
    public string Reasons { get; set; } = "";
    public bool IsFileItem { get; set; }

    /// <summary>
    /// Когда запись появилась или была изменена: время последней записи ключа
    /// реестра либо дата создания файла в папке автозагрузки.
    /// </summary>
    public DateTime? AddedAt { get; set; }

    /// <summary>Дата в виде «26.09.2026 17:14»; пустая строка, если данных нет.</summary>
    public string AddedText => AddedAt is { } d ? d.ToString("dd.MM.yyyy HH:mm") : "";

    /// <summary>
    /// Запись относится к системной точке входа (Winlogon, BootExecute, IFEO,
    /// AppInit, LSA, Winlogon\Notify, ServiceDll) и её значение отличается от
    /// эталонного. Такие строки выделяются красным — это изменённая система.
    /// </summary>
    public bool Modified { get; set; }

    /// <summary>Строку надо подсветить как подозрительную или изменённую.</summary>
    public bool Marked => Suspicious || Modified;

    /// <summary>Эталонное значение для восстановления (Shell/Userinit/BootExecute/LSA).</summary>
    public string? Reference { get; set; }

    public string Verdict => Suspicious ? "Подозрительно"
        : Modified ? "Изменено"
        : SignatureChecked && !Signed ? "Без подписи" : "";
    public string SignatureText => !SignatureChecked ? "" : (Signed ? "подписана" : "нет");
    /// <summary>Алиас для общего стиля VerdictCell (ToolTip с причинами).</summary>
    public string SuspiciousReasons => Reasons;

    public override string ToString() => $"{Location} :: {ValueName} = {Command}";
}

/// <summary>
/// Аудит автозапуска: HKLM/HKCU Run/RunOnce (+Wow6432Node), политики Run,
/// Winlogon (Shell, Userinit, Taskman, AppSetup, UIHost), BootExecute,
/// AutoRun командного процессора, папки Startup, AppInit_DLLs, перехваты
/// IFEO Debugger, LSA Notification Packages и Winlogon Notify.
/// </summary>
public static class AutorunScanner
{
    public static string UserStartupFolder =>
        Environment.GetFolderPath(Environment.SpecialFolder.Startup);

    public static string CommonStartupFolder =>
        Environment.ExpandEnvironmentVariables(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup));

    private static readonly string[] ExecutableExts =
        { ".exe", ".com", ".bat", ".cmd", ".vbs", ".vbe", ".js", ".jse", ".ps1", ".wsf", ".scr", ".hta", ".pif", ".lnk" };

    private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string RunOnceKeyPath = @"Software\Microsoft\Windows\CurrentVersion\RunOnce";
    private const string RunOnceExKeyPath = @"Software\Microsoft\Windows\CurrentVersion\RunOnceEx";
    private const string PolicyRunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run";
    private const string WinlogonKeyPath = @"Software\Microsoft\Windows NT\CurrentVersion\Winlogon";
    private const string SessionManagerKeyPath = @"SYSTEM\CurrentControlSet\Control\Session Manager";
    private const string CommandProcessorKeyPath = @"Software\Microsoft\Command Processor";
    private const string AppInitKeyPath = @"Software\Microsoft\Windows NT\CurrentVersion\Windows";
    private const string AppInitKeyPathWow = @"Software\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Windows";
    private const string IfeoKeyPath = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options";
    private const string IfeoKeyPathWow = @"SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Image File Execution Options";
    private const string LsaKeyPath = @"SYSTEM\CurrentControlSet\Control\Lsa";
    private const string NotifyKeyPath = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Notify";
    private const string ServicesKeyPath = @"SYSTEM\CurrentControlSet\Services";

    public static List<AutostartEntry> Scan(bool includeWow64 = true)
    {
        var list = new List<AutostartEntry>();
        var hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
        var hkcu = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64);

        foreach (var (hive, bk) in new[] { ("HKLM", hklm), ("HKCU", hkcu) })
        {
            ReadValues(hive, bk, RunKeyPath, AutostartKind.RunKey, list);
            ReadValues(hive, bk, RunOnceKeyPath, AutostartKind.RunOnceKey, list);
            ReadValues(hive, bk, RunOnceExKeyPath, AutostartKind.RunOnceKey, list);
            ReadValues(hive, bk, PolicyRunKeyPath, AutostartKind.PolicyRun, list);
            ReadValues(hive, bk, CommandProcessorKeyPath, AutostartKind.CmdAutoRun, list, onlyNames: new[] { "AutoRun" });
        }

        if (includeWow64)
        {
            ReadValues("HKLM", hklm, @"Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Run",
                AutostartKind.RunKey, list);
            ReadValues("HKLM", hklm, @"Software\Wow6432Node\Microsoft\Windows\CurrentVersion\RunOnce",
                AutostartKind.RunOnceKey, list);
        }

        ReadWinlogon(hklm, list);
        ReadBootExecute(hklm, list);
        ReadSetupCmdLine(hklm, list);
        ReadAppInit(hklm, AppInitKeyPath, "HKLM (64-бит)", list);
        if (includeWow64) ReadAppInit(hklm, AppInitKeyPathWow, "HKLM (32-бит, Wow6432Node)", list);
        ReadIfeo(hklm, IfeoKeyPath, list);
        if (includeWow64) ReadIfeo(hklm, IfeoKeyPathWow, list);
        ReadLsaPackages(hklm, list);
        ReadWinlogonNotify(hklm, list, includeWow64);
        ReadHijackedServices(hklm, list);

        ScanStartupFolder(UserStartupFolder, "Папка автозагрузки (пользователь)", list);
        ScanStartupFolder(CommonStartupFolder, "Папка автозагрузки (все пользователи)", list);

        foreach (var e in list) EvaluateOne(e);
        return list.OrderBy(e => AutostartCategory.Of(e.Kind))
                   .ThenBy(e => e.Location)
                   .ThenBy(e => e.ValueName)
                   .ToList();
    }

    // ---------- Чтение источников ----------

    /// <summary>Время последней записи ключа — «когда запись автозапуска появилась».</summary>
    private static DateTime? KeyTime(string hive, string keyPath) =>
        RegistryTimestamps.ForPath($"{hive}\\{keyPath}");

    private static void ReadValues(string hive, RegistryKey baseKey, string keyPath,
        AutostartKind kind, List<AutostartEntry> list, string[]? onlyNames = null)
    {
        var added = KeyTime(hive, keyPath);
        try
        {
            using var key = baseKey.OpenSubKey(keyPath);
            if (key == null) return;
            foreach (var name in key.GetValueNames())
            {
                if (onlyNames != null && !onlyNames.Contains(name, StringComparer.OrdinalIgnoreCase)) continue;
                var data = key.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                if (data is null) continue;
                var command = data switch
                {
                    string s => s,
                    string[] arr => string.Join(" ", arr),
                    _ => data.ToString() ?? ""
                };
                if (command.Length == 0) continue;

                list.Add(new AutostartEntry
                {
                    Kind = kind,
                    Location = $"{hive}\\{keyPath}",
                    RegHive = hive,
                    RegKey = keyPath,
                    ValueName = name.Length == 0 ? "(По умолчанию)" : name,
                    Command = command,
                    ResolvedPath = ExtractExecutable(command),
                    AddedAt = added
                });
            }
        }
        catch (Exception ex) { SimpleLog.Warn($"Автозапуск {hive}\\{keyPath}: {ex.Message}"); }
    }

    private static void ReadWinlogon(RegistryKey hklm, List<AutostartEntry> list)
    {
        string[] names = { "Shell", "Userinit", "Taskman", "AppSetup", "UIHost" };
        var added = KeyTime("HKLM", WinlogonKeyPath);
        try
        {
            using var key = hklm.OpenSubKey(WinlogonKeyPath);
            if (key == null) return;
            foreach (var v in names)
            {
                var data = key.GetValue(v)?.ToString();
                if (string.IsNullOrEmpty(data)) continue;
                list.Add(new AutostartEntry
                {
                    Kind = AutostartKind.Winlogon,
                    Location = $"HKLM\\{WinlogonKeyPath}",
                    RegHive = "HKLM",
                    RegKey = WinlogonKeyPath,
                    ValueName = v,
                    Command = data,
                    ResolvedPath = ExtractExecutable(data),
                    AddedAt = added,
                    Reference = v switch
                    {
                        "Shell" => "explorer.exe",
                        "Userinit" => "userinit.exe,",
                        "UIHost" => "logonui.exe",
                        _ => null
                    }
                });
            }
        }
        catch (Exception ex) { SimpleLog.Warn($"Winlogon: {ex.Message}"); }
    }

    private static void ReadBootExecute(RegistryKey hklm, List<AutostartEntry> list)
    {
        var added = KeyTime("HKLM", SessionManagerKeyPath);
        try
        {
            using var key = hklm.OpenSubKey(SessionManagerKeyPath);
            var raw = key?.GetValue("BootExecute");
            string data = raw switch
            {
                string s => s,
                string[] arr => string.Join(" ", arr),
                _ => raw?.ToString() ?? ""
            };
            if (data.Length == 0) return;
            list.Add(new AutostartEntry
            {
                Kind = AutostartKind.BootExecute,
                Location = $"HKLM\\{SessionManagerKeyPath} (BootExecute)",
                RegHive = "HKLM",
                RegKey = SessionManagerKeyPath,
                ValueName = "BootExecute",
                Command = data,
                ResolvedPath = ExtractExecutable(data),
                AddedAt = added,
                Reference = "autocheck autochk *"
            });
        }
        catch (Exception ex) { SimpleLog.Warn($"BootExecute: {ex.Message}"); }
    }

    /// <summary>
    /// CmdLine из Session Manager\Setup: команда, которую Windows выполняет при
    /// следующей загрузке. Используется вредоносным ПО и «оптимизаторами» для
    /// запуска своего кода до входа пользователя.
    /// </summary>
    private static void ReadSetupCmdLine(RegistryKey hklm, List<AutostartEntry> list)
    {
        const string setupPath = @"SYSTEM\CurrentControlSet\Control\Session Manager\Setup";
        var added = KeyTime("HKLM", setupPath);
        try
        {
            using var key = hklm.OpenSubKey(setupPath);
            if (key == null) return;
            // Показываем только CmdLine: SetupType — это служебное число состояния
            // установки, в списке автозапуска оно выглядело мусором и подсвечивалось красным.
            foreach (var name in new[] { "CmdLine" })
            {
                var data = key.GetValue(name)?.ToString();
                if (string.IsNullOrEmpty(data)) continue;
                list.Add(new AutostartEntry
                {
                    Kind = AutostartKind.CmdLine,
                    Location = $"HKLM\\{setupPath}",
                    RegHive = "HKLM",
                    RegKey = setupPath,
                    ValueName = name,
                    ValueKey = name,
                    Command = data,
                    ResolvedPath = ExtractExecutable(data),
                    AddedAt = added
                });
            }
        }
        catch (Exception ex) { SimpleLog.Warn($"Setup CmdLine: {ex.Message}"); }
    }

    /// <summary>AppInit_DLLs: классическая точка загрузки DLL в каждый процесс.</summary>
    private static void ReadAppInit(RegistryKey hklm, string keyPath, string label, List<AutostartEntry> list)
    {
        var added = KeyTime("HKLM", keyPath);
        try
        {
            using var key = hklm.OpenSubKey(keyPath);
            if (key == null) return;
            var dlls = key.GetValue("AppInit_DLLs")?.ToString() ?? "";
            var enabled = key.GetValue("LoadAppInit_DLLs");
            bool on = enabled switch
            {
                int i => i != 0,
                string s => s != "0" && s.Length > 0,
                _ => false
            };
            foreach (var dll in dlls.Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var path = Environment.ExpandEnvironmentVariables(dll.Trim());
                list.Add(new AutostartEntry
                {
                    Kind = AutostartKind.AppInit,
                    Location = $"HKLM\\{keyPath} ({label})",
                    RegHive = "HKLM",
                    RegKey = keyPath,
                    ValueName = "AppInit_DLLs",
                    Command = (on ? "" : "[LoadAppInit_DLLs=0] ") + dll,
                    ResolvedPath = path,
                    AddedAt = added,
                    Reference = null
                });
            }
        }
        catch (Exception ex) { SimpleLog.Warn($"AppInit {keyPath}: {ex.Message}"); }
    }

    /// <summary>IFEO Debugger: перехват запуска программ (используется малварью и «стики-кис»).</summary>
    private static void ReadIfeo(RegistryKey hklm, string keyPath, List<AutostartEntry> list)
    {
        var added = KeyTime("HKLM", keyPath);
        try
        {
            using var ifeo = hklm.OpenSubKey(keyPath);
            if (ifeo == null) return;
            foreach (var sub in ifeo.GetSubKeyNames())
            {
                using var k = ifeo.OpenSubKey(sub);
                var dbg = k?.GetValue("Debugger")?.ToString();
                if (string.IsNullOrEmpty(dbg)) continue;
                list.Add(new AutostartEntry
                {
                    Kind = AutostartKind.IfeoDebugger,
                    Location = $"HKLM\\{keyPath}\\{sub}",
                    RegHive = "HKLM",
                    RegKey = $@"{keyPath}\{sub}",
                    ValueName = sub,
                    ValueKey = "Debugger",
                    Command = dbg,
                    ResolvedPath = ExtractExecutable(dbg),
                    AddedAt = added
                });
            }
        }
        catch (Exception ex) { SimpleLog.Warn($"IFEO {keyPath}: {ex.Message}"); }
    }

    /// <summary>LSA Notification Packages: загрузка DLL в lsass.exe — уровень ядра доверия.</summary>
    private static void ReadLsaPackages(RegistryKey hklm, List<AutostartEntry> list)
    {
        var added = KeyTime("HKLM", LsaKeyPath);
        try
        {
            using var key = hklm.OpenSubKey(LsaKeyPath);
            var raw = key?.GetValue("Notification Packages");
            var packages = raw switch
            {
                string[] arr => arr,
                string s => s.Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries),
                _ => Array.Empty<string>()
            };
            var system32 = Environment.GetFolderPath(Environment.SpecialFolder.System);
            foreach (var p in packages)
            {
                var name = p.Trim();
                if (name.Length == 0) continue;
                // Показываем сразу путь к DLL, а не голое «scecli = scecli»:
                // так видно, что именно загружается в lsass.
                var dllPath = Path.Combine(system32,
                    name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase) ? name : name + ".dll");
                list.Add(new AutostartEntry
                {
                    Kind = AutostartKind.LsaPackage,
                    Location = $"HKLM\\{LsaKeyPath} → Notification Packages",
                    RegHive = "HKLM",
                    RegKey = LsaKeyPath,
                    ValueName = name,
                    ValueKey = "Notification Packages",
                    Command = dllPath,
                    ResolvedPath = dllPath,
                    AddedAt = added,
                    Reference = "scecli"
                });
            }
        }
        catch (Exception ex) { SimpleLog.Warn($"LSA Notification Packages: {ex.Message}"); }
    }

    private static void ReadWinlogonNotify(RegistryKey hklm, List<AutostartEntry> list, bool includeWow64)
    {
        var paths = includeWow64
            ? new[] { NotifyKeyPath, @"SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Winlogon\Notify" }
            : new[] { NotifyKeyPath };
        foreach (var basePath in paths)
        {
            try
            {
                using var notify = hklm.OpenSubKey(basePath);
                if (notify == null) continue;
                foreach (var sub in notify.GetSubKeyNames())
                {
                    using var k = notify.OpenSubKey(sub);
                    var dll = k?.GetValue("DllName")?.ToString();
                    if (string.IsNullOrEmpty(dll)) continue;
                    var resolved = Environment.ExpandEnvironmentVariables(dll.Trim());
                    // Имя без пути (например «scecli») разворачиваем в System32: иначе
                    // в таблице было бессмысленное «scecli = scecli» без адреса файла.
                    if (!resolved.Contains('\\'))
                    {
                        var system32 = Environment.GetFolderPath(Environment.SpecialFolder.System);
                        if (!resolved.EndsWith(".dll", StringComparison.OrdinalIgnoreCase)) resolved += ".dll";
                        resolved = Path.Combine(system32, resolved);
                    }
                    list.Add(new AutostartEntry
                    {
                        Kind = AutostartKind.WinlogonNotify,
                        Location = $"HKLM\\{basePath} → {sub}",
                        RegHive = "HKLM",
                        RegKey = $@"{basePath}\{sub}",
                        ValueName = sub,
                        ValueKey = "DllName",
                        Command = resolved,
                        ResolvedPath = resolved,
                        AddedAt = KeyTime("HKLM", @$"{basePath}\{sub}")
                    });
                }
            }
            catch (Exception ex) { SimpleLog.Warn($"Winlogon Notify {basePath}: {ex.Message}"); }
        }
    }

    /// <summary>
    /// ServiceDll служб, работающих в svchost, из пользовательских/временных каталогов —
    /// распространённый способ закрепиться через уже существующую службу.
    /// </summary>
    private static void ReadHijackedServices(RegistryKey hklm, List<AutostartEntry> list)
    {
        try
        {
            using var services = hklm.OpenSubKey(ServicesKeyPath);
            if (services == null) return;
            foreach (var svc in services.GetSubKeyNames())
            {
                try
                {
                    using var k = services.OpenSubKey(svc);
                    using var p = k?.OpenSubKey("Parameters");
                    var dll = p?.GetValue("ServiceDll")?.ToString();
                    if (string.IsNullOrEmpty(dll)) continue;
                    var path = Environment.ExpandEnvironmentVariables(dll.Trim('"'));
                    // Только заведомо нетипичные для служб места: временный каталог и загрузки
                    var loc = SuspicionRules.ClassifyLocation(path);
                    if (loc is not (SuspicionRules.LocTemp or SuspicionRules.LocDownload)) continue;
                    list.Add(new AutostartEntry
                    {
                        Kind = AutostartKind.ServiceDll,
                        Location = $"HKLM\\{ServicesKeyPath}\\{svc}\\Parameters",
                        RegHive = "HKLM",
                    RegKey = $@"{ServicesKeyPath}\{svc}\Parameters",                    ValueName = svc,
                    ValueKey = "ServiceDll",
                    Command = dll,
                    ResolvedPath = path,
                    AddedAt = KeyTime("HKLM", $"{ServicesKeyPath}\\{svc}\\Parameters")
                });
                }
                catch { }
            }
        }
        catch (Exception ex) { SimpleLog.Warn($"ServiceDll: {ex.Message}"); }
    }

    private static void ScanStartupFolder(string folder, string location, List<AutostartEntry> list)
    {
        if (!Directory.Exists(folder)) return;
        try
        {
            foreach (var f in Directory.EnumerateFiles(folder))
            {
                var ext = Path.GetExtension(f);
                if (!ExecutableExts.Contains(ext, StringComparer.OrdinalIgnoreCase)) continue;
                string target = f;
                if (ext.Equals(".lnk", StringComparison.OrdinalIgnoreCase))
                {
                    var resolved = ResolveShortcut(f);
                    if (!string.IsNullOrEmpty(resolved)) target = resolved;
                }
                list.Add(new AutostartEntry
                {
                    Kind = AutostartKind.StartupFolder,
                    Location = location,
                    ValueName = Path.GetFileName(f),
                    Command = f,
                    ResolvedPath = target,
                    IsFileItem = true,
                    // Для ярлыка в папке автозагрузки «когда появился» — это дата
                    // создания самого файла ярлыка.
                    AddedAt = SafeCreationTime(f)
                });
            }
        }
        catch (Exception ex) { SimpleLog.Warn($"{location}: {ex.Message}"); }
    }

    private static DateTime? SafeCreationTime(string path)
    {
        try { return File.GetCreationTime(path); }
        catch { return null; }
    }

    /// <summary>Чтение цели ярлыка .lnk через WScript.Shell COM.</summary>
    public static string ResolveShortcut(string lnkPath)
    {
        try
        {
            var type = Type.GetTypeFromProgID("WScript.Shell");
            if (type == null) return "";
            dynamic? shell = Activator.CreateInstance(type);
            try
            {
                dynamic? shortcut = shell!.CreateShortcut(lnkPath);
                return (string?)shortcut?.TargetPath ?? "";
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(shell!);
            }
        }
        catch { return ""; }
    }

    // ---------- Эвристика ----------

    public static void Reevaluate(AutostartEntry e) => EvaluateOne(e);

    /// <summary>
    /// Пересчитывает вердикт записи. Метаданные файла и подпись учитываются ВСЕГДА,
    /// а не только когда структурных замечаний ещё нет: иначе ложное «Файл не найден»
    /// никогда не снималось бы после проверки подписи.
    /// </summary>
    private static void EvaluateOne(AutostartEntry e)
    {
        var strong = new List<string>();
        var weak = new List<string>();

        switch (e.Kind)
        {
            case AutostartKind.Winlogon:
            {
                var normalized = e.Command.Trim().TrimEnd(',').Trim();
                var exeName = GetExeName(normalized);
                if (e.ValueName == "Shell" && !exeName.Equals("explorer.exe", StringComparison.OrdinalIgnoreCase))
                    strong.Add("Нестандартная оболочка (Shell)");
                if (e.ValueName == "Userinit" && !exeName.Equals("userinit.exe", StringComparison.OrdinalIgnoreCase))
                    strong.Add("Нестандартный Userinit");
                if (e.ValueName == "UIHost" && !exeName.Equals("logonui.exe", StringComparison.OrdinalIgnoreCase))
                    strong.Add("Нестандартный UIHost");
                if (e.ValueName is "Taskman" or "AppSetup" && normalized.Length > 0)
                    strong.Add($"Параметр Winlogon {e.ValueName} задан — устаревший способ перехвата входа");
                break;
            }
            case AutostartKind.BootExecute:
            {
                var normalized = e.Command.Replace("\0", " ").Trim();
                if (!normalized.Equals("autocheck autochk *", StringComparison.OrdinalIgnoreCase) &&
                    !normalized.Equals("autocheck autochk*", StringComparison.OrdinalIgnoreCase))
                    strong.Add("Модифицированный BootExecute");
                break;
            }
            case AutostartKind.IfeoDebugger:
            {
                // Легитимное использование: отладчики из Windows Kits и Application Verifier.
                var p = e.Command.ToLowerInvariant();
                if (!p.Contains("vsjitdebugger") && !p.Contains("application verifier"))
                    strong.Add("Перехват запуска программы через IFEO Debugger");
                if (!File.Exists(e.ResolvedPath) && !e.ResolvedPath.Contains('%'))
                    strong.Add("Отладчик не найден на диске");
                break;
            }
            case AutostartKind.AppInit:
            {
                bool disabled = e.Command.StartsWith("[LoadAppInit_DLLs=0]", StringComparison.Ordinal);
                if (disabled)
                    weak.Add("AppInit_DLLs присутствует, но LoadAppInit_DLLs=0 (загрузка отключена)");
                else
                    strong.Add("AppInit_DLLs: DLL загружается в адресное пространство всех процессов");
                if (!File.Exists(e.ResolvedPath) && !e.ResolvedPath.Contains('%'))
                    strong.Add("DLL из AppInit_DLLs не найдена на диске");
                break;
            }
            case AutostartKind.LsaPackage:
            {
                if (!File.Exists(e.ResolvedPath))
                    strong.Add("Пакет LSA не найден в System32 (возможна подмена)");
                var name = Path.GetFileName(e.Command);
                if (!name.Equals("scecli", StringComparison.OrdinalIgnoreCase) &&
                    !name.Equals("rassfm", StringComparison.OrdinalIgnoreCase) &&
                    !name.Equals("nefssas", StringComparison.OrdinalIgnoreCase) &&
                    !name.Equals("pku2u", StringComparison.OrdinalIgnoreCase))
                    weak.Add($"Нестандартный пакет LSA ({name}) — убедитесь, что это ваше ПО");
                break;
            }
            case AutostartKind.WinlogonNotify:
            {
                // Сам по себе Notify — штатный (и устаревший) механизм Windows:
                // scecli и pgpsmmsg грузятся самим lsass. Тревожно только то,
                // что DLL лежит вне System32 или отсутствует.
                if (!File.Exists(e.ResolvedPath) && !e.ResolvedPath.Contains('%'))
                    strong.Add("DLL из Winlogon\\Notify не найдена на диске");
                else
                {
                    var sys32 = Environment.GetFolderPath(Environment.SpecialFolder.System);
                    if (!e.ResolvedPath.StartsWith(sys32, StringComparison.OrdinalIgnoreCase))
                        strong.Add("Winlogon\\Notify загружает DLL вне System32");
                }
                break;
            }
            case AutostartKind.CmdLine:
                strong.Add("Команда из Session Manager\\Setup выполнится при следующей загрузке");
                break;
            case AutostartKind.ServiceDll:
                strong.Add("ServiceDll службы указывает в пользовательский/временный каталог");
                break;
            case AutostartKind.StartupFolder:
                if (!string.IsNullOrEmpty(e.ResolvedPath) && !File.Exists(e.ResolvedPath))
                    weak.Add("Цель ярлыка не найдена");
                if (!string.IsNullOrEmpty(e.ResolvedPath) &&
                    SuspicionRules.ClassifyLocation(e.ResolvedPath) == SuspicionRules.LocTemp)
                    strong.Add("Автозагрузка ведёт во временный каталог");
                break;
            default:
                if (string.IsNullOrEmpty(e.ResolvedPath))
                {
                    if (e.Command.Length > 0) weak.Add("Команду не удалось разобрать на путь к файлу");
                }
                else if (!File.Exists(e.ResolvedPath) && !e.ResolvedPath.Contains('%'))
                {
                    strong.Add("Файл команды не найден на диске");
                }
                break;
        }

        // Общие проверки по файлу: маскировка, двойное расширение, скрипт-хост, расположение
        if (!string.IsNullOrEmpty(e.ResolvedPath) && File.Exists(e.ResolvedPath))
        {
            try
            {
                if (string.IsNullOrEmpty(e.Company))
                    e.Company = FileVersionInfo.GetVersionInfo(e.ResolvedPath).CompanyName ?? "";
            }
            catch { }

            var signals = SuspicionRules.Analyze(e.ResolvedPath, e.Company, e.SignatureChecked, e.Signed, e.Command);
            foreach (var s in signals)
            {
                if (s.Strength == SignalStrength.Strong) strong.Add(s.Text);
                else weak.Add(s.Text);
            }
        }

        var all = strong.Concat(weak.Select(w => w + " (слабый признак)")).ToList();
        e.Reasons = string.Join("; ", all);
        e.Suspicious = strong.Count > 0;

        // Системные точки входа: любое отклонение от эталона — это изменённая система,
        // даже если признак формально «слабый» (например нестандартный пакет LSA).
        bool systemEntryPoint = e.Kind is AutostartKind.Winlogon or AutostartKind.BootExecute
            or AutostartKind.IfeoDebugger or AutostartKind.AppInit or AutostartKind.LsaPackage
            or AutostartKind.WinlogonNotify or AutostartKind.ServiceDll or AutostartKind.CmdLine;
        e.Modified = systemEntryPoint && (strong.Count > 0 || weak.Count > 0);
    }

    // ---------- Разбор командной строки ----------

    /// <summary>Имя exe из команды (без пути и аргументов) для сравнения с эталоном.</summary>
    private static string GetExeName(string command)
    {
        var exe = ExtractExecutable(command);
        var name = Path.GetFileName(exe);
        return string.IsNullOrEmpty(name) ? command.Trim().Trim('"').Trim() : name;
    }

    /// <summary>
    /// Извлекает путь к исполняемому файлу из строки запуска. Голые имена (explorer.exe)
    /// разворачиваются в системные пути, хвосты «,» после userinit отбрасываются. Пути без
    /// кавычек с пробелами разбираются жадно — по самому длинному существующему префиксу.
    /// </summary>
    public static string ExtractExecutable(string? command)
    {
        if (string.IsNullOrWhiteSpace(command)) return "";
        var c = command.Trim().TrimEnd(',').Trim();

        if (c.StartsWith('"'))
        {
            int end = c.IndexOf('"', 1);
            if (end > 0) return Normalize(c[1..end]);
        }

        var expanded = Environment.ExpandEnvironmentVariables(c);

        var greedy = LongestExistingExePrefix(expanded);
        if (!string.IsNullOrEmpty(greedy)) return greedy;

        int space = expanded.IndexOf(' ');
        var token = (space > 0 ? expanded[..space] : expanded).TrimEnd(',', ';');

        if (token.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && token.Contains('\\'))
            return token;

        if (space > 0)
        {
            var rest = expanded[(space + 1)..];
            var second = rest.Split(' ')[0].TrimEnd(',', ';');
            if (second.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
                return second;
        }

        return Normalize(token);
    }

    /// <summary>
    /// Ищет самый длинный префикс команды, который существует на диске как exe/com/bat/cmd.
    /// Покрывает незакавыченные пути с пробелами вида C:\Program Files\Vendor\app.exe --flag.
    /// </summary>
    private static string LongestExistingExePrefix(string expanded)
    {
        try
        {
            var c = expanded;
            foreach (var wrapper in new[] { "rundll32.exe", "regsvr32.exe", "cmd.exe", "powershell.exe", "/c", "/k", "-c" })
            {
                if (c.StartsWith(wrapper, StringComparison.OrdinalIgnoreCase))
                    c = c[wrapper.Length..].TrimStart();
                else if (c.StartsWith('"' + wrapper, StringComparison.OrdinalIgnoreCase))
                {
                    int q = c.IndexOf('"', 1);
                    if (q > 0) c = c[(q + 1)..].TrimStart();
                }
            }

            int maxLen = -1;
            string best = "";
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] != ' ') continue;
                var candidate = c[..i].Trim().Trim('"').TrimEnd(',', ';');
                if (candidate.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ||
                    candidate.EndsWith(".com", StringComparison.OrdinalIgnoreCase) ||
                    candidate.EndsWith(".bat", StringComparison.OrdinalIgnoreCase) ||
                    candidate.EndsWith(".cmd", StringComparison.OrdinalIgnoreCase) ||
                    candidate.EndsWith(".scr", StringComparison.OrdinalIgnoreCase))
                {
                    if (candidate.Length > maxLen && File.Exists(candidate))
                    {
                        maxLen = candidate.Length;
                        best = candidate;
                    }
                }
            }
            var whole = c.Trim().Trim('"').TrimEnd(',', ';');
            if (whole.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && File.Exists(whole))
                return whole;
            return best;
        }
        catch { return ""; }
    }

    /// <summary>Голые имена системных утилит → полный путь (для проверки существования).</summary>
    private static string Normalize(string path)
    {
        var p = path.Trim();
        if (p.Length == 0 || p.Contains('\\') || p.Contains('%')) return p;
        var name = Path.GetFileName(p);
        if (!name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) &&
            !name.EndsWith(".com", StringComparison.OrdinalIgnoreCase)) return p;
        string[] bases =
        {
            Environment.GetFolderPath(Environment.SpecialFolder.System),
            Environment.GetFolderPath(Environment.SpecialFolder.Windows),
            Environment.GetFolderPath(Environment.SpecialFolder.SystemX86),
        };
        foreach (var b in bases)
        {
            var full = Path.Combine(b, name);
            if (File.Exists(full)) return full;
        }
        return p;
    }

    // ---------- Управление записями ----------

    public static bool DeleteEntry(AutostartEntry e)
    {
        try
        {
            if (e.IsFileItem || e.Kind == AutostartKind.StartupFolder)
            {
                File.Delete(e.Command);
                SimpleLog.Ok($"Удалён файл автозагрузки: {e.Command}");
                return true;
            }

            if (e.Kind == AutostartKind.LsaPackage)
            {
                SimpleLog.Warn("Notification Packages нельзя удалить отдельным элементом: " +
                               "отредактируйте значение через встроенный редактор реестра.");
                return false;
            }

            using var baseKey = e.RegHive == "HKLM"
                ? RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64)
                : RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64);

            if (e.Kind == AutostartKind.BootExecute)
            {
                using var k = baseKey.OpenSubKey(e.RegKey, true);
                if (k == null) { SimpleLog.Error($"Ключ не найден: {e.RegKey}"); return false; }
                k.SetValue("BootExecute", "autocheck autochk *");
                SimpleLog.Ok("BootExecute восстановлен (autocheck autochk *)");
                return true;
            }

            using var key = baseKey.OpenSubKey(e.RegKey, true);
            if (key == null) { SimpleLog.Error($"Ключ не найден: {e.RegKey}"); return false; }

            var valueKey = e.ValueKey ?? e.ValueName;
            var name = valueKey == "(По умолчанию)" ? "" : valueKey;
            if (e.Reference != null && e.ValueKey == null)
            {
                key.SetValue(e.ValueName, e.Reference);
                SimpleLog.Ok($"{e.ValueName} восстановлен: {e.Reference}");
                return true;
            }
            if (e.Kind == AutostartKind.AppInit)
            {
                // LoadAppInit_DLLs=0 безопаснее удаления значения: отключает весь механизм
                key.SetValue("LoadAppInit_DLLs", 0, RegistryValueKind.DWord);
                key.DeleteValue("AppInit_DLLs", false);
                SimpleLog.Ok("AppInit_DLLs удалён, LoadAppInit_DLLs=0");
                return true;
            }

            key.DeleteValue(name, false);
            SimpleLog.Ok($"Удалено: {e.RegHive}\\{e.RegKey}\\{valueKey}");
            return true;
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"Удаление автозапуска: {ex.Message}");
            return false;
        }
    }

    public static bool EditEntry(AutostartEntry e, string newValue)
    {
        try
        {
            using var baseKey = e.RegHive == "HKLM"
                ? RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64)
                : RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64);
            using var key = baseKey.OpenSubKey(e.RegKey, true);
            if (key == null) { SimpleLog.Error($"Ключ не найден: {e.RegKey}"); return false; }
            var valueKey = e.ValueKey ?? e.ValueName;
            var name = valueKey == "(По умолчанию)" ? "" : valueKey;
            key.SetValue(name, newValue, RegistryValueKind.String);
            SimpleLog.Ok($"Изменено: {e.ValueName} = {newValue}");
            return true;
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"Правка автозапуска: {ex.Message}");
            return false;
        }
    }
}

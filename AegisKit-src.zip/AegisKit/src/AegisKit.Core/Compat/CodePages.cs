using System.Text;

namespace AegisKit.Core.Compat;

/// <summary>
/// Доступ к OEM-кодировкам (cp866 и др.).
/// .NET Core/5+ не содержит их по умолчанию: без провайдера Encoding.GetEncoding(866)
/// выбрасывает NotSupportedException, из-за чего падал запуск sfc/dism (вывод
/// локализованных консольных утилит читался в кодировке консоли).
/// </summary>
public static class CodePages
{
    private static bool _registered;

    public static void Register()
    {
        if (_registered) return;
        _registered = true;
        try { Encoding.RegisterProvider(CodePagesEncodingProvider.Instance); }
        catch { /* останутся только UTF-кодировки — это не фатально */ }
    }

    /// <summary>Кодировка по номеру или null, если она недоступна.</summary>
    public static Encoding? TryGet(int codePage)
    {
        Register();
        try { return Encoding.GetEncoding(codePage); }
        catch { return null; }
    }

    /// <summary>OEM-кодировка консоли (cp866 для русской Windows) или null.</summary>
    public static Encoding? Oem
    {
        get
        {
            int cp;
            try { cp = System.Globalization.CultureInfo.CurrentCulture.TextInfo.OEMCodePage; }
            catch { cp = 866; }
            return TryGet(cp) ?? TryGet(866);
        }
    }
}

using System.Diagnostics;
using System.Runtime.InteropServices;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;

namespace AegisKit.Core.Files;

/// <summary>Пакетные файловые операции: копирование, перемещение, карантин, принудительное удаление.</summary>
public static class FileOperations
{
    /// <summary>Папка карантина рядом с программой.</summary>
    public static string QuarantineFolder
    {
        get
        {
            var dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Quarantine");
            Directory.CreateDirectory(dir);
            return dir;
        }
    }

    public static string ManifestPath => Path.Combine(QuarantineFolder, "manifest.txt");

    public static int CopyTo(IEnumerable<string> files, string destFolder, Action<string>? progress = null)
    {
        int ok = 0;
        Directory.CreateDirectory(destFolder);
        foreach (var f in files)
        {
            try
            {
                var dest = GetUniquePath(Path.Combine(destFolder, Path.GetFileName(f)));
                File.Copy(f, dest, true);
                SimpleLog.Info($"Скопирован: {f} → {dest}");
                ok++;
            }
            catch (Exception ex) { SimpleLog.Error($"Копирование {f}: {ex.Message}"); }
            progress?.Invoke(f);
        }
        return ok;
    }

    public static int MoveTo(IEnumerable<string> files, string destFolder, Action<string>? progress = null)
    {
        int ok = 0;
        Directory.CreateDirectory(destFolder);
        foreach (var f in files)
        {
            try
            {
                var dest = GetUniquePath(Path.Combine(destFolder, Path.GetFileName(f)));
                File.Move(f, dest, false);
                SimpleLog.Info($"Перемещён: {f} → {dest}");
                ok++;
            }
            catch (Exception ex) { SimpleLog.Error($"Перемещение {f}: {ex.Message}"); }
            progress?.Invoke(f);
        }
        return ok;
    }

    /// <summary>Карантин: перемещение в папку карантина + переименование в .vir + запись манифеста для восстановления.</summary>
    public static int Quarantine(IEnumerable<string> files, Action<string>? progress = null)
    {
        int ok = 0;
        foreach (var f in files)
        {
            try
            {
                var id = Guid.NewGuid().ToString("N")[..12];
                var qPath = Path.Combine(QuarantineFolder, id + ".vir");
                File.Move(f, qPath);
                File.SetAttributes(qPath, FileAttributes.Hidden);
                var line = $"{id}|{DateTime.Now:yyyy-MM-dd HH:mm:ss}|{f}";
                File.AppendAllText(ManifestPath, line + Environment.NewLine);
                SimpleLog.Ok($"Отправлен в карантин [{id}]: {f}");
                ok++;
            }
            catch (Exception ex) { SimpleLog.Error($"Карантин {f}: {ex.Message}"); }
            progress?.Invoke(f);
        }
        return ok;
    }

    /// <summary>Восстановление файла из карантина по идентификатору или исходному пути.</summary>
    public static List<string> GetQuarantineManifest()
    {
        if (!File.Exists(ManifestPath)) return new List<string>();
        return File.ReadAllLines(ManifestPath).Where(l => l.Length > 0).ToList();
    }

    public static bool RestoreFromQuarantine(string idOrOriginalPath)
    {
        try
        {
            foreach (var line in GetQuarantineManifest())
            {
                var parts = line.Split('|', 3);
                if (parts.Length < 3) continue;
                if (!parts[0].Equals(idOrOriginalPath, StringComparison.OrdinalIgnoreCase) &&
                    !parts[2].Equals(idOrOriginalPath, StringComparison.OrdinalIgnoreCase)) continue;

                var qPath = Path.Combine(QuarantineFolder, parts[0] + ".vir");
                if (!File.Exists(qPath)) { SimpleLog.Error($"Файл карантина не найден: {qPath}"); return false; }
                File.SetAttributes(qPath, FileAttributes.Normal);
                var dest = GetUniquePath(parts[2]);
                File.Move(qPath, dest);
                SimpleLog.Ok($"Восстановлен из карантина: {dest}");
                return true;
            }
            SimpleLog.Error($"В манифесте не найдено: {idOrOriginalPath}");
            return false;
        }
        catch (Exception ex) { SimpleLog.Error($"Восстановление: {ex.Message}"); return false; }
    }

    /// <summary>
    /// Принудительное удаление заблокированного файла: снимает ReadOnly, определяет
    /// блокирующие процессы через Restart Manager, завершает их и удаляет.
    /// Фолбэк — отложенное удаление при перезагрузке (MoveFileEx).
    /// </summary>
    public static bool ForceDelete(string file)
    {
        try
        {
            if (!File.Exists(file)) { SimpleLog.Warn($"Файл не существует: {file}"); return false; }
            File.SetAttributes(file, FileAttributes.Normal);

            if (TryDelete(file)) { SimpleLog.Ok($"Удалён: {file}"); return true; }

            var lockers = NativeMethods.GetFileLockers(file);
            if (lockers.Count > 0)
            {
                SimpleLog.Warn($"Файл блокируют PID: {string.Join(", ", lockers)} — завершение…");
                foreach (var pid in lockers)
                {
                    try { Process.GetProcessById(pid).Kill(); SimpleLog.Info($"Завершён блокирующий процесс PID {pid}"); }
                    catch { }
                }
                Thread.Sleep(500);
                if (TryDelete(file)) { SimpleLog.Ok($"Удалён после снятия блокировки: {file}"); return true; }
            }

            // Отложенное удаление (MOVEFILE_DELAY_UNTIL_REBOOT = 4)
            if (MoveFileEx(file, null, 4))
            {
                SimpleLog.Warn($"Файл будет удалён при перезагрузке: {file}");
                return true;
            }
            SimpleLog.Error($"Не удалось удалить: {file} ({NativeMethods.GetWin32Message(Marshal.GetLastWin32Error())})");
            return false;
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"ForceDelete {file}: {ex.Message}");
            return false;
        }
    }

    [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true,
        CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
    private static extern bool MoveFileEx(string existing, string? newFile, int flags);

    private static bool TryDelete(string file)
    {
        try { File.Delete(file); return !File.Exists(file); }
        catch
        {
            // Если это каталог — удаляем рекурсивно
            if (Directory.Exists(file))
            {
                try { Directory.Delete(file, true); return true; } catch { }
            }
            return false;
        }
    }

    private static string GetUniquePath(string path)
    {
        if (!File.Exists(path)) return path;
        var dir = Path.GetDirectoryName(path) ?? ".";
        var name = Path.GetFileNameWithoutExtension(path);
        var ext = Path.GetExtension(path);
        for (int i = 1; i < 1000; i++)
        {
            var candidate = Path.Combine(dir, $"{name} ({i}){ext}");
            if (!File.Exists(candidate)) return candidate;
        }
        return Path.Combine(dir, Guid.NewGuid() + ext);
    }
}

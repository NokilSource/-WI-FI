using System.Collections.Concurrent;
using AegisKit.Core.Logging;
using AegisKit.Core.Processes;

namespace AegisKit.Core.Files;

/// <summary>Результат сканирования недавних файлов.</summary>
public class RecentFileRow
{
    public string Path { get; set; } = "";
    public DateTime Created { get; set; }
    public DateTime Modified { get; set; }
    public long Size { get; set; }
    public string Extension => System.IO.Path.GetExtension(Path);
    public bool Suspicious { get; set; }
    /// <summary>Алиас для общей подсветки строк (красным).</summary>
    public bool Marked => Suspicious;
    public string Reasons { get; set; } = "";
    public string SizeText => Size >= 1 << 20 ? $"{Size / 1048576.0:F1} МБ" : $"{Size / 1024.0:F1} КБ";
}

/// <summary>
/// Эвристический анализ недавно созданных/изменённых файлов — отслеживание
/// активности малвари за заданный промежуток времени (в минутах).
/// </summary>
public static class RecentFilesScanner
{
    public static string[] DefaultRoots { get; } = new[]
    {
        Environment.GetEnvironmentVariable("TEMP") ?? "",
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp"),
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        Environment.GetEnvironmentVariable("ProgramData") ?? "",
        "C:\\Users\\Public",
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Tasks"),
        Environment.GetFolderPath(Environment.SpecialFolder.Startup),
    }.Where(r => !string.IsNullOrEmpty(r)).Distinct().ToArray();

    public static List<string> CommonLocations => new List<string>
    {
            Environment.GetEnvironmentVariable("TEMP") ?? "",
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp"),
            Path.Combine(Environment.GetEnvironmentVariable("ProgramData") ?? "C:\\ProgramData"),
            "C:\\Users\\Public",
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            Environment.GetFolderPath(Environment.SpecialFolder.Startup),
            Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup),
            "C:\\Windows\\Tasks",
            "C:\\Windows\\Prefetch",
        }.Where(Directory.Exists).Distinct().ToList();

    public static List<RecentFileRow> Scan(string[] roots, int minutes, Action<string>? progress = null,
        CancellationToken ct = default)
    {
        var deadline = DateTime.Now.AddMinutes(-minutes);
        var results = new ConcurrentBag<RecentFileRow>();
        // Сколько потоков каталогов читать параллельно: на SSD это ускоряет скан
        // в разы (одиночный обход LocalApplicationData занимал ~50 секунд).
        int workers = Math.Clamp(Environment.ProcessorCount - 1, 2, 8);
        var sw = System.Diagnostics.Stopwatch.StartNew();
        // Расширения, которые запускаются сами по себе
        var exeExts = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { ".exe", ".scr", ".com", ".pif", ".bat", ".cmd", ".vbs", ".vbe", ".ps1", ".js",
              ".jse", ".wsf", ".wsh", ".hta", ".msi", ".cpl", ".jar" };
        // Расширения-«полуфабрикаты»: сами по себе не запускаются, поэтому
        // обычная DLL во временной папке (сборщики, установщики) — не признак.
        var weakExts = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { ".dll", ".sys", ".lnk", ".url", ".ocx", ".cab" };

        // Ограничители против зависания на гигантских деревьях (LocalApplicationData и т.п.)
        const int maxDirs = 20000;
        const int maxFiles = 20000;

        var current = roots.Where(Directory.Exists).Distinct().ToList();
        int processed = 0;
        int fileCount = 0;
        progress?.Invoke($"Сканирование {current.Count} корней в {workers} потоков…");

        // Обход по «волнам»: каждый уровень читается параллельно. Раньше скан шёл
        // в один поток и на практике выглядел как зависание.
        while (current.Count > 0 && processed < maxDirs && fileCount < maxFiles)
        {
            ct.ThrowIfCancellationRequested();
            var next = new ConcurrentBag<string>();
            Parallel.ForEach(current,
                new ParallelOptions { MaxDegreeOfParallelism = workers, CancellationToken = ct },
                dir =>
                {
                    if (fileCount >= maxFiles) return;
                    try
                    {
                        foreach (var f in Directory.EnumerateFiles(dir))
                        {
                            if (fileCount >= maxFiles) break;
                            try
                            {
                                var fi = new FileInfo(f);
                                if (fi.LastWriteTime < deadline && fi.CreationTime < deadline) continue;
                                Interlocked.Increment(ref fileCount);
                                results.Add(BuildRow(fi, exeExts, weakExts));
                            }
                            catch { }
                        }
                        foreach (var sub in Directory.EnumerateDirectories(dir))
                        {
                            // Системные/гигантские каталоги пропускаем осознанно
                            var name = System.IO.Path.GetFileName(sub).ToLowerInvariant();
                            if (NoisyDirs.Contains(name)) continue;
                            next.Add(sub);
                        }
                    }
                    catch { }
                });
            processed += current.Count;
            current = next.ToList();
            progress?.Invoke($"Каталогов обработано: {processed}, файлов за окно: {fileCount}, {sw.Elapsed.TotalSeconds:F0} с…");
        }

        // В первую очередь подозрительные, затем самые свежие: иначе поток
        // журналов и баз приложений вытесняет из выборки самое интересное.
        var ordered = results.OrderByDescending(r => r.Suspicious)
                             .ThenByDescending(r => r.Modified)
                             .ToList();
        var list = ordered.Take(5000).ToList();
        progress?.Invoke($"Просканировано каталогов: {processed}, найдено файлов: {ordered.Count}");

        // Подписи проверяем только у уже помеченных файлов (не более 40):
        // массовый WinVerifyTrust по тысячам файлов превратил бы скан в минуты.
        var suspects = list.Where(r => r.Suspicious).Take(40).ToList();
        if (suspects.Count > 0)
        {
            System.Threading.Tasks.Parallel.ForEach(suspects,
                new System.Threading.Tasks.ParallelOptions { MaxDegreeOfParallelism = 4 }, r =>
                {
                    try
                    {
                        if (Native.NativeMethods.VerifyFileSignature(r.Path))
                        {
                            // Подпись действительна, а структурных признаков (маскировка,
                            // двойное расширение, автозагрузка) нет — снимаем обвинение.
                            // Иначе обычные файлы сборщиков и установщиков в Temp
                            // выглядят как «подозрительные».
                            if (!r.Reasons.Contains("маскиров")
                                && !r.Reasons.Contains("двойное расширение")
                                && !r.Reasons.Contains("автозагруз")
                                && !r.Reasons.Contains("скрытый"))
                            {
                                r.Suspicious = false;
                                r.Reasons += " — подпись действительна, признано безопасным";
                            }
                        }
                        else r.Reasons += "; нет действительной цифровой подписи";
                    }
                    catch { }
                });
        }
        return list;
    }

    private static readonly HashSet<string> NoisyDirs = new(StringComparer.OrdinalIgnoreCase)
    {
        "node_modules", "cache", "caches", "inetsrv", "servicing", "winsxs", "$recycle.bin",
        "softwaredistribution", "assembly", "driverstore", "package cache",
        "webcache", "cryptneturlcache"
    };

    /// <summary>Строит строку результата и расставляет эвристические признаки файла.</summary>
    private static RecentFileRow BuildRow(FileInfo fi, HashSet<string> exeExts, HashSet<string> weakExts)
    {
        var row = new RecentFileRow
        {
            Path = fi.FullName,
            Created = fi.CreationTime,
            Modified = fi.LastWriteTime,
            Size = fi.Length
        };
        if (exeExts.Contains(fi.Extension))
        {
            // Помечаем только по реальным признакам. Раньше каждый файл,
            // созданный внутри окна сканирования (то есть вообще все файлы
            // выборки), получал «создан за окно» — мусорный признак.
            var reasons = new List<string>();
            var lower = fi.FullName.ToLowerInvariant();
            if (lower.Contains("\\temp\\") || lower.Contains("\\tmp\\"))
                reasons.Add("исполняемый во временной папке");
            if (lower.Contains("\\public\\"))
                reasons.Add("исполняемый в общей папке Public");
            if (lower.Contains("\\startup\\") || lower.Contains("\\tasks\\") ||
                lower.Contains("\\prefetch\\"))
                reasons.Add("исполняемый в автозагрузке/задачах");
            if (fi.Attributes.HasFlag(FileAttributes.Hidden) ||
                fi.Attributes.HasFlag(FileAttributes.System))
                reasons.Add("скрытый/системный исполняемый файл");
            if (SuspicionRules.HasDoubleExtension(fi.FullName))
                reasons.Add("двойное расширение в имени");
            if (reasons.Count > 0)
            {
                row.Suspicious = true;
                row.Reasons = string.Join("; ", reasons);
            }
        }
        else if (weakExts.Contains(fi.Extension))
        {
            // Слабые расширения обвиняем только по сильным признакам места/маскировки
            var lower = fi.FullName.ToLowerInvariant();
            var reasons = new List<string>();
            if (lower.Contains("\\startup\\") || lower.Contains("\\tasks\\"))
                reasons.Add("файл в автозагрузке/задачах");
            if (SuspicionRules.HasDoubleExtension(fi.FullName))
                reasons.Add("двойное расширение в имени");
            if (fi.Attributes.HasFlag(FileAttributes.Hidden) && fi.Attributes.HasFlag(FileAttributes.System))
                reasons.Add("скрытый и системный файл");
            if (reasons.Count > 0)
            {
                row.Suspicious = true;
                row.Reasons = string.Join("; ", reasons);
            }
        }
        return row;
    }
}

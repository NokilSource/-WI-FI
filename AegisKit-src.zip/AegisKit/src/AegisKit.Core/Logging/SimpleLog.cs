using System.Collections.ObjectModel;
using System.Text;

namespace AegisKit.Core.Logging;

public enum LogLevel { Info, Success, Warning, Error, Command }

/// <summary>
/// Потокобезопасный журнал, отображаемый в UI, плюс индикатор хода выполнения.
/// Все изменения коллекции автоматически переносятся в UI-поток, захваченный
/// при старте приложения (иначе CollectionView падает).
/// </summary>
public static class SimpleLog
{
    private static readonly object Gate = new();
    private static readonly ObservableCollection<LogEntry> Entries = new();
    private static SynchronizationContext? _uiContext;

    /// <summary>Текущий прогресс: 0..100, либо null — «неизвестно/не активно».</summary>
    private static int? _progress;
    private static string _progressText = "";
    private static bool _busy;

    public static event Action? Changed;
    public static event Action? ProgressChanged;

    public sealed record LogEntry(DateTime Time, LogLevel Level, string Message);

    /// <summary>Захватить UI-контекст (вызывается один раз из UI-потока при старте).</summary>
    public static void CaptureUiContext()
    {
        if (_uiContext == null)
            _uiContext = SynchronizationContext.Current;
    }

    public static ObservableCollection<LogEntry> GetEntries()
    {
        lock (Gate) return Entries;
    }

    // ---------------- Ход выполнения ----------------

    public static bool IsBusy { get { lock (Gate) return _busy; } }
    public static int? Progress { get { lock (Gate) return _progress; } }
    public static string ProgressText { get { lock (Gate) return _progressText; } }

    /// <summary>Показывает ход операции. Значение вне 0..100 отображается бегунком.</summary>
    public static void SetProgress(int? percent, string text = "")
    {
        lock (Gate)
        {
            _progress = percent is null ? null : Math.Clamp(percent.Value, 0, 100);
            _progressText = text;
            _busy = true;
        }
        ProgressChanged?.Invoke();
    }

    public static void ClearProgress()
    {
        lock (Gate)
        {
            _progress = null;
            _progressText = "";
            _busy = false;
        }
        ProgressChanged?.Invoke();
    }

    /// <summary>Проводит операцию через журнал: начало, конец, сброс индикатора.</summary>
    public static void Run(string title, Action<Action<string>> work)
    {
        Info($"[ Начато ] {title}");
        SetProgress(null, title);
        var sw = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            work(line => Info(line));
            sw.Stop();
            Ok($"[ Готово  ] {title} ({sw.Elapsed.TotalSeconds:F1} с)");
        }
        catch (Exception ex)
        {
            sw.Stop();
            Error($"[ Ошибка  ] {title}: {ex.Message}");
        }
        finally
        {
            ClearProgress();
        }
    }

    // ---------------- Записи ----------------

    private static void AddInternal(LogEntry entry)
    {
        lock (Gate)
        {
            Entries.Add(entry);
            if (Entries.Count > 2000) Entries.RemoveAt(0);
        }
        Changed?.Invoke();
    }

    public static void Log(LogLevel level, string message)
    {
        var entry = new LogEntry(DateTime.Now, level, message);
        var ctx = _uiContext;
        if (ctx != null && SynchronizationContext.Current != ctx)
        {
            // из фонового потока — переносим в UI-поток
            ctx.Post(_ => AddInternal(entry), null);
        }
        else
        {
            AddInternal(entry);
        }
    }

    public static void Info(string m) => Log(LogLevel.Info, m);
    public static void Ok(string m) => Log(LogLevel.Success, m);
    public static void Warn(string m) => Log(LogLevel.Warning, m);
    public static void Error(string m) => Log(LogLevel.Error, m);
    public static void Command(string m) => Log(LogLevel.Command, m);

    public static void Clear()
    {
        lock (Gate) Entries.Clear();
        Changed?.Invoke();
    }

    public static string Export()
    {
        var sb = new StringBuilder();
        lock (Gate)
            foreach (var e in Entries)
                sb.AppendLine($"{e.Time:yyyy-MM-dd HH:mm:ss.fff} [{e.Level}] {e.Message}");
        return sb.ToString();
    }
}

/// <summary>
/// Разбор строк вывода sfc/dism в проценты. Утилиты печатают прогресс
/// по-разному («[==== 12.3% ====]», «[#########  23.7%  ]»), поэтому
/// процент ищется как первое число перед знаком «%».
/// </summary>
public static class ProgressParser
{
    public static int? PercentFrom(string? line)
    {
        if (string.IsNullOrEmpty(line)) return null;
        int idx = line.IndexOf('%');
        if (idx < 0) return null;
        int start = idx - 1;
        while (start >= 0 && (char.IsDigit(line[start]) || line[start] == '.' || line[start] == ',')) start--;
        var chunk = line[(start + 1)..idx].Replace(',', '.');
        if (chunk.Length == 0) return null;
        if (double.TryParse(chunk, System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out var value))
            return (int)Math.Round(value);
        return null;
    }

    /// <summary>Этапы DISM не выражаются в процентах — показываем их как подписи.</summary>
    public static bool IsMilestone(string? line) =>
        !string.IsNullOrEmpty(line) &&
        (line.Contains("Восстановление", StringComparison.OrdinalIgnoreCase) ||
         line.Contains("Проверка", StringComparison.OrdinalIgnoreCase) ||
         line.Contains("RestoreHealth", StringComparison.OrdinalIgnoreCase) ||
         line.Contains("Scanning", StringComparison.OrdinalIgnoreCase) ||
         line.Contains("Checking", StringComparison.OrdinalIgnoreCase));
}

using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;

namespace AegisKit.Core.Native;

/// <summary>Низкоуровневые вызовы Win32/NT для всех модулей AegisKit.</summary>
public static unsafe class NativeMethods
{
    public const uint PROCESS_TERMINATE = 0x0001;
    public const uint PROCESS_CREATE_THREAD = 0x0002;
    public const uint PROCESS_SET_SESSIONID = 0x0004;
    public const uint PROCESS_VM_OPERATION = 0x0008;
    public const uint PROCESS_VM_READ = 0x0010;
    public const uint PROCESS_VM_WRITE = 0x0020;
    public const uint PROCESS_DUP_HANDLE = 0x0040;
    public const uint PROCESS_CREATE_PROCESS = 0x0080;
    public const uint PROCESS_SET_QUOTA = 0x0100;
    public const uint PROCESS_SET_INFORMATION = 0x0200;
    public const uint PROCESS_QUERY_INFORMATION = 0x0400;
    public const uint PROCESS_SUSPEND_RESUME = 0x0800;
    public const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;

    public const int PROCESS_BREAK_ON_TERMINATION = 29;   // ProcessBreakOnTermination

    public const int SC_MANAGER_ALL_ACCESS = 0xF003F;
    public const int SC_MANAGER_CONNECT = 0x0001;
    public const int SC_MANAGER_CREATE_SERVICE = 0x0002;
    public const int SC_MANAGER_ENUMERATE_SERVICE = 0x0004;
    public const int SC_MANAGER_QUERY_LOCK_STATUS = 0x0010;
    public const int SERVICE_ALL_ACCESS = 0xF01FF;

    public const int SERVICE_KERNEL_DRIVER = 0x00000001;
    public const int SERVICE_FILE_SYSTEM_DRIVER = 0x00000002;
    public const int SERVICE_WIN32_OWN_PROCESS = 0x00000010;
    public const int SERVICE_WIN32_SHARE_PROCESS = 0x00000020;
    public const int SERVICE_INTERACTIVE_PROCESS = 0x00000100;

    public const int SERVICE_AUTO_START = 2;
    public const int SERVICE_BOOT_START = 0;
    public const int SERVICE_DEMAND_START = 3;
    public const int SERVICE_DISABLED = 4;
    public const int SERVICE_SYSTEM_START = 1;

    public const int SERVICE_RUNNING = 0x00000004;
    public const int SERVICE_STOPPED = 0x00000001;
    public const int SERVICE_START_PENDING = 0x00000002;
    public const int SERVICE_STOP_PENDING = 0x00000003;
    public const int SERVICE_PAUSE_PENDING = 0x00000006;
    public const int SERVICE_PAUSED = 0x00000007;

    public const int SERVICE_QUERY_CONFIG = 0x0001;
    public const int SERVICE_CHANGE_CONFIG = 0x0002;
    public const int SERVICE_QUERY_STATUS = 0x0004;
    public const int SERVICE_ENUMERATE_DEPENDENTS = 0x0008;
    public const int SERVICE_START = 0x0010;
    public const int SERVICE_STOP = 0x0020;
    public const int SERVICE_PAUSE_CONTINUE = 0x0040;
    public const int SERVICE_INTERROGATE = 0x0080;
    public const int DELETE = 0x00010000;

    public const int SERVICE_CONFIG_DESCRIPTION = 1;
    public const int SC_STATUS_PROCESS_INFO = 0;

    // ---------- Kernel32 ----------

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool CloseHandle(IntPtr handle);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool TerminateProcess(IntPtr hProcess, uint exitCode);

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool GetExitCodeProcess(IntPtr hProcess, out uint exitCode);

    /// <summary>Полный путь образа из хендла процесса (работает и без WMI).</summary>
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool QueryFullProcessImageNameW(
        IntPtr hProcess, uint flags, StringBuilder exeName, ref uint size);

    public static string? GetProcessImagePath(IntPtr hProcess)
    {
        try
        {
            uint size = 1024;
            var sb = new StringBuilder((int)size);
            if (!QueryFullProcessImageNameW(hProcess, 0, sb, ref size)) return null;
            return sb.ToString();
        }
        catch { return null; }
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool GetProcessTimes(IntPtr hProcess, out long creation,
        out long exit, out long kernel, out long user);

    /// <summary>Время создания процесса в UTC (для стабильного идентификатора PID+время).</summary>
    public static DateTime? GetProcessCreationTime(IntPtr hProcess)
    {
        try
        {
            if (!GetProcessTimes(hProcess, out long creation, out _, out _, out _)) return null;
            return DateTime.FromFileTimeUtc(creation);
        }
        catch { return null; }
    }

    // ---------- ntdll: сведения о процессе (без WMI) ----------

    public const int ProcessBasicInformation = 0;      // PROCESS_BASIC_INFORMATION
    public const int ProcessCommandLineInformation = 60; // UNICODE_STRING с командной строкой

    [DllImport("ntdll.dll")]
    public static extern int NtQueryInformationProcess(
        IntPtr processHandle, int infoClass, IntPtr info, uint length, out uint returnLength);

    [StructLayout(LayoutKind.Sequential)]
    public struct UNICODE_STRING
    {
        public ushort Length;
        public ushort MaximumLength;
        public IntPtr Buffer;
    }

    /// <summary>PROCESS_BASIC_INFORMATION в 64-битной раскладке (все поля по 8 байт).</summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct PROCESS_BASIC_INFORMATION
    {
        public IntPtr ExitStatus;
        public IntPtr PebBaseAddress;
        public IntPtr AffinityMask;
        public IntPtr BasePriority;
        public IntPtr UniqueProcessId;
        public IntPtr InheritedFromUniqueProcessId;
    }

    public static int GetParentProcessId(IntPtr hProcess)
    {
        try
        {
            int size = Marshal.SizeOf<PROCESS_BASIC_INFORMATION>();
            IntPtr buf = Marshal.AllocHGlobal(size);
            try
            {
                int st = NtQueryInformationProcess(hProcess, ProcessBasicInformation, buf, (uint)size, out _);
                if (st < 0) return 0;
                var pbi = Marshal.PtrToStructure<PROCESS_BASIC_INFORMATION>(buf);
                return pbi.InheritedFromUniqueProcessId.ToInt32();
            }
            finally { Marshal.FreeHGlobal(buf); }
        }
        catch { return 0; }
    }

    /// <summary>Командная строка процесса через NtQueryInformationProcess(60).</summary>
    public static string? GetProcessCommandLine(IntPtr hProcess)
    {
        try
        {
            uint needed = 0;
            // Первый вызов узнаём требуемый размер (ожидаем STATUS_INFO_LENGTH_MISMATCH)
            NtQueryInformationProcess(hProcess, ProcessCommandLineInformation, IntPtr.Zero, 0, out needed);
            if (needed == 0) return null;
            IntPtr buf = Marshal.AllocHGlobal((int)needed);
            try
            {
                int st = NtQueryInformationProcess(hProcess, ProcessCommandLineInformation, buf, needed, out _);
                if (st < 0) return null;
                var us = Marshal.PtrToStructure<UNICODE_STRING>(buf);
                if (us.Length == 0 || us.Buffer == IntPtr.Zero) return null;
                return Marshal.PtrToStringUni(us.Buffer, us.Length / 2);
            }
            finally { Marshal.FreeHGlobal(buf); }
        }
        catch { return null; }
    }

    // ---------- ntdll: suspend / resume / critical ----------

    private static readonly IntPtr Ntdll = GetModuleHandle("ntdll.dll");

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Ansi)]
    private static extern IntPtr GetModuleHandle(string name);

    private static T? GetNt<T>(string name) where T : Delegate
    {
        var p = GetProcAddress(Ntdll, name);
        return p == IntPtr.Zero ? null : Marshal.GetDelegateForFunctionPointer<T>(p);
    }

    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    public delegate int NtSuspendResume(IntPtr processHandle);

    private static readonly NtSuspendResume? NtSuspendProcess = GetNt<NtSuspendResume>("NtSuspendProcess");
    private static readonly NtSuspendResume? NtResumeProcess = GetNt<NtSuspendResume>("NtResumeProcess");

    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    public delegate int NtSetInformationProcessDelegate(
        IntPtr processHandle, int infoClass, void* info, int length);

    private static readonly NtSetInformationProcessDelegate? NtSetInformationProcess =
        GetNt<NtSetInformationProcessDelegate>("NtSetInformationProcess");

    public static bool SuspendProcess(IntPtr hProcess) =>
        NtSuspendProcess != null && NtSuspendProcess(hProcess) == 0;

    public static bool ResumeProcess(IntPtr hProcess) =>
        NtResumeProcess != null && NtResumeProcess(hProcess) == 0;

    /// <summary>Читает/устанавливает флаг критичности (ProcessBreakOnTermination).</summary>
    public static bool SetProcessCritical(IntPtr hProcess, bool critical)
    {
        if (NtSetInformationProcess == null) return false;
        uint value = critical ? 1u : 0u;
        return NtSetInformationProcess(hProcess, PROCESS_BREAK_ON_TERMINATION, &value, 4) == 0;
    }

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Ansi)]
    private static extern IntPtr GetProcAddress(IntPtr module, string name);

    // ---------- AdvApi32: привилегии ----------

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool LookupPrivilegeValue(string? system, string name, out LUID luid);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool AdjustTokenPrivileges(
        IntPtr token, bool disableAll,
        ref TOKEN_PRIVILEGES newState, int bufferLen,
        IntPtr prev, IntPtr returnLen);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern IntPtr GetCurrentProcess();

    public const uint TOKEN_ADJUST_PRIVILEGES = 0x0020;
    public const uint TOKEN_QUERY = 0x0008;
    public const int SE_PRIVILEGE_ENABLED = 0x00000002;

    [StructLayout(LayoutKind.Sequential)]
    public struct LUID
    {
        public uint LowPart;
        public int HighPart;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct TOKEN_PRIVILEGES
    {
        public int PrivilegeCount;
        public LUID Luid;
        public int Attributes;
    }

    /// <summary>Включает привилегию текущего процесса (SeDebug/SeBackup/SeRestore/SeShutdown...).</summary>
    public static bool EnablePrivilege(string privilege)
    {
        if (!LookupPrivilegeValue(null, privilege, out var luid)) return false;
        if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, out var token))
            return false;
        try
        {
            var tp = new TOKEN_PRIVILEGES { PrivilegeCount = 1, Luid = luid, Attributes = SE_PRIVILEGE_ENABLED };
            return AdjustTokenPrivileges(token, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
        }
        finally { CloseHandle(token); }
    }

    public static bool EnableDebugPrivilege() => EnablePrivilege("SeDebugPrivilege");
    public static void EnableBackupRestorePrivileges()
    {
        EnablePrivilege("SeBackupPrivilege");
        EnablePrivilege("SeRestorePrivilege");
        EnableDebugPrivilege();
    }

    // ---------- AdvApi32: автономные кусты (RegLoadKey / RegUnLoadKey) ----------

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern int RegLoadKey(UIntPtr hKey, string subKey, string file);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern int RegUnLoadKey(UIntPtr hKey, string subKey);

    public static readonly UIntPtr HKEY_LOCAL_MACHINE = new(0x80000002u);
    public static readonly UIntPtr HKEY_USERS = new(0x80000003u);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern int RegCreateKeyExW(UIntPtr hKey, string subKey, uint reserved,
        string? class_, uint options, uint samDesired, IntPtr securityAttributes,
        out UIntPtr resultKey, out uint disposition);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern int RegCloseKey(UIntPtr hKey);

    public const uint KEY_CREATE_SUB_KEY = 0x0004;
    public const uint KEY_READ = 0x20019;
    public const uint KEY_WRITE = 0x20006;

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern int RegDeleteKey(UIntPtr hKey, string subKey);

    // ---------- AdvApi32: Service Control Manager ----------

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern IntPtr OpenSCManager(string? machine, string? database, uint access);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool EnumServicesStatusEx(
        IntPtr scm, int infoLevel, int serviceType, int serviceState, IntPtr buffer,
        int bufSize, out int bytesNeeded, out int servicesReturned, out int resumeHandle,
        string? groupName);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern IntPtr OpenService(IntPtr scm, string name, uint access);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool CloseServiceHandle(IntPtr handle);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool QueryServiceStatusEx(
        IntPtr service, int infoLevel, ref SERVICE_STATUS_PROCESS buffer, int bufSize, out int bytesNeeded);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool QueryServiceConfig(
        IntPtr service, IntPtr buffer, int bufSize, out int bytesNeeded);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool QueryServiceConfig2(
        IntPtr service, int infoLevel, IntPtr buffer, int bufSize, out int bytesNeeded);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool ChangeServiceConfig(
        IntPtr service, int serviceType, int startType, int errorControl,
        string? binaryPath, string? loadOrderGroup, IntPtr tagId,
        string? dependencies, string? account, string? password, string? displayName);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool DeleteService(IntPtr service);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool StartService(IntPtr service, int argc, IntPtr argv);

    [DllImport("advapi32.dll", SetLastError = true)]
    public static extern bool ControlService(IntPtr service, int control, ref SERVICE_STATUS status);

    [StructLayout(LayoutKind.Sequential)]
    public struct SERVICE_STATUS_PROCESS
    {
        public int ServiceType;
        public int CurrentState;
        public int ControlsAccepted;
        public int Win32ExitCode;
        public int ServiceSpecificExitCode;
        public int CheckPoint;
        public int WaitHint;
        public int ProcessId;
        public int ServiceFlags;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SERVICE_STATUS
    {
        public int ServiceType;
        public int CurrentState;
        public int ControlsAccepted;
        public int Win32ExitCode;
        public int ServiceSpecificExitCode;
        public int CheckPoint;
        public int WaitHint;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct ENUM_SERVICE_STATUS_PROCESS
    {
        public string lpServiceName;
        public string lpDisplayName;
        public SERVICE_STATUS_PROCESS ServiceStatusProcess;
    }

    public const int SC_ENUM_PROCESS_INFO = 0;
    public const int SERVICE_STATE_ALL = 3;

    // ---------- Wintrust: проверка цифровой подписи (Authenticode) ----------

    public static readonly Guid WINTRUST_ACTION_GENERIC_VERIFY_V2 =
        new("00AAC56B-CD44-11D0-8CC2-00C04FC295EE");

    public const uint WTD_UI_NONE = 2;
    public const uint WTD_REVOKE_NONE = 0;
    public const uint WTD_CHOICE_FILE = 1;
    public const uint WTD_STATEACTION_VERIFY = 1;
    public const uint WTD_STATEACTION_CLOSE = 2;

    [StructLayout(LayoutKind.Sequential)]
    public struct WINTRUST_FILE_INFO
    {
        public uint cbStruct;
        public IntPtr pcwszFilePath;
        public IntPtr hFile;
        public IntPtr pgKnownSubject;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct WINTRUST_DATA
    {
        public uint cbStruct;
        public IntPtr pPolicyCallbackData;
        public IntPtr pSIPClientData;
        public uint dwUIChoice;
        public uint fdwRevocationChecks;
        public uint dwUnionChoice;
        public IntPtr pFile;
        public uint dwStateAction;
        public IntPtr hWVTStateData;
        public IntPtr pURL;
        public uint dwProvFlags;
        public uint dwUIContext;
        public IntPtr pSignatureSettings;
    }

    [DllImport("wintrust.dll", SetLastError = true)]
    public static extern uint WinVerifyTrust(IntPtr hwnd, ref Guid actionId, ref WINTRUST_DATA data);

    /// <summary>Проверяет Authenticode-подпись файла. true = подписан и доверенный.</summary>
    public static bool VerifyFileSignature(string filePath)
    {
        if (!File.Exists(filePath)) return false;
        try
        {
            var filePtr = Marshal.StringToHGlobalUni(filePath);
            try
            {
                var fi = new WINTRUST_FILE_INFO
                {
                    cbStruct = (uint)sizeof(WINTRUST_FILE_INFO),
                    pcwszFilePath = filePtr
                };
                var fiPtr = Marshal.AllocHGlobal(sizeof(WINTRUST_FILE_INFO));
                Marshal.StructureToPtr(fi, fiPtr, false);
                try
                {
                    var guid = WINTRUST_ACTION_GENERIC_VERIFY_V2;
                    var wd = new WINTRUST_DATA
                    {
                        cbStruct = (uint)sizeof(WINTRUST_DATA),
                        dwUIChoice = WTD_UI_NONE,
                        fdwRevocationChecks = WTD_REVOKE_NONE,
                        dwUnionChoice = WTD_CHOICE_FILE,
                        pFile = fiPtr,
                        dwStateAction = WTD_STATEACTION_VERIFY
                    };
                    uint status = WinVerifyTrust(IntPtr.Zero, ref guid, ref wd);
                    // Проверка успешно завершена — освободить состояние
                    wd.dwStateAction = WTD_STATEACTION_CLOSE;
                    WinVerifyTrust(IntPtr.Zero, ref guid, ref wd);
                    return status == 0; // TRUST_E_NOSIGNATURE / TRUST_E_SUBJECT_NOT_TRUSTED и т.д.
                }
                finally { Marshal.FreeHGlobal(fiPtr); }
            }
            finally { Marshal.FreeHGlobal(filePtr); }
        }
        catch { return false; }
    }

    // ---------- Restart Manager: поиск процессов, блокирующих файл ----------

    public const int RmSessionZero = 0;

    [DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)]
    private static extern int RmStartSession(out uint session, int flags, string sessionKey);

    [DllImport("rstrtmgr.dll")]
    private static extern int RmEndSession(uint session);

    [DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)]
    private static extern int RmRegisterResources(
        uint session, uint fileCount, string[] filePaths,
        uint appCount, IntPtr applications, uint serviceCount, string[]? serviceNames);

    [DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)]
    private static extern int RmGetList(
        uint session, out uint procInfoNeeded, ref uint procInfoCount,
        [In] [Out] RM_PROCESS_INFO[] processInfo, ref uint rebootReasons);

    [StructLayout(LayoutKind.Sequential)]
    public struct RM_UNIQUE_PROCESS
    {
        public int dwProcessId;
        public System.Runtime.InteropServices.ComTypes.FILETIME ProcessStartTime;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct RM_PROCESS_INFO
    {
        public RM_UNIQUE_PROCESS Process;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string strAppName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
        public string strServiceShortName;
        public int ApplicationType;
        public uint AppStatus;
        public uint TSSessionId;
        [MarshalAs(UnmanagedType.Bool)]
        public bool bRestartable;
    }

    /// <summary>Возвращает PID процессов, блокирующих файл.</summary>
    public static List<int> GetFileLockers(string filePath)
    {
        var result = new List<int>();
        try
        {
            int res = RmStartSession(out uint session, 0, Guid.NewGuid().ToString());
            if (res != 0) return result;
            try
            {
                string[] files = { filePath };
                res = RmRegisterResources(session, 1, files, 0, IntPtr.Zero, 0, null);
                if (res != 0) return result;
                uint count = 0;
                uint needed = 0;
                uint reasons = 0;
                res = RmGetList(session, out needed, ref count, Array.Empty<RM_PROCESS_INFO>(), ref reasons);
                if (needed == 0) return result;
                var info = new RM_PROCESS_INFO[needed];
                count = needed;
                res = RmGetList(session, out needed, ref count, info, ref reasons);
                if (res == 0)
                    for (int i = 0; i < count; i++)
                        result.Add(info[i].Process.dwProcessId);
            }
            finally { RmEndSession(session); }
        }
        catch { }
        return result;
    }

    // ---------- Разное ----------

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    public static extern IntPtr ILCreateFromPath(string path);

    [DllImport("shell32.dll")]
    public static extern void ILFree(IntPtr pidl);

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    public static extern int SHOpenFolderAndSelectItems(IntPtr pidl, uint cidl, IntPtr apidl, uint flags);

    public static void ShowInExplorer(string path)
    {
        try
        {
            var pidl = ILCreateFromPath(path);
            if (pidl != IntPtr.Zero)
            {
                SHOpenFolderAndSelectItems(pidl, 0, IntPtr.Zero, 0);
                ILFree(pidl);
            }
        }
        catch
        {
            try { System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{path}\""); } catch { }
        }
    }

    public static string GetWin32Message(int error)
    {
        try { return new Win32Exception(error).Message; }
        catch { return $"Ошибка {error}"; }
    }
}

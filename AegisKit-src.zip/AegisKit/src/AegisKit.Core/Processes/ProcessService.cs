using System.Diagnostics;
using System.Management;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;

namespace AegisKit.Core.Processes;

/// <summary>Информация о процессе для таблицы.</summary>
public class ProcessRow
{
    public int Pid { get; set; }
    public int ParentPid { get; set; }
    public string Name { get; set; } = "";
    public string Company { get; set; } = "";
    public string Description { get; set; } = "";
    public string Path { get; set; } = "";
    public string CommandLine { get; set; } = "";
    public bool IsCritical { get; set; }
    public bool Signed { get; set; }
    public bool SignatureChecked { get; set; }
    public bool IsSuspended { get; set; }
    public string LocationClass => SuspicionRules.ClassifyLocation(string.IsNullOrEmpty(Path) ? null : Path);
    public bool Suspicious { get; set; }
    public string SuspiciousReasons { get; set; } = "";
    public long WorkingSet { get; set; }
    public int Threads { get; set; }
    public bool Responding { get; set; } = true;
    /// <summary>Время создания (UTC) — защита от подмены PID при операциях.</summary>
    public DateTime CreationTimeUtc { get; set; }
    public bool IsSystem => Pid <= 4;

    /// <summary>Стабильный идентификатор: PID сам по себе переиспользуется системой.</summary>
    public string Uid => CreationTimeUtc == default ? $"process:{Pid}" : $"process:{Pid}:{CreationTimeUtc.Ticks}";

    public string StateText => IsSuspended ? "Заморожен" : (Responding ? "Работает" : "Не отвечает");
    /// <summary>Подозрительно (сильные признаки) / Без подписи (слабые) / пусто.</summary>
    public string Verdict => Suspicious ? "Подозрительно" : SignatureChecked && !Signed ? "Без подписи" : "";

    /// <summary>Алиас для общей подсветки строк (красным).</summary>
    public bool Marked => Suspicious;
    public string MemoryText => WorkingSet >= 1L << 30
        ? $"{WorkingSet / 1073741824.0:F2} ГБ"
        : $"{WorkingSet / 1048576.0:F1} МБ";
}

/// <summary>Диспетчер процессов: перечисление, обогащение и управление.</summary>
public static class ProcessService
{
    /// <summary>
    /// Полный снимок процессов: путь, командная строка, родитель, время создания,
    /// флаг критичности, издатель и эвристика.
    /// Основной путь — WinAPI/NtAPI (быстро, десятки миллисекунд); WMI используется
    /// только если нативное чтение недоступно (иначе снимок занимал до 8 секунд).
    /// </summary>
    public static List<ProcessRow> Snapshot()
    {
        var result = new List<ProcessRow>();

        int withPath = 0, withCommandLine = 0;
        var processes = new List<Process>();
        try { processes.AddRange(Process.GetProcesses()); } catch { }

        foreach (var p in processes)
        {
            var row = new ProcessRow { Pid = p.Id };
            try { row.Name = p.ProcessName + ".exe"; } catch { }
            try { row.WorkingSet = p.WorkingSet64; } catch { }
            try { row.Threads = p.Threads.Count; } catch { }
            try { row.Responding = p.Responding; } catch { }
            p.Dispose();

            var h = NativeMethods.OpenProcess(
                NativeMethods.PROCESS_QUERY_LIMITED_INFORMATION, false, row.Pid);
            if (h != IntPtr.Zero)
            {
                try
                {
                    var path = NativeMethods.GetProcessImagePath(h);
                    if (!string.IsNullOrEmpty(path)) { row.Path = path; withPath++; }

                    var cmd = NativeMethods.GetProcessCommandLine(h);
                    if (string.IsNullOrEmpty(cmd))
                    {
                        // Часть процессов отдаёт командную строку только с VM_READ
                        NativeMethods.CloseHandle(h);
                        h = IntPtr.Zero;
                        var h2 = NativeMethods.OpenProcess(
                            NativeMethods.PROCESS_QUERY_LIMITED_INFORMATION | NativeMethods.PROCESS_VM_READ,
                            false, row.Pid);
                        if (h2 != IntPtr.Zero)
                        {
                            try { cmd = NativeMethods.GetProcessCommandLine(h2); }
                            finally { NativeMethods.CloseHandle(h2); }
                        }
                    }
                    if (!string.IsNullOrEmpty(cmd)) { row.CommandLine = cmd; withCommandLine++; }

                    if (h != IntPtr.Zero)
                    {
                        row.ParentPid = NativeMethods.GetParentProcessId(h);
                        var created = NativeMethods.GetProcessCreationTime(h);
                        if (created.HasValue) row.CreationTimeUtc = created.Value;
                        row.IsCritical = ReadCriticalFlag(h);
                    }
                }
                finally { if (h != IntPtr.Zero) NativeMethods.CloseHandle(h); }
            }

            result.Add(row);
        }

        // Фолбэк: если нативный путь систематически не работает (ограниченные права,
        // недоступная ntdll), добираем данные через WMI — медленно, но почти всегда доступно.
        if (result.Count > 0 && withPath < result.Count / 2)
        {
            SimpleLog.Warn("Нативное чтение списка процессов недоступно — используется WMI (медленно).");
            var wmi = QueryWmiProcesses();
            foreach (var row in result)
            {
                if (!wmi.TryGetValue(row.Pid, out var info)) continue;
                if (string.IsNullOrEmpty(row.Path) && !string.IsNullOrEmpty(info.path)) row.Path = info.path;
                if (string.IsNullOrEmpty(row.CommandLine) && !string.IsNullOrEmpty(info.cmd)) row.CommandLine = info.cmd;
                if (row.ParentPid == 0) row.ParentPid = info.parent;
            }
        }

        // Издатель и описание — параллельно: последовательный FileVersionInfo на 300 файлов
        // заметно тормозил первый показ таблицы.
        Parallel.ForEach(result.Where(r => !string.IsNullOrEmpty(r.Path)),
            new ParallelOptions { MaxDegreeOfParallelism = 4 }, row =>
            {
                try
                {
                    var vi = FileVersionInfo.GetVersionInfo(row.Path);
                    row.Company = vi.CompanyName ?? "";
                    row.Description = vi.FileDescription ?? "";
                }
                catch { }
            });

        // Первичный вердикт по дешёвым признакам. Проверка подписей — отдельный проход
        // (VerifySuspectSignatures): он занимает секунды и не задерживает показ списка.
        foreach (var row in result) Evaluate(row);
        SimpleLog.Info($"Процессов: {result.Count}, путь определён у {withPath}, " +
                       $"командная строка — у {withCommandLine}");

        return result.OrderBy(r => r.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    /// <summary>Данные WMI на случай, если нативное чтение недоступно.</summary>
    private static Dictionary<int, (string? path, string? cmd, int parent)> QueryWmiProcesses()
    {
        var map = new Dictionary<int, (string? path, string? cmd, int parent)>();
        try
        {
            using var searcher = new ManagementObjectSearcher(
                "SELECT ProcessId, ParentProcessId, Name, ExecutablePath, CommandLine FROM Win32_Process");
            foreach (var o in searcher.Get())
            {
                try
                {
                    int pid = Convert.ToInt32(o["ProcessId"]);
                    int parent = Convert.ToInt32(o["ParentProcessId"]);
                    map[pid] = (o["ExecutablePath"] as string, o["CommandLine"] as string, parent);
                }
                catch { }
            }
        }
        catch (Exception ex)
        {
            SimpleLog.Warn($"WMI Win32_Process недоступен: {ex.Message}");
        }
        return map;
    }

    /// <summary>Вердикт одной строки по текущим данным (без обращения к диску за подписью).</summary>
    public static void Evaluate(ProcessRow row)
    {
        if (row.Pid <= 4 || string.IsNullOrEmpty(row.Path)) return;
        if (row.Pid == Environment.ProcessId)
        {
            row.SuspiciousReasons = "Собственный процесс AegisKit";
            return;
        }
        var signals = SuspicionRules.Analyze(row.Path, row.Company, row.SignatureChecked, row.Signed, row.CommandLine);
        row.Suspicious = signals.Any(s => s.Strength == SignalStrength.Strong);
        row.SuspiciousReasons = string.Join("; ", signals
            .Select(s => s.Strength == SignalStrength.Strong ? s.Text : s.Text + " (слабый признак)"));
    }

    /// <summary>Строки, для которых проверка подписи действительно уточнит вердикт.</summary>
    public static List<ProcessRow> SignatureCandidates(IEnumerable<ProcessRow> rows) =>
        rows.Where(r => r.Pid > 4 && !r.SignatureChecked && !string.IsNullOrEmpty(r.Path) &&
                        AvoidSelf(r.Pid) &&
                        SuspicionRules.Analyze(r.Path, r.Company, false, false, r.CommandLine)
                            .Any(s => s.Strength == SignalStrength.Weak))
            .ToList();

    private static bool AvoidSelf(int pid) => pid != Environment.ProcessId;

    /// <summary>Проверяет подписи переданных файлов (параллельно) и пересчитывает вердикты.</summary>
    public static int VerifySuspectSignatures(IReadOnlyList<ProcessRow> rows)
    {
        int signed = 0;
        Parallel.ForEach(rows, new ParallelOptions { MaxDegreeOfParallelism = 4 }, r =>
        {
            try { r.Signed = NativeMethods.VerifyFileSignature(r.Path); }
            catch { r.Signed = false; }
            r.SignatureChecked = true;
            if (r.Signed) Interlocked.Increment(ref signed);
        });
        foreach (var r in rows) Evaluate(r);
        return signed;
    }

    [System.Runtime.InteropServices.DllImport("ntdll.dll")]
    private static extern int NtQueryInformationProcess(
        IntPtr processHandle, int infoClass,
        out uint processInformation, uint length, out uint returnLength);

    private static bool ReadCriticalFlag(IntPtr hProcess)
    {
        // ProcessBreakOnTermination = 29
        try
        {
            return NtQueryInformationProcess(hProcess, 29, out uint value, 4, out _) == 0 && value != 0;
        }
        catch { return false; }
    }

    // ---------- Операции ----------

    /// <summary>
    /// Проверяет, что PID всё ещё принадлежит тому же процессу: сравнивает время
    /// создания, а если его не удалось прочитать — путь к образу. Иначе команда
    /// «Завершить» могла убить совсем другой процесс, занявший тот же PID.
    /// </summary>
    public static bool IsSameProcess(ProcessRow row)
    {
        Process? p = null;
        try
        {
            p = Process.GetProcessById(row.Pid);
            if (row.CreationTimeUtc != default)
            {
                try
                {
                    var start = p.StartTime.ToUniversalTime();
                    return Math.Abs((start - row.CreationTimeUtc).TotalSeconds) < 2;
                }
                catch { /* недоступно — ниже проверяем путь к образу */ }
            }
            var h = NativeMethods.OpenProcess(NativeMethods.PROCESS_QUERY_LIMITED_INFORMATION, false, row.Pid);
            if (h == IntPtr.Zero) return true; // не можем перепроверить — не мешаем оператору
            try
            {
                var path = NativeMethods.GetProcessImagePath(h);
                return string.IsNullOrEmpty(path) || string.IsNullOrEmpty(row.Path) ||
                       string.Equals(path, row.Path, StringComparison.OrdinalIgnoreCase);
            }
            finally { NativeMethods.CloseHandle(h); }
        }
        catch { return false; }
        finally { p?.Dispose(); }
    }

    private static bool Guard(ProcessRow row, string action)
    {
        if (IsSameProcess(row)) return true;
        SimpleLog.Warn($"{action}: PID {row.Pid} уже занят другим процессом — действие отменено");
        return false;
    }

    public static bool Kill(ProcessRow row) => Guard(row, "Завершение") && Kill(row.Pid);
    public static bool Suspend(ProcessRow row) => Guard(row, "Приостановка") && Suspend(row.Pid);
    public static bool Resume(ProcessRow row) => Guard(row, "Возобновление") && Resume(row.Pid);
    public static bool SetCritical(ProcessRow row, bool critical) =>
        Guard(row, "Смена критичности") && SetCritical(row.Pid, critical);

    public static bool Kill(int pid)
    {
        try { using var p = Process.GetProcessById(pid); p.Kill(); return true; }
        catch (Exception ex) { SimpleLog.Error($"Kill {pid}: {ex.Message}"); return false; }
    }

    /// <summary>
    /// Завершение дерева процессов: обход по ParentPid в ширину (защита от циклов),
    /// затем завершение от листьев к корню.
    /// </summary>
    public static int KillTree(int pid)
    {
        var all = new Dictionary<int, int>(); // pid -> parent
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT ProcessId, ParentProcessId FROM Win32_Process");
            foreach (var o in searcher.Get())
                all[Convert.ToInt32(o["ProcessId"])] = Convert.ToInt32(o["ParentProcessId"]);
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"KillTree snapshot: {ex.Message}");
            return 0;
        }

        var children = new Dictionary<int, List<int>>();
        foreach (var (child, parent) in all)
        {
            if (!children.TryGetValue(parent, out var list)) children[parent] = list = new List<int>();
            list.Add(child);
        }

        // Обход в ширину с защитой от циклов и повторного включения
        var toKill = new List<int>();
        var seen = new HashSet<int>();
        var queue = new Queue<int>();
        queue.Enqueue(pid);
        seen.Add(pid);
        while (queue.Count > 0)
        {
            var p = queue.Dequeue();
            toKill.Add(p);
            if (!children.TryGetValue(p, out var kids)) continue;
            foreach (var k in kids)
                if (seen.Add(k)) queue.Enqueue(k);
        }

        int killed = 0;
        foreach (var target in Enumerable.Reverse(toKill)) // сначала листья
        {
            if (target == Environment.ProcessId) continue; // не убиваем сами себя
            try
            {
                using var p = Process.GetProcessById(target);
                p.Kill();
                killed++;
                SimpleLog.Info($"Завершён PID {target}");
            }
            catch { }
        }
        return killed;
    }

    public static bool Suspend(int pid)
    {
        NativeMethods.EnableDebugPrivilege();
        var h = NativeMethods.OpenProcess(NativeMethods.PROCESS_SUSPEND_RESUME, false, pid);
        if (h == IntPtr.Zero)
        {
            SimpleLog.Error($"Suspend {pid}: {NativeMethods.GetWin32Message(System.Runtime.InteropServices.Marshal.GetLastWin32Error())}");
            return false;
        }
        try
        {
            bool ok = NativeMethods.SuspendProcess(h);
            if (!ok) SimpleLog.Error($"Suspend {pid}: NtSuspendProcess failed");
            return ok;
        }
        finally { NativeMethods.CloseHandle(h); }
    }

    public static bool Resume(int pid)
    {
        NativeMethods.EnableDebugPrivilege();
        var h = NativeMethods.OpenProcess(NativeMethods.PROCESS_SUSPEND_RESUME, false, pid);
        if (h == IntPtr.Zero)
        {
            SimpleLog.Error($"Resume {pid}: {NativeMethods.GetWin32Message(System.Runtime.InteropServices.Marshal.GetLastWin32Error())}");
            return false;
        }
        try
        {
            bool ok = NativeMethods.ResumeProcess(h);
            if (!ok) SimpleLog.Error($"Resume {pid}: NtResumeProcess failed");
            return ok;
        }
        finally { NativeMethods.CloseHandle(h); }
    }

    public static bool SetCritical(int pid, bool critical)
    {
        NativeMethods.EnableDebugPrivilege();
        var h = NativeMethods.OpenProcess(
            NativeMethods.PROCESS_SET_INFORMATION | NativeMethods.PROCESS_QUERY_INFORMATION | NativeMethods.PROCESS_TERMINATE,
            false, pid);
        if (h == IntPtr.Zero)
        {
            SimpleLog.Error($"Critical {pid}: {NativeMethods.GetWin32Message(System.Runtime.InteropServices.Marshal.GetLastWin32Error())}");
            return false;
        }
        try
        {
            bool ok = NativeMethods.SetProcessCritical(h, critical);
            if (!ok) SimpleLog.Error($"Critical {pid}: NtSetInformationProcess failed");
            else SimpleLog.Ok($"PID {pid}: флаг критичности = {(critical ? "ВКЛ" : "ВЫКЛ")}");
            return ok;
        }
        finally { NativeMethods.CloseHandle(h); }
    }

    /// <summary>Поиск похожих файлов: то же имя в типичных местах размещения вредоносных копий.</summary>
    public static List<string> FindSimilarFiles(string filePath)
    {
        var results = new List<string>();
        var name = Path.GetFileName(filePath);
        var roots = new[]
        {
            Environment.GetEnvironmentVariable("TEMP"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp"),
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            Path.Combine(Environment.GetEnvironmentVariable("ProgramData") ?? "C:\\ProgramData"),
            "C:\\Users\\Public",
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Tasks"),
        }.Where(r => !string.IsNullOrEmpty(r) && Directory.Exists(r))
         .Select(r => r!)
         .Distinct(StringComparer.OrdinalIgnoreCase)
         .ToList();

        foreach (var root in roots)
        {
            try
            {
                results.AddRange(Directory.EnumerateFiles(root, name, SearchOption.AllDirectories));
                if (results.Count > 100) break;
            }
            catch { }
        }
        return results.Distinct().ToList();
    }
}

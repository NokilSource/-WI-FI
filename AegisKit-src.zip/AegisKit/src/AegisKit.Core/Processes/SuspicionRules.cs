namespace AegisKit.Core.Processes;

/// <summary>Сила признака: Strong делает строку «подозрительной», Weak — только поясняет.</summary>
public enum SignalStrength { Weak, Strong }

/// <summary>Один признак подозрительности с объяснением.</summary>
public readonly record struct SuspicionSignal(string Text, SignalStrength Strength);

/// <summary>
/// Эвристика «подозрительности» исполняемых файлов (по образцу AVZ/RecoveryKit).
/// Правила детерминированные и объяснимые: каждый вердикт — список текстовых причин.
/// Никаких «магических» эвристик: всё, что помечается, можно проверить руками.
/// </summary>
public static class SuspicionRules
{
    // ---------- Категории расположения ----------
    public const string LocSystem = "SYSTEM";
    public const string LocProgramFiles = "PROGFILES";
    public const string LocTemp = "TEMP";
    public const string LocDownload = "DOWNLOAD";
    public const string LocUser = "USER";
    public const string LocOther = "OTHER";

    private static readonly string[] TempRoots =
    {
        Environment.GetEnvironmentVariable("TEMP") ?? "",
        Environment.GetEnvironmentVariable("TMP") ?? "",
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Temp"),
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp"),
        Environment.GetFolderPath(Environment.SpecialFolder.InternetCache),
        "C:\\Users\\Public",
    };

    private static readonly string[] UserRoots =
    {
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
    };

    private static readonly string[] SystemDirs =
    {
        Environment.GetFolderPath(Environment.SpecialFolder.System),
        Environment.GetFolderPath(Environment.SpecialFolder.SystemX86),
        Environment.GetFolderPath(Environment.SpecialFolder.Windows),
        Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
        Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
    };

    /// <summary>Убирает префикс \??\ и разворачивает переменные окружения.</summary>
    public static string NormalizePath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return "";
        var p = path.Trim().Trim('"');
        if (p.StartsWith(@"\??\", StringComparison.Ordinal)) p = p[4..];
        if (p.StartsWith(@"\\?\", StringComparison.Ordinal)) p = p[4..];
        try { p = Environment.ExpandEnvironmentVariables(p); } catch { }
        return p;
    }

    /// <summary>Категория расположения: SYSTEM / PROGFILES / TEMP / DOWNLOAD / USER / OTHER.</summary>
    public static string ClassifyLocation(string? path)
    {
        var full = NormalizePath(path);
        if (full.Length == 0) return LocOther;
        if (full.StartsWith(@"\\")) return LocOther;              // UNC/устройство
        if (full.StartsWith('\\')) return LocOther;
        var p = full.ToLowerInvariant();

        foreach (var w in SystemDirs.Where(w => !string.IsNullOrEmpty(w)))
        {
            var wl = w.ToLowerInvariant().TrimEnd('\\');
            if (p.StartsWith(wl + "\\") || p == wl) return LocSystem;
        }
        if (p.Contains(":\\program files")) return LocProgramFiles;

        foreach (var t in TempRoots.Where(t => !string.IsNullOrEmpty(t)))
        {
            var tl = t.ToLowerInvariant().TrimEnd('\\');
            if (p.StartsWith(tl + "\\") || p == tl) return LocTemp;
        }
        if (p.Contains("\\temp\\") || p.Contains("\\tmp\\")) return LocTemp;
        if (p.Contains("\\downloads\\") || p.EndsWith("\\downloads")) return LocDownload;

        foreach (var u in UserRoots.Where(u => !string.IsNullOrEmpty(u)))
        {
            var ul = u.ToLowerInvariant().TrimEnd('\\');
            if (p.StartsWith(ul + "\\") || p == ul) return LocUser;
        }
        if (p.Contains(":\\programdata\\")) return LocUser;
        return LocOther;
    }

    private static readonly string[] TrustedTokens =
    {
        "microsoft", "intel", "nvidia", "realtek", "advanced micro devices", "google",
        "mozilla", "valve", "voidtools", "videolan", "python software foundation",
        "jetbrains", "adobe", "samsung", "lenovo", "dell", "logitech", "oracle",
        "hewlett", "advanced micro devices, inc", "kaspersky", "eset", "mbam",
        "malwarebytes", "avast", "avira", "bitdefender", "notepad++", "wireguard",
        "teamviewer", "browserstack", "openai", "github", "gitkraken", "obsidian",
        "discord", "slack", "zoom", "telegram", "signal", "nvidia corporation",
        "wireshark", "corel", "autodesk", "elantech", "synaptics", "logitech europe"
    };

    /// <summary>Известные доверенные издатели (по CompanyName).</summary>
    public static bool IsTrustedPublisher(string? company)
    {
        if (string.IsNullOrWhiteSpace(company)) return false;
        var c = company.ToLowerInvariant();
        if (TrustedTokens.Any(t => c.Contains(t))) return true;
        // короткие аббревиатуры — только как отдельные слова, иначе «amd» ловит «Amdocs» и т.п.
        return System.Text.RegularExpressions.Regex.IsMatch(c, @"\b(amd|ibm|msi|asrock|gigabyte|asustek|msi)\b");
    }

    // ---------- Маскировка ----------

    /// <summary>Имена, под которые маскируется малварь (должны запускаться только из %SystemRoot%).</summary>
    private static readonly string[] SystemProcessNames =
    {
        "svchost.exe", "lsass.exe", "csrss.exe", "winlogon.exe", "services.exe", "smss.exe",
        "wininit.exe", "lsaiso.exe", "taskhostw.exe", "spoolsv.exe", "dwm.exe", "explorer.exe",
        "audiodg.exe", "fontdrvhost.exe", "userinit.exe", "sihost.exe", "ctfmon.exe",
        "runtimebroker.exe", "searchindexer.exe", "wmiprvse.exe", "wlanext.exe", "msdtc.exe",
        "conhost.exe", "dllhost.exe", "ntoskrnl.exe", "registry", "system"
    };

    /// <summary>Системный процесс запущен не из каталога Windows — признак маскировки.</summary>
    public static bool IsMasquerade(string? path)
    {
        var full = NormalizePath(path);
        if (full.Length == 0) return false;
        var name = Path.GetFileName(full);
        if (string.IsNullOrEmpty(name)) return false;
        if (!SystemProcessNames.Contains(name, StringComparer.OrdinalIgnoreCase)) return false;

        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        if (string.IsNullOrEmpty(windows)) return false;
        var prefix = windows.TrimEnd('\\').ToLowerInvariant() + "\\";
        return !full.ToLowerInvariant().StartsWith(prefix);
    }

    private const string CyrillicLookalikes = "аеорсхуіјАЕОРСХУІЈ";

    /// <summary>
    /// Гомоглифы: латинские буквы перемешаны с кириллическими двойниками в одном имени
    /// (explorеr.exe, lsаss.exe). Просто кириллическое имя файла — не признак.
    /// </summary>
    public static bool HasMaskedName(string? path)
    {
        var name = Path.GetFileNameWithoutExtension(NormalizePath(path));
        if (string.IsNullOrEmpty(name)) return false;

        bool hasLatin = false, hasLookalike = false, hasOtherCyrillic = false;
        foreach (var c in name)
        {
            if (c is >= 'a' and <= 'z' or >= 'A' and <= 'Z') hasLatin = true;
            if (CyrillicLookalikes.Contains(c)) hasLookalike = true;
            else if (c >= '\u0400' && c <= '\u04FF') hasOtherCyrillic = true;
        }
        return hasLatin && hasLookalike && !hasOtherCyrillic;
    }

    private static readonly string[] ExecExtensions =
    {
        ".exe", ".scr", ".com", ".pif", ".bat", ".cmd", ".js", ".jse", ".vbs", ".vbe",
        ".wsf", ".wsh", ".hta", ".ps1", ".msi", ".jar", ".cpl", ".sys", ".dll", ".lnk", ".url"
    };

    private static readonly string[] DocumentExtensions =
    {
        ".txt", ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".rtf", ".csv",
        ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".mp3", ".mp4", ".avi",
        ".mkv", ".mov", ".zip", ".rar", ".7z", ".iso", ".img", ".chm", ".hlp", ".xml",
        ".jpg", ".log", ".dat", ".tmp", ".dll", ".exe", ".scr", ".com", ".bat", ".cmd"
    };

    /// <summary>Двойное расширение: «документ» + исполняемое (отчёт.pdf.exe).</summary>
    public static bool HasDoubleExtension(string? path)
    {
        var name = Path.GetFileName(NormalizePath(path)).ToLowerInvariant();
        if (name.Length == 0) return false;
        foreach (var ex in ExecExtensions)
        {
            if (!name.EndsWith(ex, StringComparison.Ordinal)) continue;
            var stem = name[..^ex.Length];
            int dot = stem.LastIndexOf('.');
            if (dot <= 0) continue;
            var inner = stem[dot..];
            if (DocumentExtensions.Contains(inner, StringComparer.Ordinal)) return true;
        }
        return false;
    }

    // ---------- Скриптовые хосты ----------

    private static readonly string[] ScriptHosts =
    {
        "wscript.exe", "cscript.exe", "mshta.exe", "powershell.exe", "pwsh.exe",
        "cmd.exe", "rundll32.exe", "regsvr32.exe", "wmic.exe", "msiexec.exe",
        "forfiles.exe", "installutil.exe", "msbuild.exe", "certutil.exe", "bitsadmin.exe"
    };

    private static readonly string[] DropExtensions =
    {
        ".js", ".jse", ".vbs", ".vbe", ".wsf", ".wsh", ".hta", ".ps1", ".bat", ".cmd",
        ".scr", ".pif", ".lnk", ".url", ".xll", ".lnk"
    };

    /// <summary>Известный интерпретатор/лоадер запущен с файлом из пользовательского места.</summary>
    public static bool IsScriptHostExecution(string? processPath, string? commandLine)
    {
        var host = Path.GetFileName(NormalizePath(processPath));
        if (string.IsNullOrEmpty(host)) return false;
        if (!ScriptHosts.Contains(host, StringComparer.OrdinalIgnoreCase)) return false;
        if (string.IsNullOrWhiteSpace(commandLine)) return false;

        // Ищем в командной строке аргумент-файл, лежащий в пользовательском/временном месте
        foreach (var token in SplitCommandLine(commandLine))
        {
            if (token.Length < 5) continue;
            if (!DropExtensions.Any(e => token.EndsWith(e, StringComparison.OrdinalIgnoreCase))) continue;
            var loc = ClassifyLocation(token);
            if (loc is LocTemp or LocDownload or LocUser) return true;
        }
        return false;
    }

    /// <summary>Разбор командной строки на токены с учётом кавычек.</summary>
    public static IEnumerable<string> SplitCommandLine(string commandLine)
    {
        var sb = new System.Text.StringBuilder();
        bool quoted = false;
        foreach (var c in commandLine)
        {
            if (c == '"') { quoted = !quoted; continue; }
            if (!quoted && c == ' ')
            {
                if (sb.Length > 0) { yield return sb.ToString(); sb.Clear(); }
                continue;
            }
            sb.Append(c);
        }
        if (sb.Length > 0) yield return sb.ToString();
    }

    // ---------- Основные правила ----------

    /// <summary>Разбор всех признаков (Strong и Weak) с пояснениями.</summary>
    public static List<SuspicionSignal> Analyze(string? path, string? company,
        bool signatureChecked, bool signed, string? commandLine = null)
    {
        var signals = new List<SuspicionSignal>();
        var full = NormalizePath(path);

        if (full.Length == 0)
        {
            signals.Add(new SuspicionSignal("Путь к файлу недоступен", SignalStrength.Strong));
            return signals;
        }
        if (!File.Exists(full))
        {
            signals.Add(new SuspicionSignal("Файл отсутствует на диске", SignalStrength.Strong));
            return signals;
        }

        var loc = ClassifyLocation(full);
        bool verified = signatureChecked && signed;
        bool trusted = IsTrustedPublisher(company);
        bool vouched = verified && (trusted || !string.IsNullOrWhiteSpace(company));

        // --- Признаки, не зависящие от расположения ---
        if (IsMasquerade(full))
            signals.Add(new SuspicionSignal(
                $"Маскировка под системный процесс: {Path.GetFileName(full)} вне каталога Windows",
                SignalStrength.Strong));
        if (HasMaskedName(full))
            signals.Add(new SuspicionSignal(
                "В имени файла смешаны латиница и кириллические двойники", SignalStrength.Strong));
        if (HasDoubleExtension(full))
            signals.Add(new SuspicionSignal(
                "Двойное расширение в имени файла (маскировка под документ)", SignalStrength.Strong));
        if (IsScriptHostExecution(full, commandLine))
            signals.Add(new SuspicionSignal(
                "Интерпретатор запускает скрипт из пользовательского/временного каталога",
                SignalStrength.Strong));

        // --- Расположение ---
        // Сильный вердикт — только для действительно характерных мест запуска малвари.
        // Отсутствие подписи у портативной программы в пользовательской папке — это
        // «Без подписи» (weak), а не «Подозрительно»: иначе весь список горит красным.
        switch (loc)
        {
            case LocTemp:
                if (!verified)
                    signals.Add(new SuspicionSignal(
                        "Запуск исполняемого файла из временного каталога", SignalStrength.Strong));
                else if (!trusted)
                    signals.Add(new SuspicionSignal(
                        "Подписанный файл неизвестного издателя из временного каталога",
                        SignalStrength.Weak));
                break;
            case LocDownload:
                if (signatureChecked && !verified && !trusted)
                    signals.Add(new SuspicionSignal(
                        "Неподписанный исполняемый файл в папке загрузок", SignalStrength.Weak));
                else if (!signatureChecked && !trusted)
                    signals.Add(new SuspicionSignal(
                        "Файл в папке загрузок, подпись не проверена", SignalStrength.Weak));
                if (signatureChecked && verified && !trusted)
                    signals.Add(new SuspicionSignal(
                        "Подписанный файл неизвестного издателя в папке загрузок", SignalStrength.Weak));
                break;
            case LocUser:
                if (signatureChecked && !verified && !trusted)
                    signals.Add(new SuspicionSignal(
                        "Неподписанный файл в пользовательском каталоге", SignalStrength.Weak));
                else if (!signatureChecked && !trusted)
                    signals.Add(new SuspicionSignal(
                        "Исполняемый файл в пользовательском каталоге, подпись не проверена",
                        SignalStrength.Weak));
                break;
            case LocOther:
                if (signatureChecked && !verified && !trusted)
                    signals.Add(new SuspicionSignal(
                        "Неподписанный файл вне доверенных каталогов", SignalStrength.Weak));
                break;
        }

        // --- Метаданные (слабые сигналы: объясняют, но не обвиняют) ---
        if (loc is LocUser or LocOther or LocTemp or LocDownload)
        {
            if (!signatureChecked)
                signals.Add(new SuspicionSignal("Цифровая подпись не проверена", SignalStrength.Weak));
            else if (!verified)
                signals.Add(new SuspicionSignal("Нет действительной цифровой подписи", SignalStrength.Weak));
            if (string.IsNullOrWhiteSpace(company) && !trusted && !vouched)
                signals.Add(new SuspicionSignal("Издатель не указан (нет CompanyName)", SignalStrength.Weak));
        }

        return signals;
    }

    /// <summary>Только сильные причины — для вердикта «Подозрительно».</summary>
    public static List<string> Evaluate(string? path, string? company, bool signatureChecked, bool signed) =>
        Analyze(path, company, signatureChecked, signed)
            .Where(s => s.Strength == SignalStrength.Strong)
            .Select(s => s.Text).ToList();

    /// <summary>Все причины (включая слабые) — для подсказки в интерфейсе.</summary>
    public static List<string> Describe(string? path, string? company, bool signatureChecked, bool signed) =>
        Analyze(path, company, signatureChecked, signed)
            .Select(s => s.Strength == SignalStrength.Strong ? s.Text : s.Text + " (слабый признак)")
            .ToList();

    public static bool IsPathSuspicious(string? path) =>
        ClassifyLocation(path) is LocTemp;
}

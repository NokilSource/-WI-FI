using Microsoft.Win32;
using AegisKit.Core.Logging;

namespace AegisKit.Core.Recovery;

/// <summary>Один пункт восстановления: что именно и где снимается.</summary>
public sealed record RecoveryItem(
    string Id,
    string Group,
    string Title,
    string Details,
    Action Action,
    bool Dangerous = false);

/// <summary>
/// Дополнительные снятия ограничений, повторяющие набор Recovery Kit
/// (uDisallowAndRestrict, uCAD, uPowerButton, uMouse, uDeviceManagerPage,
/// uDesktopItems, uLogOff, uSwitchUser, uUserAccount, uCmdLine, uKeyboard,
/// uIFEODebuggerCleaner). Каждый метод идемпотентен: отсутствие значения
/// считается успехом, а не ошибкой.
/// </summary>
public static partial class RecoveryOps
{
    private const string PoliciesSystemWin = @"Software\Microsoft\Windows\CurrentVersion\Policies\System";
    private const string PoliciesExplorerWin = @"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer";
    private const string PoliciesWindowsSystem = @"Software\Policies\Microsoft\Windows\System";
    private const string WinlogonKey = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon";
    private const string SessionManagerKey = @"SYSTEM\CurrentControlSet\Control\Session Manager";
    private const string LsaKey = @"SYSTEM\CurrentControlSet\Control\Lsa";
    private const string KeyboardLayoutKey = @"SYSTEM\CurrentControlSet\Control\Keyboard Layout";

    /// <summary>Выполняет действие, гася исключения, и всегда пишет строку в журнал.</summary>
    private static bool Step(string title, Action body)
    {
        try
        {
            body();
            return true;
        }
        catch (UnauthorizedAccessException)
        {
            SimpleLog.Error($"{title}: доступ запрещён — нужны права администратора");
            return false;
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"{title}: {ex.Message}");
            return false;
        }
    }

    /// <summary>Удаляет значение и в 64-, и в 32-битном представлении куста.</summary>
    private static void DelBothViews(string label, RegistryHive hive, string keyPath, string valueName)
    {
        foreach (var view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
        {
            try
            {
                using var root = RegistryKey.OpenBaseKey(hive, view);
                using var key = root.OpenSubKey(keyPath, true);
                if (key == null) continue;
                if (!key.GetValueNames().Any(n => n.Equals(valueName, StringComparison.OrdinalIgnoreCase)))
                    continue;
                key.DeleteValue(valueName, false);
                SimpleLog.Ok($"{label}: удалено {valueName}");
            }
            catch (Exception ex)
            {
                // ключа в этом представлении может не быть — это норма
                if (ex is not UnauthorizedAccessException) continue;
                SimpleLog.Error($"{label}: доступ запрещён к {hive}\\{keyPath}");
            }
        }
    }

    /// <summary>Удаляет все значения в подключах вида <c>&lt;key&gt;\&lt;DisallowRun&gt;</c>.</summary>
    private static int DeleteAllValues(string hiveLabel, RegistryHive hive, string keyPath)
    {
        int removed = 0;
        try
        {
            using var root = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64);
            using var key = root.OpenSubKey(keyPath, true);
            if (key == null) return 0;
            // нельзя удалять во время перечисления — сначала собираем имена
            var names = key.GetValueNames();
            foreach (var n in names)
                try { key.DeleteValue(n, false); removed++; } catch { }
        }
        catch (Exception ex)
        {
            SimpleLog.Warn($"{hiveLabel}\\{keyPath}: {ex.Message}");
        }
        return removed;
    }

    // ---------- 11. Запрет запуска программ: DisallowRun / RestrictRun ----------

    public static void RepairDisallowRestrict()
    {
        Step("Запрет запуска программ", () =>
        {
            foreach (var (hive, label) in new[]
                     { (RegistryHive.CurrentUser, "HKCU"), (RegistryHive.LocalMachine, "HKLM") })
            {
                DelBothViews($"{label} DisallowRun", hive, PoliciesExplorerWin, "DisallowRun");
                DelBothViews($"{label} RestrictRun", hive, PoliciesExplorerWin, "RestrictRun");
                int n = DeleteAllValues(label, hive, PoliciesExplorerWin + @"\DisallowRun")
                      + DeleteAllValues(label, hive, PoliciesExplorerWin + @"\RestrictRun");
                if (n > 0) SimpleLog.Ok($"{label}: очищено записей в подключах Disallow/Restrict: {n}");
            }
            SimpleLog.Ok("Списки запрещённых программ сняты");
        });
    }

    // ---------- 12. Ctrl+Alt+Del, блокировка, смена пароля, выход ----------

    public static void RepairCad()
    {
        Step("Ctrl+Alt+Del (DisableCAD)", () =>
        {
            DelBothViews("CAD Winlogon", RegistryHive.LocalMachine, WinlogonKey, "DisableCAD");
            DelBothViews("CAD Политики", RegistryHive.LocalMachine, PoliciesSystemWin, "DisableCAD");
            DelBothViews("CAD Политики (пользователь)", RegistryHive.CurrentUser, PoliciesSystemWin, "DisableCAD");
            SimpleLog.Ok("Требование Ctrl+Alt+Del возвращено к стандартному");
        });
    }

    public static void RepairChangePasswordAndLock()
    {
        Step("Смена пароля и блокировка", () =>
        {
            foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
            {
                DelBothViews("DisableChangePassword", hive, PoliciesSystemWin, "DisableChangePassword");
                DelBothViews("DisableLockWorkstation", hive, PoliciesSystemWin, "DisableLockWorkstation");
                DelBothViews("DisableLockWorkstation (Policies)", hive, @"Software\Microsoft\Windows\CurrentVersion\Policies", "DisableLockWorkstation");
            }
            SimpleLog.Ok("Смена пароля и Win+L разблокированы");
        });
    }

    public static void RepairLogOff()
    {
        Step("Выход из системы", () =>
        {
            foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
            {
                DelBothViews("NoLogoff", hive, PoliciesExplorerWin, "NoLogoff");
                DelBothViews("DisableLogoff", hive, PoliciesExplorerWin, "DisableLogoff");
                DelBothViews("StartMenuLogoff", hive, PoliciesExplorerWin, "StartMenuLogoff");
            }
            SimpleLog.Ok("Пункты «Выход из системы» восстановлены");
        });
    }

    public static void RepairSwitchUser()
    {
        Step("Смена пользователя", () =>
        {
            foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
            {
                DelBothViews("HideFastUserSwitching", hive, PoliciesSystemWin, "HideFastUserSwitching");
                DelBothViews("DisableSwitchUser", hive, PoliciesSystemWin, "DisableSwitchUser");
            }
            SimpleLog.Ok("Быстрая смена пользователя разблокирована");
        });
    }

    public static void RepairTaskSwitching()
    {
        Step("Alt+Tab (NoTaskSwitching)", () =>
        {
            foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
                DelBothViews("NoTaskSwitching", hive, PoliciesExplorerWin, "NoTaskSwitching");
            SimpleLog.Ok("Alt+Tab разблокирован");
        });
    }

    // ---------- 13. Кнопка питания ----------

    public static void RepairPowerButton()
    {
        Step("Кнопка питания", () =>
        {
            foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
            {
                DelBothViews("DisablePowerButton", hive, PoliciesSystemWin, "DisablePowerButton");
                DelBothViews("NoClose", hive, PoliciesExplorerWin, "NoClose");
                DelBothViews("NoClose (пользователь)", hive, @"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer", "NoClose");
            }
            DelBothViews("HidePowerButton", RegistryHive.LocalMachine,
                @"SOFTWARE\Microsoft\PolicyManager\default\Start\HidePowerButton", "value");
            SimpleLog.Ok("Кнопки завершения работы и питания возвращены");
        });
    }

    // ---------- 14. Курсор мыши ----------

    public static void RepairCursorSuppression()
    {
        Step("Скрытие курсора мыши", () =>
        {
            foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
            {
                DelBothViews("EnableCursorSuppression", hive, PoliciesSystemWin, "EnableCursorSuppression");
                DelBothViews("EnableCursorSuppressio", hive, PoliciesSystemWin, "EnableCursorSuppressio");
            }
            DelBothViews("CursorBaseSize", RegistryHive.CurrentUser, @"Control Panel\Cursors", "CursorBaseSize");
            DelBothViews("CursorSize", RegistryHive.CurrentUser, @"Software\Microsoft\Accessibility", "CursorSize");
            SimpleLog.Ok("Настройки курсора мыши сброшены к стандартным");
        });
    }

    // ---------- 15. Диспетчер устройств и оснастки ----------

    public static void RepairDeviceManagerPage()
    {
        Step("Диспетчер устройств", () =>
        {
            foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
            {
                DelBothViews("NoDeviceManagerPage", hive, PoliciesSystemWin, "NoDeviceManagerPage");
                DelBothViews("NoDevMgrPage", hive, PoliciesSystemWin, "NoDevMgrPage");
                DelBothViews("MMC RestrictToPermittedSnapins", hive,
                    @"Software\Policies\Microsoft\MMC", "RestrictToPermittedSnapins");
            }
            SimpleLog.Ok("Диспетчер устройств и оснастки MMC разблокированы");
        });
    }

    // ---------- 16. Рабочий стол, панель задач, меню «Пуск» ----------

    private static readonly (string Key, string Value)[] DesktopRestrictions =
    {
        (PoliciesExplorerWin, "NoDesktop"),
        (PoliciesExplorerWin, "NoStartMenu"),
        (PoliciesExplorerWin, "NoChangeStartMenu"),
        (PoliciesExplorerWin, "NoTaskbar"),
        (PoliciesExplorerWin, "NoStartButton"),
        (PoliciesExplorerWin, "NoTrayItemsDisplay"),
        (PoliciesExplorerWin, "TaskbarNoNotification"),
        (PoliciesExplorerWin, "NoPinningToTaskbar"),
        (PoliciesExplorerWin, "NoPinningToDestinations"),
        (PoliciesExplorerWin, "HideSCANetwork"),
        (PoliciesExplorerWin, "HideSCAPower"),
        (PoliciesExplorerWin, "HideSCAVolume"),
        (PoliciesExplorerWin, "HideSCAHealth"),
        (PoliciesExplorerWin, "NoViewContextMenu"),
        (PoliciesExplorerWin, "NoTrayContextMenu"),
        (PoliciesExplorerWin, "NoFileMenu"),
        (PoliciesExplorerWin, "NoViewMenu"),
        (PoliciesExplorerWin, "NoToolbarCustomize"),
        (PoliciesExplorerWin, "NoSetTaskbar"),
        (PoliciesExplorerWin, "NoChangeStartMenu"),
        (PoliciesExplorerWin, "NoActiveDesktop"),
        (PoliciesExplorerWin, "NoActiveDesktopChanges"),
        (PoliciesExplorerWin, "NoFind"),
        (PoliciesExplorerWin, "NoWindowsUpdate"),
        (PoliciesExplorerWin, "NoSetFolders"),
        (PoliciesExplorerWin, "ClassicShell"),
        (@"Software\Policies\Microsoft\Windows\Explorer", "HideStartMenu"),
        (@"Software\Policies\Microsoft\Windows\Explorer", "NoUseStoreOpenWith"),
        (PoliciesWindowsSystem, "DisableCMD"),
    };

    public static void RepairShellRestrictions()
    {
        Step("Ограничения оболочки и «Пуск»", () =>
        {
            int removed = 0;
            foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
                foreach (var (key, value) in DesktopRestrictions)
                {
                    using var root = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64);
                    using var k = root.OpenSubKey(key, true);
                    if (k == null) continue;
                    if (!k.GetValueNames().Any(n => n.Equals(value, StringComparison.OrdinalIgnoreCase))) continue;
                    k.DeleteValue(value, false);
                    removed++;
                }
            SimpleLog.Ok(removed == 0
                ? "Ограничений панели задач, рабочего стола и меню «Пуск» не найдено"
                : $"Снято ограничений оболочки: {removed}");
        });
    }

    // ---------- 17. Учётные записи и вход ----------

    public static void RepairAccountPolicies()
    {
        Step("Политики учётных записей", () =>
        {
            foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
            {
                DelBothViews("DontDisplayLastUserName", hive, PoliciesSystemWin, "DontDisplayLastUserName");
                DelBothViews("NoAddUser", hive, PoliciesSystemWin, "NoAddUser");
                DelBothViews("NoDeleteUser", hive, PoliciesSystemWin, "NoDeleteUser");
                DelBothViews("LimitBlankPasswordUse", hive, PoliciesSystemWin, "LimitBlankPasswordUse");
                DelBothViews("DisableWakeOnPassword", hive, @"Software\Policies\Microsoft\Windows\Personalization", "NoLockScreen");
            }
            // Автовход с открытым паролем в реестре — почти всегда след малвари
            foreach (var value in new[] { "AutoAdminLogon", "DefaultPassword" })
                DelBothViews("Автовход", RegistryHive.LocalMachine, WinlogonKey, value);
            SimpleLog.Ok("Политики входа и учётных записей восстановлены");
        });
    }

    public static void RepairSetupCmdLine()
    {
        Step("Перехват SYSTEM\\Setup\\CmdLine", () =>
        {
            DelBothViews("Setup CmdLine", RegistryHive.LocalMachine, @"SYSTEM\Setup", "CmdLine");
            DelBothViews("Setup SetupType", RegistryHive.LocalMachine, @"SYSTEM\Setup", "SetupType");
            SimpleLog.Ok("Параметры переустановки/первичной настройки очищены");
        });
    }

    // ---------- 18. Клавиатура и раскладка ----------

    public static void RepairKeyboardLayoutHijack()
    {
        Step("Перехват раскладки клавиатуры", () =>
        {
            DelBothViews("Scancode Map", RegistryHive.LocalMachine, KeyboardLayoutKey, "Scancode Map");
            DelBothViews("Scancode Map (Set001)", RegistryHive.LocalMachine,
                @"SYSTEM\ControlSet001\Control\Keyboard Layout", "Scancode Map");
            try
            {
                using var k = Registry.CurrentUser.CreateSubKey(@"Control Panel\Keyboard", true);
                k.SetValue("InitialKeyboardIndicators", "2");
                SimpleLog.Ok("Индикатор NumLock по умолчанию восстановлен");
            }
            catch (Exception ex) { SimpleLog.Warn($"NumLock: {ex.Message}"); }
            SimpleLog.Ok("Подмена клавиш (Scancode Map) удалена");
        });
    }

    /// <summary>
    /// Возвращает раскладки RU/EN и переключение по Alt+Shift — частая поломка
    /// после действий «оптимизаторов», когда язык ввода пропадает совсем.
    /// </summary>
    public static void RepairKeyboardLayouts()
    {
        Step("Раскладки RU/EN", () =>
        {
            try
            {
                using var root = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64);
                using var preload = root.CreateSubKey(@"Keyboard Layout\Preload", true);
                preload.SetValue("1", "00000409");   // en-US
                preload.SetValue("2", "00000419");   // ru-RU
                using var toggle = root.CreateSubKey(@"Keyboard Layout\Toggle", true);
                toggle.SetValue("Hotkey", "2", RegistryValueKind.String); // 2 = Alt+Shift
                // Мёртвые ссылки на отсутствующие раскладки в списке замен
                using var subst = root.CreateSubKey(@"Keyboard Layout\Substitutes", true);
                foreach (var name in subst.GetValueNames())
                    if (name.StartsWith('d') && name.Length == 8) subst.DeleteValue(name, false);
                SimpleLog.Ok("Раскладки RU/EN восстановлены, переключение — Alt+Shift");
                SimpleLog.Info("Для полного применения перезайдите в систему.");
            }
            catch (Exception ex) { SimpleLog.Error($"Раскладки: {ex.Message}"); }
        });
    }

    // ---------- 19. Оболочка и точки входа Winlogon ----------

    public static void RestoreShellAndWinlogon()
    {
        Step("Оболочка и точки входа Winlogon", () =>
        {
            using var root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
            using var key = root.OpenSubKey(WinlogonKey, true);
            if (key == null) { SimpleLog.Error("Winlogon: ключ недоступен"); return; }

            var expected = new Dictionary<string, string>
            {
                ["Shell"] = "explorer.exe",
                ["Userinit"] = @"C:\Windows\system32\userinit.exe,",
                ["UIHost"] = "logonui.exe",
                ["VMApplet"] = "SystemPropertiesPerformance.exe /pagefile",
            };
            foreach (var (name, value) in expected)
            {
                var current = key.GetValue(name)?.ToString();
                if (current == null) continue;
                if (current.Trim().Equals(value, StringComparison.OrdinalIgnoreCase)) continue;
                key.SetValue(name, name == "Userinit"
                    ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "userinit.exe,")
                    : value);
                SimpleLog.Ok($"Winlogon {name} восстановлен: было «{current}»");
            }
            foreach (var junk in new[] { "Taskman", "AppSetup" })
                if (key.GetValueNames().Any(n => n.Equals(junk, StringComparison.OrdinalIgnoreCase)))
                {
                    var old = key.GetValue(junk)?.ToString();
                    key.DeleteValue(junk, false);
                    SimpleLog.Ok($"Winlogon {junk} удалён (было «{old}»)");
                }
            SimpleLog.Ok("Точки входа Winlogon проверены");
        });
    }

    public static void RestoreBootExecute()
    {
        Step("BootExecute", () =>
        {
            using var root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
            using var key = root.OpenSubKey(SessionManagerKey, true);
            if (key == null) { SimpleLog.Error("Session Manager недоступен"); return; }
            var raw = key.GetValue("BootExecute");
            var text = raw switch
            {
                string[] arr => string.Join(" ", arr),
                string s => s,
                _ => ""
            };
            if (text.Replace("\0", " ").Trim().Equals("autocheck autochk *", StringComparison.OrdinalIgnoreCase))
            {
                SimpleLog.Info("BootExecute уже стандартный");
                return;
            }
            key.SetValue("BootExecute", new[] { "autocheck autochk *" }, RegistryValueKind.MultiString);
            SimpleLog.Ok($"BootExecute восстановлен (было «{text.Replace("\0", " ")}»)");
        });
    }

    // ---------- 20. Точки автозагрузки DLL: AppInit, LSA, Winlogon Notify ----------

    public static void CleanAppInitDlls()
    {
        Step("AppInit_DLLs", () =>
        {
            foreach (var path in new[]
                     {
                         @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows",
                         @"SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Windows",
                     })
            {
                using var root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                using var key = root.OpenSubKey(path, true);
                if (key == null) continue;
                var dlls = key.GetValue("AppInit_DLLs")?.ToString() ?? "";
                var loadValue = key.GetValue("LoadAppInit_DLLs");
                bool loadOn = loadValue switch
                {
                    int i => i != 0,
                    string s => s != "0" && s.Length > 0,
                    _ => false
                };
                if (dlls.Length == 0 && !loadOn) continue;
                key.SetValue("AppInit_DLLs", "", RegistryValueKind.String);
                key.SetValue("LoadAppInit_DLLs", 0, RegistryValueKind.DWord);
                SimpleLog.Ok($"AppInit_DLLs очищен ({path}): было «{dlls}»");
            }
        });
    }

    public static void CleanLsaNotificationPackages()
    {
        Step("LSA Notification Packages", () =>
        {
            using var root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
            using var key = root.OpenSubKey(LsaKey, true);
            if (key == null) { SimpleLog.Error("LSA недоступен"); return; }
            var known = new[] { "scecli", "rassfm", "nefssasas", "pku2u", "wdigest", "msv1_0", "kerberos" };
            var raw = key.GetValue("Notification Packages");
            var packages = raw switch
            {
                string[] arr => arr.ToList(),
                string s => s.Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries).ToList(),
                _ => new List<string>()
            };
            var clean = packages.Where(p => known.Contains(p.Trim(), StringComparer.OrdinalIgnoreCase)).ToArray();
            if (clean.Length == packages.Count)
            {
                SimpleLog.Info("Notification Packages: посторонних пакетов нет");
                return;
            }
            key.SetValue("Notification Packages", clean, RegistryValueKind.MultiString);
            SimpleLog.Ok($"Удалены посторонние пакеты LSA: " +
                         string.Join(", ", packages.Except(clean, StringComparer.OrdinalIgnoreCase)));
        });
    }

    public static void CleanWinlogonNotify()
    {
        Step("Winlogon Notify", () =>
        {
            using var root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
            foreach (var path in new[]
                     {
                         @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Notify",
                         @"SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Winlogon\Notify",
                     })
            {
                using var notify = root.OpenSubKey(path, true);
                if (notify == null) continue;
                var subs = notify.GetSubKeyNames();
                foreach (var sub in subs)
                {
                    try
                    {
                        notify.DeleteSubKeyTree(sub, false);
                        SimpleLog.Ok($"Удалён устаревший перехватчик Winlogon\\Notify\\{sub}");
                    }
                    catch (Exception ex) { SimpleLog.Warn($"Notify\\{sub}: {ex.Message}"); }
                }
            }
        });
    }

    // ---------- 21. IFEO: отладчики и «тихие» перехваты ----------

    /// <summary>Значения IFEO, которыми пользуются и малварь, и App Verifier.</summary>
    private static readonly string[] IfeoHijackValues =
    {
        "Debugger", "GlobalFlag", "VerifierDlls", "FilterFullPath",
        "MitigationOptions", "MinimumStackCommitInBytes", "TracingFlags",
    };

    /// <summary>
    /// Полная зачистка Image File Execution Options: HKLM и HKCU, оба
    /// представления, все перехватывающие значения. Считает статистику и
    /// пропускает легитимные отладчики (VS JIT, Application Verifier),
    /// чтобы не сломать установленные средства разработки.
    /// </summary>
    public static int CleanIfeoDebuggersDetailed(out int scanned, out int removed)
    {
        scanned = 0;
        removed = 0;
        try
        {
            foreach (var hive in new[] { RegistryHive.LocalMachine, RegistryHive.CurrentUser })
            foreach (var view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                using var root = RegistryKey.OpenBaseKey(hive, view);
                using var ifeo = root.OpenSubKey(Ifeo, true);
                if (ifeo == null) continue;
                foreach (var sub in ifeo.GetSubKeyNames())
                {
                    scanned++;
                    try
                    {
                        using var k = ifeo.OpenSubKey(sub, true);
                        if (k == null) continue;
                        var names = k.GetValueNames();
                        foreach (var value in IfeoHijackValues)
                        {
                            if (!names.Any(n => n.Equals(value, StringComparison.OrdinalIgnoreCase))) continue;
                            var old = k.GetValue(value)?.ToString() ?? "";
                            if (value == "Debugger" && IsLegitimateDebugger(old))
                            {
                                SimpleLog.Info($"IFEO {sub}: отладчик оставлен (легитимный: {old})");
                                continue;
                            }
                            k.DeleteValue(value, false);
                            removed++;
                            SimpleLog.Ok($"IFEO {sub}: удалено {value} = «{Short(old)}»");
                        }
                    }
                    catch (Exception ex) { SimpleLog.Warn($"IFEO {sub}: {ex.Message}"); }
                }
            }
            if (removed == 0)
                SimpleLog.Info($"IFEO: перехватчиков не найдено (проверено ключей: {scanned})");
            else
                SimpleLog.Ok($"IFEO: очищено значений — {removed} (проверено ключей: {scanned})");
        }
        catch (UnauthorizedAccessException)
        {
            SimpleLog.Error("IFEO: доступ запрещён (нужны права администратора)");
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"IFEO: {ex.Message}");
        }
        return removed;
    }

    public static void CleanIfeoDebuggers() => CleanIfeoDebuggersDetailed(out _, out _);

    private static bool IsLegitimateDebugger(string command)
    {
        var p = command.ToLowerInvariant();
        return p.Contains("vsjitdebugger") || p.Contains("application verifier") ||
               p.Contains("dbgx.dll") || p.Contains("windbg") || p.Contains("cdb.exe");
    }

    private static string Short(string s) => s.Length <= 70 ? s : s[..70] + "…";

    // ---------- 22. Полное восстановление ----------

    /// <summary>
    /// Выполняет выбранные пункты по порядку, сообщая о ходе.
    /// Используется кнопкой «Восстановить всё» и выборочным списком.
    /// </summary>
    public static int RestoreItems(IEnumerable<RecoveryItem> items, Action<int, int, string>? onStep = null)
    {
        var list = items.ToList();
        SimpleLog.Info($"Запущено восстановление: пунктов {list.Count}");
        SimpleLog.SetProgress(0, "Полное восстановление");
        int done = 0, failed = 0;
        foreach (var item in list)
        {
            onStep?.Invoke(done, list.Count, item.Title);
            SimpleLog.Info($"---- {item.Title} ----");
            try
            {
                item.Action();
            }
            catch (Exception ex)
            {
                failed++;
                SimpleLog.Error($"{item.Title}: {ex.Message}");
            }
            done++;
            SimpleLog.SetProgress((int)Math.Round(done * 100.0 / Math.Max(1, list.Count)), item.Title);
        }
        SimpleLog.ClearProgress();
        if (failed == 0) SimpleLog.Ok($"Восстановление завершено: выполнено {done} пунктов");
        else SimpleLog.Warn($"Восстановление завершено: {done - failed} из {done}, ошибок {failed}");
        return failed;
    }
}

/// <summary>
/// Каталог пунктов восстановления — единый источник и для одиночных кнопок,
/// и для галочек «выбрать что восстанавливать», и для кнопки «восстановить всё».
/// </summary>
public static class RecoveryCatalog
{
    public static IReadOnlyList<RecoveryItem> Items { get; } = new List<RecoveryItem>
    {
        new("taskmgr", "Доступ к средствам",
            "Диспетчер задач", "DisableTaskMgr (HKLM/HKCU)", RecoveryOps.RepairTaskManager),
        new("regedit", "Доступ к средствам",
            "Редактор реестра", "DisableRegistryTools (HKLM/HKCU)", RecoveryOps.RepairRegistryTools),
        new("cmd", "Доступ к средствам",
            "Командная строка", "DisableCMD (политики системы и пользователя)", RecoveryOps.RepairCommandPrompt),
        new("run", "Доступ к средствам",
            "Диалог «Выполнить»", "NoRun", RecoveryOps.RepairRunDialog),
        new("controlpanel", "Доступ к средствам",
            "Панель управления", "NoControlPanel, NoSetFolders", RecoveryOps.RepairControlPanel),
        new("devmgr", "Доступ к средствам",
            "Диспетчер устройств и оснастки MMC", "NoDeviceManagerPage, NoDevMgrPage, MMC", RecoveryOps.RepairDeviceManagerPage),
        new("folderopts", "Доступ к средствам",
            "Параметры папок", "NoFolderOptions", RecoveryOps.RepairFolderOptions),
        new("gpedit", "Доступ к средствам",
            "gpedit.msc и оснастки MMC", "RestrictToPermittedSnapins", RecoveryOps.RepairGpedit),

        new("hotkeys", "Клавиши и вход",
            "Клавиши Win, блокировка, выход", "NoWinKeys, DisableLockWorkstation, NoLogoff", RecoveryOps.RepairHotKeys),
        new("alttab", "Клавиши и вход",
            "Alt+Tab", "NoTaskSwitching", RecoveryOps.RepairTaskSwitching),
        new("cad", "Клавиши и вход",
            "Ctrl+Alt+Del", "DisableCAD", RecoveryOps.RepairCad),
        new("pwd", "Клавиши и вход",
            "Смена пароля и Win+L", "DisableChangePassword, DisableLockWorkstation", RecoveryOps.RepairChangePasswordAndLock),
        new("switchuser", "Клавиши и вход",
            "Быстрая смена пользователя", "HideFastUserSwitching, DisableSwitchUser", RecoveryOps.RepairSwitchUser),
        new("keyboard", "Клавиши и вход",
            "Подмена клавиш и NumLock", "Scancode Map, InitialKeyboardIndicators", RecoveryOps.RepairKeyboardLayoutHijack),
        new("layouts", "Клавиши и вход",
            "Раскладки RU/EN и Alt+Shift", "HKCU\\Keyboard Layout\\Preload и Toggle", RecoveryOps.RepairKeyboardLayouts),

        new("desktop", "Оболочка и «Пуск»",
            "Рабочий стол, панель задач, меню «Пуск»", "NoDesktop, NoTaskbar, NoTrayItemsDisplay и др.", RecoveryOps.RepairShellRestrictions),
        new("power", "Оболочка и «Пуск»",
            "Кнопки питания и завершения работы", "NoClose, DisablePowerButton", RecoveryOps.RepairPowerButton),
        new("logoff", "Оболочка и «Пуск»",
            "Выход из системы", "NoLogoff, DisableLogoff, StartMenuLogoff", RecoveryOps.RepairLogOff),

        new("ifeo", "Перехваты запуска (отладчики)",
            "IFEO Debugger и тихие перехваты", "Debugger, GlobalFlag, VerifierDlls, FilterFullPath, MitigationOptions (HKLM+HKCU, оба представления)", RecoveryOps.CleanIfeoDebuggers),
        new("appinit", "Перехваты запуска (отладчики)",
            "AppInit_DLLs", "DLL в каждый процесс — очистка и LoadAppInit_DLLs=0", RecoveryOps.CleanAppInitDlls),
        new("lsa", "Перехваты запуска (отладчики)",
            "Пакеты LSA", "Notification Packages: только scecli/rassfm/pku2u", RecoveryOps.CleanLsaNotificationPackages),
        new("notify", "Перехваты запуска (отладчики)",
            "Winlogon Notify", "Устаревшие перехватчики входа", RecoveryOps.CleanWinlogonNotify),
        new("shell", "Перехваты запуска (отладчики)",
            "Оболочка и Winlogon", "Shell, Userinit, UIHost, Taskman, AppSetup", RecoveryOps.RestoreShellAndWinlogon),
        new("bootexec", "Перехваты запуска (отладчики)",
            "BootExecute", "autocheck autochk *", RecoveryOps.RestoreBootExecute),

        new("disallow", "Прочее",
            "Запрет запуска программ", "DisallowRun, RestrictRun и их подключи", RecoveryOps.RepairDisallowRestrict),
        new("drives", "Прочее",
            "Скрытые диски", "NoDrives, NoViewOnDrive", RecoveryOps.RepairHiddenDrives),
        new("hidden", "Прочее",
            "Показ скрытых и системных файлов", "Hidden, ShowSuperHidden, NoHidden", RecoveryOps.RepairHiddenFiles),
        new("accounts", "Прочее",
            "Политики учётных записей и автовход", "DontDisplayLastUserName, NoAddUser, AutoAdminLogon/DefaultPassword", RecoveryOps.RepairAccountPolicies),
        new("setup", "Прочее",
            "SYSTEM\\Setup\\CmdLine", "Перехват первичной настройки системы", RecoveryOps.RepairSetupCmdLine),
        new("uac", "Прочее",
            "UAC", "EnableLUA=1, ConsentPromptBehaviorAdmin=5", RecoveryOps.RepairUac),
        new("assoc", "Прочее",
            "Ассоциации файлов", "exe/com/bat/cmd/reg/msc/scr/pif/lnk", RecoveryOps.RepairFileAssociations),
        new("defender", "Прочее",
            "Политики Windows Defender", "DisableAntiSpyware и политики мониторинга", RecoveryOps.RepairDefenderPolicies),
        new("theme", "Прочее",
            "Цветовая тема Windows", "Стандартные цвета и DWM", RecoveryOps.RepairThemeColors),
        new("fonts", "Прочее",
            "Стандартные шрифты", "Реестр шрифтов и подстановки", RecoveryOps.RepairFonts),
        new("cursor", "Прочее",
            "Курсор мыши", "EnableCursorSuppression, размер курсора", RecoveryOps.RepairCursorSuppression),
        new("explorer", "Прочее",
            "Перезапуск Проводника", "Применение изменений оболочки", RecoveryOps.RunExplorerRestart),
    };

    /// <summary>Всё, кроме перезапуска Проводника — он выполняется последним.</summary>
    public static List<RecoveryItem> All() => Items.ToList();

    public static RecoveryItem? Find(string id) =>
        Items.FirstOrDefault(i => i.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
}

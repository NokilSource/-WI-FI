using Microsoft.Win32;
using System.Diagnostics;
using System.Text;
using AegisKit.Core.Logging;

namespace AegisKit.Core.Recovery;

/// <summary>
/// Восстановление системных компонентов после блокировок малварью.
/// Ключи соответствуют модулю DefenderUtils образца RecoveryKit (uTaskManager, uUac,
/// uNoRun, uExplorerDrives, uFileAssociationRepair, uThemeRestore, uFontRestore и др.).
/// </summary>
public static partial class RecoveryOps
{
    private const string PoliciesSystem = @"Software\Microsoft\Windows\CurrentVersion\Policies\System";
    private const string PoliciesExplorer = @"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer";
    private const string Advanced = @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";
    private const string Ifeo = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options";

    private static bool DelValue(RegistryKey baseKey, string keyPath, string valueName, string label)
    {
        try
        {
            using var key = baseKey.OpenSubKey(keyPath, true);
            if (key == null)
            {
                SimpleLog.Info($"{label}: ключ отсутствует — блокировка не применялась");
                return true;
            }
            bool exists = key.GetValueNames()
                .Any(n => n.Equals(valueName, StringComparison.OrdinalIgnoreCase));
            if (!exists)
            {
                SimpleLog.Info($"{label}: значение {valueName} отсутствует — ок");
                return true;
            }
            key.DeleteValue(valueName, false);
            SimpleLog.Ok($"{label}: удалено значение {valueName}");
            return true;
        }
        catch (UnauthorizedAccessException)
        {
            SimpleLog.Error($"{label}: доступ запрещён (запустите AegisKit от администратора)");
            return false;
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"{label}: {ex.Message}");
            return false;
        }
    }

    private static (RegistryKey hklm, RegistryKey hkcu) Bases() => (
        RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64),
        RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64));

    // ---------- 1. Диспетчер задач / Редактор реестра / клавиши ----------

    public static void RepairTaskManager()
    {
        var (hklm, hkcu) = Bases();
        using (hklm) using (hkcu)
        {
            DelValue(hkcu, PoliciesSystem, "DisableTaskMgr", "Диспетчер задач HKCU");
            DelValue(hklm, PoliciesSystem, "DisableTaskMgr", "Диспетчер задач HKLM");
        }
    }

    public static void RepairRegistryTools()
    {
        var (hklm, hkcu) = Bases();
        using (hklm) using (hkcu)
        {
            DelValue(hkcu, PoliciesSystem, "DisableRegistryTools", "Редактор реестра HKCU");
            DelValue(hklm, PoliciesSystem, "DisableRegistryTools", "Редактор реестра HKLM");
        }
    }

    public static void RepairHotKeys()
    {
        var (hklm, hkcu) = Bases();
        using (hklm) using (hkcu)
        {
            DelValue(hkcu, PoliciesExplorer, "NoWinKeys", "Клавиша Win HKCU");
            DelValue(hklm, PoliciesExplorer, "NoWinKeys", "Клавиша Win HKLM");
            DelValue(hkcu, PoliciesSystem, "DisableLockWorkstation", "Блокировка рабочей станции");
            DelValue(hkcu, PoliciesSystem, "DisableChangePassword", "Смена пароля");
            DelValue(hkcu, PoliciesSystem, "NoLogoff", "Выход из системы");
            DelValue(hkcu, PoliciesSystem, "HideFastUserSwitching", "Быстрая смена пользователя");
        }
    }

    public static void RepairRunDialog()
    {
        var (_, hkcu) = Bases();
        using (hkcu) DelValue(hkcu, PoliciesExplorer, "NoRun", "Диалог «Выполнить»");
    }

    public static void RepairControlPanel()
    {
        var (hklm, hkcu) = Bases();
        using (hklm) using (hkcu)
        {
            DelValue(hkcu, PoliciesExplorer, "NoControlPanel", "Панель управления HKCU");
            DelValue(hklm, PoliciesExplorer, "NoControlPanel", "Панель управления HKLM");
            DelValue(hkcu, PoliciesExplorer, "NoSetFolders", "Настройка папок");
        }
    }

    public static void RepairCommandPrompt()
    {
        var (hklm, hkcu) = Bases();
        using (hklm) using (hkcu)
        {
            // Политика DisableCMD живёт в двух местах: устаревшее Policies\System
            // и современное Software\Policies\Microsoft\Windows\System.
            const string modern = @"Software\Policies\Microsoft\Windows\System";
            DelValue(hkcu, PoliciesSystem, "DisableCMD", "Командная строка HKCU");
            DelValue(hklm, PoliciesSystem, "DisableCMD", "Командная строка HKLM");
            DelValue(hkcu, modern, "DisableCMD", "Командная строка (политики) HKCU");
            DelValue(hklm, modern, "DisableCMD", "Командная строка (политики) HKLM");
        }
    }

    public static void RepairFolderOptions()
    {
        var (hklm, hkcu) = Bases();
        using (hklm) using (hkcu)
        {
            DelValue(hkcu, PoliciesExplorer, "NoFolderOptions", "Параметры папок HKCU");
            DelValue(hklm, PoliciesExplorer, "NoFolderOptions", "Параметры папок HKLM");
        }
    }

    // ---------- 2. UAC ----------

    public static void RepairUac()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(PoliciesSystem, true);
            if (key == null) { SimpleLog.Error("UAC: ключ Policies\\System не найден"); return; }
            key.SetValue("EnableLUA", 1, RegistryValueKind.DWord);
            key.SetValue("ConsentPromptBehaviorAdmin", 5, RegistryValueKind.DWord);
            key.SetValue("PromptOnSecureDesktop", 1, RegistryValueKind.DWord);
            SimpleLog.Ok("UAC восстановлен: EnableLUA=1, ConsentPromptBehaviorAdmin=5, PromptOnSecureDesktop=1");
            SimpleLog.Warn("Требуется перезагрузка для вступления в силу.");
        }
        catch (UnauthorizedAccessException)
        {
            SimpleLog.Error("UAC: доступ запрещён — запустите AegisKit от администратора");
        }
        catch (Exception ex) { SimpleLog.Error($"UAC: {ex.Message}"); }
    }

    // ---------- 3. Скрытые диски и файлы ----------

    public static void RepairHiddenDrives()
    {
        var (hklm, hkcu) = Bases();
        using (hklm) using (hkcu)
        {
            DelValue(hkcu, PoliciesExplorer, "NoDrives", "Скрытие дисков HKCU");
            DelValue(hklm, PoliciesExplorer, "NoDrives", "Скрытие дисков HKLM");
            DelValue(hkcu, PoliciesExplorer, "NoViewOnDrive", "Просмотр дисков HKCU");
            DelValue(hklm, PoliciesExplorer, "NoViewOnDrive", "Просмотр дисков HKLM");
        }
    }

    public static void RepairHiddenFiles()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(Advanced, true);
            if (key != null)
            {
                key.SetValue("Hidden", 1, RegistryValueKind.DWord);
                key.SetValue("ShowSuperHidden", 1, RegistryValueKind.DWord);
                key.SetValue("HideFileExt", 0, RegistryValueKind.DWord);
            }
            var (hklm, hkcu) = Bases();
            using (hklm) using (hkcu)
            {
                DelValue(hkcu, PoliciesExplorer, "NoHidden", "Политика скрытых файлов");
                DelValue(hkcu, PoliciesExplorer, "NoSuperHidden", "Политика системных файлов");
                DelValue(hklm, PoliciesExplorer, "NoHidden", "Политика скрытых файлов HKLM");
                DelValue(hklm, PoliciesExplorer, "NoSuperHidden", "Политика системных файлов HKLM");
            }
            SimpleLog.Ok("Показ скрытых и системных файлов включён");
        }
        catch (Exception ex) { SimpleLog.Error($"Скрытые файлы: {ex.Message}"); }
    }

    // ---------- 4. gpedit.msc и оснастки MMC ----------

    public static void RepairGpedit()
    {
        var (hklm, hkcu) = Bases();
        using (hklm) using (hkcu)
        {
            DelValue(hkcu, @"Software\Policies\Microsoft\MMC", "RestrictToPermittedSnapins", "MMC: ограничение оснасток HKCU");
            DelValue(hklm, @"Software\Policies\Microsoft\MMC", "RestrictToPermittedSnapins", "MMC: ограничение оснасток HKLM");
        }
        var gpedit = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "gpedit.msc");
        if (File.Exists(gpedit))
        {
            SimpleLog.Ok($"gpedit.msc найден: {gpedit}");
            try
            {
                Process.Start(new ProcessStartInfo(gpedit) { UseShellExecute = true });
            }
            catch (Exception ex) { SimpleLog.Warn($"Не удалось открыть gpedit.msc: {ex.Message}"); }
        }
        else
        {
            SimpleLog.Warn("gpedit.msc отсутствует в системе (Home-редакция?). Попробуйте установить компоненты GroupPolicy.");
        }
    }


    // ---------- 6. Ассоциации файлов (.exe, .bat, .lnk, .reg, .cmd, .com, .msc) ----------

    private record AssocEntry(string Ext, string ProgId, string ContentType, string OpenCommand);

    private static readonly AssocEntry[] Associations =
    {
        new(".exe", "exefile", "application/x-msdownload", "\"%1\" %*"),
        new(".com", "comfile", "application/octet-stream", "\"%1\" %*"),
        new(".bat", "batfile", "text/plain", "\"%1\" %*"),
        new(".cmd", "cmdfile", "text/plain", "\"%1\" %*"),
        new(".reg", "regfile", "", "regedit.exe \"%1\""),
        new(".msc", "mscfile", "", "%SystemRoot%\\system32\\mmc.exe \"%1\" %*"),
        new(".scr", "scrfile", "application/x-msdownload", "\"%1\" /S"),
        new(".pif", "piffile", "", "\"%1\" %*"),
    };

    public static void RepairFileAssociations()
    {
        try
        {
            foreach (var h in new[] { true, false })
            {
                RegistryKey baseKey = h
                    ? RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64)
                    : RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64);
                using (baseKey)
                {
                    var classes = baseKey.OpenSubKey("Software\\Classes", true);
                    if (classes == null) continue;
                    using (classes)
                    {
                        foreach (var a in Associations)
                        {
                            using var ext = classes.CreateSubKey(a.Ext);
                            if (a.ProgId.Length > 0) ext.SetValue("", a.ProgId);
                            if (a.ContentType.Length > 0) ext.SetValue("Content Type", a.ContentType);

                            var progIdKey = classes.CreateSubKey(a.ProgId);
                            progIdKey.SetValue("FriendlyTypeName", FriendlyName(a.ProgId));
                            using var cmd = progIdKey.CreateSubKey("shell\\open\\command");
                            cmd.SetValue("", a.OpenCommand);
                        }
                        // .lnk — восстановление класса ярлыков
                        using var lnk = classes.CreateSubKey(".lnk");
                        lnk.SetValue("", "lnkfile");
                        using var lnkCls = classes.CreateSubKey("lnkfile");
                        lnkCls.SetValue("IsShortcut", "");
                    }
                }
            }

            // Сброс пользовательских перехватов (UserChoice с битым хешем)
            var userChoiceRoot = Registry.CurrentUser.OpenSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts", true);
            if (userChoiceRoot != null)
                using (userChoiceRoot)
                    foreach (var ext in Associations.Select(a => a.Ext))
                    {
                        var ucKey = userChoiceRoot.OpenSubKey(ext + "\\UserChoice", true);
                        if (ucKey == null) continue;
                        var progId = ucKey.GetValue("ProgId")?.ToString() ?? "";
                        using (ucKey)
                        {
                            var expected = ExpectedUserChoice(ext);
                            if (progId.Length > 0 && expected != null && !progId.Equals(expected, StringComparison.OrdinalIgnoreCase))
                            {
                                try
                                {
                                    userChoiceRoot.DeleteSubKeyTree(ext + "\\UserChoice");
                                    SimpleLog.Ok($"UserChoice сброшен для {ext} (был: {progId})");
                                }
                                catch { }
                            }
                        }
                    }

            SimpleLog.Ok("Ассоциации файлов восстановлены: exe/com/bat/cmd/reg/msc/scr/pif/lnk");
            SimpleLog.Warn("Перезапустите Проводник или перезагрузитесь, если ассоциации не применились.");
        }
        catch (UnauthorizedAccessException) { SimpleLog.Error("Ассоциации: доступ запрещён (нужны права администратора)"); }
        catch (Exception ex) { SimpleLog.Error($"Ассоциации: {ex.Message}"); }
    }

    private static string FriendlyName(string progId) => progId switch
    {
        "exefile" => "Приложение",
        "comfile" => "Приложение MS-DOS",
        "batfile" => "Пакетный файл Windows",
        "cmdfile" => "Командный сценарий Windows",
        "regfile" => "Параметры реестра",
        "mscfile" => "Оснастка консоли MMC",
        "scrfile" => "Экранная заставка",
        "piffile" => "Ярлык программы MS-DOS",
        _ => progId
    };

    private static string? ExpectedUserChoice(string ext) => ext switch
    {
        ".exe" => "Applications\\Explorer.exe",
        ".bat" => "batfile",
        ".cmd" => "cmdfile",
        ".reg" => "regfile",
        _ => null
    };

    // ---------- 7. Тема и цвета ----------

    private static readonly (string Name, string Value)[] DefaultColors =
    {
        ("ActiveBorder", "212 208 200"), ("ActiveTitle", "153 180 209"),
        ("AppWorkSpace", "171 171 171"), ("Background", "0 0 0"),
        ("ButtonAlternateFace", "181 181 181"), ("ButtonDkShadow", "105 105 105"),
        ("ButtonFace", "240 240 240"), ("ButtonHilight", "255 255 255"),
        ("ButtonLight", "227 227 227"), ("ButtonShadow", "160 160 160"),
        ("ButtonText", "0 0 0"), ("GradientActiveTitle", "185 209 234"),
        ("GradientInactiveTitle", "215 228 242"), ("GrayText", "109 109 109"),
        ("Hilight", "0 120 215"), ("HilightText", "255 255 255"),
        ("HotTrackingColor", "0 102 204"), ("InactiveBorder", "244 247 252"),
        ("InactiveTitle", "191 205 219"), ("InactiveTitleText", "0 0 0"),
        ("InfoText", "0 0 0"), ("InfoWindow", "255 255 225"),
        ("Menu", "240 240 240"), ("MenuBar", "240 240 240"),
        ("MenuHilight", "0 120 215"), ("MenuText", "0 0 0"),
        ("Scrollbar", "200 200 200"), ("TitleText", "0 0 0"),
        ("Window", "255 255 255"), ("WindowFrame", "100 100 100"),
        ("WindowText", "0 0 0"),
    };

    public static void RepairThemeColors()
    {
        try
        {
            using var colors = Registry.CurrentUser.CreateSubKey(@"Control Panel\Colors", true);
            foreach (var (name, value) in DefaultColors)
                colors.SetValue(name, value);

            using var dwm = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\DWM", true);
            dwm.SetValue("AccentColor", 0xFF0078D7u, RegistryValueKind.DWord); // #0078D7 (BGRA)
            dwm.SetValue("AccentColorInactive", 0xFF43413Au, RegistryValueKind.DWord);
            dwm.SetValue("ColorPrevalence", 0, RegistryValueKind.DWord);

            using var personalize = Registry.CurrentUser.CreateSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", true);
            personalize.SetValue("AppsUseLightTheme", 1, RegistryValueKind.DWord);
            personalize.SetValue("SystemUsesLightTheme", 1, RegistryValueKind.DWord);
            personalize.SetValue("EnableTransparency", 1, RegistryValueKind.DWord);

            SimpleLog.Ok("Цвета Windows и DWM восстановлены к стандартным");
            SimpleLog.Info("Перезапустите Проводник для применения.");
        }
        catch (Exception ex) { SimpleLog.Error($"Тема: {ex.Message}"); }
    }

    // ---------- 8. Шрифты ----------

    private static readonly (string Name, string File)[] StandardFonts =
    {
        ("Segoe UI (TrueType)", "segoeui.ttf"),
        ("Segoe UI Bold (TrueType)", "segoeuib.ttf"),
        ("Segoe UI Semibold (TrueType)", "segoeuisl.ttf"),
        ("Segoe UI Italic (TrueType)", "segoeuii.ttf"),
        ("Segoe UI Bold Italic (TrueType)", "segoeuiz.ttf"),
        ("Tahoma (TrueType)", "tahoma.ttf"),
        ("Tahoma Bold (TrueType)", "tahomabd.ttf"),
        ("Microsoft Sans Serif (TrueType)", "micross.ttf"),
        ("Arial (TrueType)", "arial.ttf"),
        ("Arial Bold (TrueType)", "arialbd.ttf"),
        ("Courier New (TrueType)", "cour.ttf"),
        ("Courier New Bold (TrueType)", "courbd.ttf"),
        ("Times New Roman (TrueType)", "times.ttf"),
        ("Times New Roman Bold (TrueType)", "timesbd.ttf"),
        ("Verdana (TrueType)", "verdana.ttf"),
        ("Verdana Bold (TrueType)", "verdanab.ttf"),
        ("Calibri (TrueType)", "calibri.ttf"),
        ("Calibri Bold (TrueType)", "calibrib.ttf"),
        ("Cambria (TrueType)", "cambria.ttc"),
        ("Consolas (TrueType)", "consola.ttf"),
        ("Trebuchet MS (TrueType)", "trebuc.ttf"),
        ("Symbol (TrueType)", "symbol.ttf"),
        ("Wingdings (TrueType)", "wingding.ttf"),
    };

    private static readonly (string Name, string Subst)[] StandardSubstitutes =
    {
        ("MS Shell Dlg", "Microsoft Sans Serif"),
        ("MS Shell Dlg 2", "Tahoma"),
        ("MS UI Gothic", "MS UI Gothic"),
        ("MS Gothic", "MS Gothic"),
        ("MS PGothic", "MS PGothic"),
        ("MS Serif", "MS Serif"),
        ("MS Sans Serif", "Microsoft Sans Serif"),
        ("Helv", "MS Sans Serif"),
        ("Arial", "Arial"),
        ("Courier", "Courier New"),
        ("Courier New", "Courier New"),
        ("Times", "Times New Roman"),
        ("Times New Roman", "Times New Roman"),
        ("Trebuchet MS", "Trebuchet MS"),
        ("Verdana", "Verdana"),
    };

    public static void RepairFonts()
    {
        try
        {
            var winFonts = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Fonts");
            using var fonts = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows NT\CurrentVersion\Fonts", true);
            int restored = 0;
            foreach (var (name, file) in StandardFonts)
                if (File.Exists(Path.Combine(winFonts, file)))
                {
                    fonts.SetValue(name, file);
                    restored++;
                }

            using var subst = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows NT\CurrentVersion\FontSubstitutes", true);
            foreach (var (name, s) in StandardSubstitutes)
                subst.SetValue(name, s);

            SimpleLog.Ok($"Шрифты восстановлены ({restored} записей + подстановки)");
            SimpleLog.Info("Требуется перезагрузка.");
        }
        catch (Exception ex) { SimpleLog.Error($"Шрифты: {ex.Message}"); }
    }

    // ---------- 9. Политики Windows Defender ----------

    public static void RepairDefenderPolicies()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender", true);
            if (key != null)
                foreach (var value in new[]
                {
                    "DisableAntiSpyware", "DisableAntiVirus", "DisableRoutinelyTakingAction",
                    "PUAProtection", "AllowFastServiceStartup", "ServiceKeepAlive"
                })
                    if (key.GetValueNames().Any(n => n.Equals(value, StringComparison.OrdinalIgnoreCase)))
                        key.DeleteValue(value, false);

            using var rtp = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection", true);
            if (rtp != null)
                foreach (var value in new[] { "DisableRealtimeMonitoring", "DisableBehaviorMonitoring", "DisableOnAccessProtection", "DisableScanOnRealtimeEnable" })
                    if (rtp.GetValueNames().Any(n => n.Equals(value, StringComparison.OrdinalIgnoreCase)))
                        rtp.DeleteValue(value, false);

            SimpleLog.Ok("Политики-ограничители Windows Defender удалены");
        }
        catch (Exception ex) { SimpleLog.Error($"Defender: {ex.Message}"); }
    }

    // ---------- 10. SFC / DISM ----------

    public static void RunSfc(Action<string> onOutput, Action<int>? onExit = null)
    {
        RunConsole("sfc.exe", "/scannow", onOutput, onExit);
    }

    public static void RunDism(Action<string> onOutput, Action<int>? onExit = null)
    {
        RunConsole("dism.exe", "/Online /Cleanup-Image /RestoreHealth", onOutput, onExit);
    }

    /// <summary>Универсальный запуск системной проверки с выводом строк.</summary>
    public static void RunSfc2(string exe, string args, Action<string> onOutput, Action<int>? onExit = null)
    {
        RunConsole(exe, args, onOutput, onExit);
    }

    public static void RunExplorerRestart()
    {
        try
        {
            foreach (var p in Process.GetProcessesByName("explorer"))
            {
                p.Kill();
                p.Dispose();
            }
            Thread.Sleep(800);
            Process.Start("explorer.exe");
            SimpleLog.Ok("Проводник перезапущен");
        }
        catch (Exception ex) { SimpleLog.Error($"Перезапуск Проводника: {ex.Message}"); }
    }

    private static void RunConsole(string exe, string args, Action<string> onOutput, Action<int>? onExit)
    {
        try
        {
            SimpleLog.Command($"{exe} {args}");
            // Вывод sfc/dism локализован и приходит в OEM-кодировке (cp866).
            // Encoding.GetEncoding(866) без CodePagesEncodingProvider выбрасывает
            // NotSupportedException — раньше это срывало запуск до старта процесса.
            var oem = Compat.CodePages.Oem ?? Encoding.UTF8;
            var psi = new ProcessStartInfo
            {
                FileName = exe,
                Arguments = args,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = oem,
                StandardErrorEncoding = oem
            };
            var p = Process.Start(psi)!;
            p.OutputDataReceived += (_, e) => { if (e.Data != null) onOutput(e.Data); };
            p.ErrorDataReceived += (_, e) => { if (e.Data != null) onOutput(e.Data); };
            p.BeginOutputReadLine();
            p.BeginErrorReadLine();
            Task.Run(() =>
            {
                p.WaitForExit();
                SimpleLog.Info($"{exe} завершён с кодом {p.ExitCode}");
                onExit?.Invoke(p.ExitCode);
            });
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"{exe}: {ex.Message}");
            onExit?.Invoke(-1);
        }
    }
}

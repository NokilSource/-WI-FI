using AegisKit.Core.Logging;

namespace AegisKit.Core.Recovery;

/// <summary>Очистка временных директорий и Prefetch.</summary>
public static class TempCleaner
{
    public static string UserTemp => Environment.GetEnvironmentVariable("TEMP")
        ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Temp");

    public static string WindowsTemp => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp");

    public static string Prefetch => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Prefetch");

    public static string UserStartup => Environment.GetFolderPath(Environment.SpecialFolder.Startup);

    public static string CommonStartup => Environment.ExpandEnvironmentVariables(
        Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup));

    public static long GetFolderSize(string path)
    {
        try
        {
            if (!Directory.Exists(path)) return 0;
            return new DirectoryInfo(path)
                .EnumerateFiles("*", SearchOption.AllDirectories)
                .Sum(f => { try { return f.Length; } catch { return 0L; } });
        }
        catch { return 0; }
    }

    /// <summary>Очистка каталога: удаление файлов и подпапок (занятые пропускаются).</summary>
    public static (int files, long bytes) CleanFolder(string path, string label, int onlyOlderThanDays = 0)
    {
        int files = 0;
        long bytes = 0;
        if (!Directory.Exists(path))
        {
            SimpleLog.Info($"{label}: папка отсутствует ({path})");
            return (0, 0);
        }
        try
        {
            var deadline = DateTime.Now.AddDays(-onlyOlderThanDays);
            foreach (var f in Directory.EnumerateFiles(path))
            {
                try
                {
                    var fi = new FileInfo(f);
                    if (onlyOlderThanDays > 0 && fi.LastWriteTime > deadline) continue;
                    var size = fi.Length;
                    File.SetAttributes(f, FileAttributes.Normal);
                    File.Delete(f);
                    files++;
                    bytes += size;
                }
                catch { }
            }
            foreach (var d in Directory.EnumerateDirectories(path))
            {
                try { Directory.Delete(d, true); }
                catch { }
            }
            SimpleLog.Ok($"{label}: удалено {files} файлов ({bytes / 1024.0 / 1024.0:F1} МБ)");
        }
        catch (Exception ex) { SimpleLog.Error($"{label}: {ex.Message}"); }
        return (files, bytes);
    }

    public static void CleanAll()
    {
        SimpleLog.Info("=== Очистка временных файлов ===");
        var (_, b1) = CleanFolder(UserTemp, "Временные файлы пользователя (%TEMP%)");
        var (_, b2) = CleanFolder(WindowsTemp, "Временные файлы Windows");
        var (_, b3) = CleanFolder(Prefetch, "Prefetch");
        SimpleLog.Ok($"Итого освобождено: {(b1 + b2 + b3) / 1024.0 / 1024.0:F1} МБ");
    }
}

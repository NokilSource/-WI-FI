using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.Text;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;

namespace AegisKit.Core.RegOps;

/// <summary>Узел дерева реестра (для TreeView, ленивое раскрытие).</summary>
public class RegNode
{
    public string Name { get; set; } = "";
    /// <summary>Полный путь: HKLM\Software\... или MOUNT:<name>\...</summary>
    public string FullPath { get; set; } = "";
    public bool IsRoot { get; set; }
    public bool IsMountedHive { get; set; }

    /// <summary>
    /// Именно ObservableCollection: при ленивой подгрузке подключаются заменяются
    /// на реальные, и TreeView узнаёт об этом только по CollectionChanged.
    /// С List&lt;T&gt; дерево оставалось с заглушкой «…» — ключи «не раскрывались».
    /// </summary>
    public ObservableCollection<RegNode> Children { get; } = new();

    public bool HasDummyChild { get; set; } = true;

    public override string ToString() => Name;
}

/// <summary>Одно значение реестра.</summary>
public class RegValue
{
    public string Name { get; set; } = "";
    public RegistryValueKind Kind { get; set; }
    public object? Data { get; set; }

    public string KindName => Kind switch
    {
        RegistryValueKind.String => "REG_SZ",
        RegistryValueKind.ExpandString => "REG_EXPAND_SZ",
        RegistryValueKind.Binary => "REG_BINARY",
        RegistryValueKind.DWord => "REG_DWORD",
        RegistryValueKind.QWord => "REG_QWORD",
        RegistryValueKind.MultiString => "REG_MULTI_SZ",
        RegistryValueKind.None => "REG_NONE",
        _ => "REG_UNKNOWN"
    };

    public string DisplayData => Format(Data, Kind);

    public static string Format(object? data, RegistryValueKind kind)
    {
        if (data is null) return "(значение не установлено)";
        return kind switch
        {
            RegistryValueKind.Binary when data is byte[] bytes =>
                "(двоичное) " + Convert.ToHexString(bytes)[..Math.Min(64, bytes.Length * 2)] +
                (bytes.Length * 2 > 64 ? $"… ({bytes.Length} байт)" : ""),
            RegistryValueKind.DWord => $"0x{Convert.ToUInt32(data):x8} ({Convert.ToUInt32(data)})",
            RegistryValueKind.QWord => $"0x{Convert.ToUInt64(data):x16} ({Convert.ToUInt64(data)})",
            RegistryValueKind.MultiString when data is string[] arr => string.Join(" | ", arr),
            RegistryValueKind.None when data is byte[] rawNone =>
                "(нет типа) " + Convert.ToHexString(rawNone)[..Math.Min(64, rawNone.Length * 2)],
            _ => data.ToString() ?? ""
        };
    }
}

/// <summary>
/// Движок редактора реестра. Работает со стандартными разделами и с автономными
/// кустами, смонтированными через RegLoadKey (для WinRE/офлайн-анализа).
/// </summary>
public static class RegistryEditor
{
    public const string MountPrefix = "MOUNT:";

    private static readonly (string Name, RegistryHive Hive)[] Roots =
    {
        ("HKEY_LOCAL_MACHINE", RegistryHive.LocalMachine),
        ("HKEY_CURRENT_USER", RegistryHive.CurrentUser),
        ("HKEY_CLASSES_ROOT", RegistryHive.ClassesRoot),
        ("HKEY_USERS", RegistryHive.Users),
        ("HKEY_CURRENT_CONFIG", RegistryHive.CurrentConfig),
    };

    public static List<RegNode> GetRootNodes()
    {
        var nodes = new List<RegNode>();
        foreach (var (name, _) in Roots)
        {
            var n = new RegNode { Name = name, FullPath = name, IsRoot = true };
            n.Children.Add(new RegNode { Name = "…", FullPath = "DUMMY", HasDummyChild = true });
            nodes.Add(n);
        }

        // Смонтированные автономные кусты (отображаются отдельными корнями).
        // Без пиктограмм: подпись — просто «Куст: имя».
        foreach (var m in RegistryHiveService.GetMounted())
        {
            var n = new RegNode
            {
                Name = $"Куст: {m.MountName}",
                FullPath = MountPrefix + m.MountPoint,
                IsRoot = true,
                IsMountedHive = true
            };
            n.Children.Add(new RegNode { Name = "…", FullPath = "DUMMY", HasDummyChild = true });
            nodes.Add(n);
        }
        return nodes;
    }

    /// <summary>
    /// Путь в том виде, в котором его показывает штатный редактор:
    /// <c>Компьютер\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft</c>.
    /// Смонтированный куст выводится как <c>Куст: имя\ControlSet001\Services</c>.
    /// </summary>
    public static string DisplayPath(string fullPath)
    {
        if (string.IsNullOrEmpty(fullPath)) return "Компьютер";
        if (fullPath.StartsWith(MountPrefix, StringComparison.OrdinalIgnoreCase))
        {
            var rest = fullPath[MountPrefix.Length..];
            // rest = HKLM\AegisKitHives\<имя>\...
            var parts = rest.Split('\\', 4);
            var name = parts.Length > 2 ? parts[2] : rest;
            var tail = parts.Length > 3 ? parts[3] : "";
            return string.IsNullOrEmpty(tail) ? $"Куст: {name}" : $"Куст: {name}\\{tail}";
        }
        return "Компьютер\\" + fullPath;
    }

    /// <summary>
    /// Разбивает путь на сегменты для навигационной строки («хлебных крошек»).
    /// Первый сегмент — корень («Компьютер»), последний — текущий раздел.
    /// Возвращаются пары «подпись + путь», чтобы по каждому сегменту можно было перейти.
    /// </summary>
    public static List<(string Label, string Path)> Breadcrumb(string fullPath)
    {
        var result = new List<(string, string)> { ("Компьютер", "") };
        if (string.IsNullOrEmpty(fullPath)) return result;

        if (fullPath.StartsWith(MountPrefix, StringComparison.OrdinalIgnoreCase))
        {
            var rest = fullPath[MountPrefix.Length..];
            var parts = rest.Split('\\');
            var name = parts.Length > 2 ? parts[2] : rest;
            result.Add(($"Куст: {name}", MountPrefix + (parts.Length > 2 ? string.Join('\\', parts[..3]) : rest)));
            var built = parts.Length > 2 ? string.Join('\\', parts[..3]) : rest;
            for (int i = 3; i < parts.Length; i++)
            {
                built += "\\" + parts[i];
                result.Add((parts[i], MountPrefix + built));
            }
            return result;
        }

        var segments = fullPath.Split('\\');
        var current = segments[0];
        result.Add((segments[0], current));
        for (int i = 1; i < segments.Length; i++)
        {
            if (segments[i].Length == 0) continue;
            current += "\\" + segments[i];
            result.Add((segments[i], current));
        }
        return result;
    }

    /// <summary>Открывает реальный ключ по логическому пути (с учётом монтирований).</summary>
    /// <remarks>
    /// Понимает полные имена (HKEY_LOCAL_MACHINE\...), короткие (HKLM\..., HKCU\...,
    /// HKCR\..., HKU\..., HKCC\...) и префикс «Компьютер\» из штатного Regedit.
    /// </remarks>
    public static RegistryKey? OpenKey(string fullPath, bool writable = false)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(fullPath)) return null;

            if (fullPath.StartsWith(MountPrefix, StringComparison.OrdinalIgnoreCase))
            {
                var mountPath = fullPath[MountPrefix.Length..];
                // mountPath = HKLM\<mountname>\... — открыть через реальный hive
                return RegistryHiveService.OpenMounted(mountPath, writable);
            }

            var normalized = NormalizeHiveName(fullPath.Trim().TrimEnd('\\'));
            if (normalized is null) return null;

            int idx = normalized.IndexOf('\\');
            var rootName = idx > 0 ? normalized[..idx] : normalized;
            var sub = idx > 0 ? normalized[(idx + 1)..] : null;

            RegistryHive hive = rootName.ToUpperInvariant() switch
            {
                "HKEY_LOCAL_MACHINE" => RegistryHive.LocalMachine,
                "HKEY_CURRENT_USER" => RegistryHive.CurrentUser,
                "HKEY_CLASSES_ROOT" => RegistryHive.ClassesRoot,
                "HKEY_USERS" => RegistryHive.Users,
                "HKEY_CURRENT_CONFIG" => RegistryHive.CurrentConfig,
                _ => (RegistryHive)(-1)
            };
            if ((int)hive == -1) return null;

            var baseKey = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64);
            return sub is null ? baseKey : baseKey.OpenSubKey(sub, writable);
        }
        catch (Exception ex)
        {
            // Недоступные для чтения разделы (SECURITY, SAM и т.п.) — норма, а не сбой
            if (writable) SimpleLog.Error($"Открытие ключа для записи {fullPath}: {ex.Message}");
            else SimpleLog.Warn($"Раздел недоступен: {fullPath} ({ex.Message})");
            return null;
        }
    }

    /// <summary>Приводит короткие имена кустов и префикс Regedit к полному виду.</summary>
    public static string? NormalizeHiveName(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return null;
        var p = path.Trim();
        const string computerPrefix = "Компьютер\\";
        if (p.StartsWith(computerPrefix, StringComparison.OrdinalIgnoreCase))
            p = p[computerPrefix.Length..];
        // Короткие имена — только в начале пути
        var aliases = new (string Short, string Full)[]
        {
            ("HKLM\\", "HKEY_LOCAL_MACHINE\\"), ("HKLM", "HKEY_LOCAL_MACHINE"),
            ("HKCU\\", "HKEY_CURRENT_USER\\"), ("HKCU", "HKEY_CURRENT_USER"),
            ("HKCR\\", "HKEY_CLASSES_ROOT\\"), ("HKCR", "HKEY_CLASSES_ROOT"),
            ("HKU\\", "HKEY_USERS\\"), ("HKU", "HKEY_USERS"),
            ("HKCC\\", "HKEY_CURRENT_CONFIG\\"), ("HKCC", "HKEY_CURRENT_CONFIG"),
        };
        foreach (var (shortName, full) in aliases)
        {
            if (p.Equals(shortName, StringComparison.OrdinalIgnoreCase) ||
                p.StartsWith(shortName, StringComparison.OrdinalIgnoreCase) && shortName.EndsWith("\\"))
                return full + p[shortName.Length..];
            if (p.Equals(shortName, StringComparison.OrdinalIgnoreCase))
                return full;
        }
        return p;
    }

    public static List<RegNode> GetSubKeys(string fullPath)
    {
        var list = new List<RegNode>();
        using var key = OpenKey(fullPath);
        if (key == null)
        {
            SimpleLog.Warn($"Раздел недоступен для чтения: {fullPath}");
            return list;
        }
        try
        {
            foreach (var name in key.GetSubKeyNames())
            {
                var child = new RegNode { Name = name, FullPath = fullPath + "\\" + name };
                child.Children.Add(new RegNode { Name = "…", FullPath = "DUMMY", HasDummyChild = true });
                list.Add(child);
            }
        }
        catch (Exception ex)
        {
            SimpleLog.Warn($"Чтение подключей {fullPath}: {ex.Message}");
        }
        return list.OrderBy(c => c.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    public static List<RegValue> GetValues(string fullPath)
    {
        var list = new List<RegValue>();
        using var key = OpenKey(fullPath);
        if (key == null) return list;
        foreach (var name in key.GetValueNames())
        {
            try
            {
                list.Add(new RegValue
                {
                    Name = name.Length == 0 ? "(По умолчанию)" : name,
                    Kind = key.GetValueKind(name),
                    Data = key.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames)
                });
            }
            catch { }
        }
        return list.OrderBy(v => v.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    public static bool DeleteKey(string fullPath)
    {
        try
        {
            int idx = fullPath.LastIndexOf('\\');
            if (idx <= 0) return false;
            var parent = fullPath[..idx];
            var name = fullPath[(idx + 1)..];
            using var pk = OpenKey(parent, writable: true);
            if (pk == null) return false;
            pk.DeleteSubKeyTree(name, false);
            SimpleLog.Ok($"Удалён ключ: {fullPath}");
            return true;
        }
        catch (Exception ex) { SimpleLog.Error($"Удаление ключа: {ex.Message}"); return false; }
    }

    public static bool CreateKey(string parentPath, string name)
    {
        try
        {
            using var pk = OpenKey(parentPath, writable: true);
            if (pk == null) return false;
            pk.CreateSubKey(name);
            SimpleLog.Ok($"Создан ключ: {parentPath}\\{name}");
            return true;
        }
        catch (Exception ex) { SimpleLog.Error($"Создание ключа: {ex.Message}"); return false; }
    }

    public static bool DeleteValue(string keyPath, string valueName)
    {
        try
        {
            using var k = OpenKey(keyPath, writable: true);
            if (k == null) return false;
            var name = valueName == "(По умолчанию)" ? "" : valueName;
            k.DeleteValue(name, false);
            SimpleLog.Ok($"Удалён параметр: {keyPath}\\{valueName}");
            return true;
        }
        catch (Exception ex) { SimpleLog.Error($"Удаление параметра: {ex.Message}"); return false; }
    }

    public static bool SetStringValue(string keyPath, string valueName, string data, RegistryValueKind kind)
    {
        try
        {
            using var k = OpenKey(keyPath, writable: true);
            if (k == null) return false;
            var name = valueName == "(По умолчанию)" ? "" : valueName;
            k.SetValue(name, data, kind);
            SimpleLog.Ok($"Записано: {keyPath}\\{valueName} = {data}");
            return true;
        }
        catch (Exception ex) { SimpleLog.Error($"Запись параметра: {ex.Message}"); return false; }
    }

    public static bool SetDword(string keyPath, string valueName, uint data)
    {
        try
        {
            using var k = OpenKey(keyPath, writable: true);
            if (k == null) return false;
            var name = valueName == "(По умолчанию)" ? "" : valueName;
            k.SetValue(name, data, RegistryValueKind.DWord);
            SimpleLog.Ok($"Записано: {keyPath}\\{valueName} = 0x{data:x8}");
            return true;
        }
        catch (Exception ex) { SimpleLog.Error($"Запись параметра: {ex.Message}"); return false; }
    }

    public static bool SetQword(string keyPath, string valueName, ulong data)
    {
        try
        {
            using var k = OpenKey(keyPath, writable: true);
            if (k == null) return false;
            var name = valueName == "(По умолчанию)" ? "" : valueName;
            k.SetValue(name, unchecked((long)data), RegistryValueKind.QWord);
            SimpleLog.Ok($"Записано: {keyPath}\\{valueName} = 0x{data:x16}");
            return true;
        }
        catch (Exception ex) { SimpleLog.Error($"Запись параметра: {ex.Message}"); return false; }
    }

    /// <summary>Переход к ключу в штатном Regedit (через LastKey).</summary>
    public static void OpenInRegedit(string fullPath)
    {
        try
        {
            if (fullPath.StartsWith(MountPrefix, StringComparison.OrdinalIgnoreCase))
            {
                SimpleLog.Warn("Смонтированный куст нельзя открыть в штатном Regedit — используйте встроенный редактор.");
                return;
            }
            var normalized = fullPath switch
            {
                var p when p.StartsWith("HKEY_LOCAL_MACHINE") => p.Replace("HKEY_LOCAL_MACHINE", "Компьютер\\HKEY_LOCAL_MACHINE"),
                var p when p.StartsWith("HKEY_CURRENT_USER") => p.Replace("HKEY_CURRENT_USER", "Компьютер\\HKEY_CURRENT_USER"),
                var p when p.StartsWith("HKEY_CLASSES_ROOT") => p.Replace("HKEY_CLASSES_ROOT", "Компьютер\\HKEY_CLASSES_ROOT"),
                var p when p.StartsWith("HKEY_USERS") => p.Replace("HKEY_USERS", "Компьютер\\HKEY_USERS"),
                var p when p.StartsWith("HKEY_CURRENT_CONFIG") => p.Replace("HKEY_CURRENT_CONFIG", "Компьютер\\HKEY_CURRENT_CONFIG"),
                _ => fullPath
            };
            using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Applets\Regedit", true))
                key?.SetValue("LastKey", normalized);
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("regedit.exe"));
            SimpleLog.Info($"Regedit открыт на: {normalized}");
        }
        catch (Exception ex) { SimpleLog.Error($"Regedit: {ex.Message}"); }
    }
}

/// <summary>Смонтированный автономный куст.</summary>
public record MountedHive(string MountName, string MountPoint, string HiveFile, string Base);

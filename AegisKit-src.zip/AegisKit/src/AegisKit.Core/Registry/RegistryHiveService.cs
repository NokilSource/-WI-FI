using Microsoft.Win32;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;
using static AegisKit.Core.RegOps.RegistryEditor;

namespace AegisKit.Core.RegOps;

/// <summary>
/// Монтирование и выгрузка автономных кустов реестра (RegLoadKey/RegUnLoadKey).
/// Используется для офлайн-анализа: загрузить SYSTEM/SOFTWARE/SAM-куст с другого
/// диска или из WinRE и исследовать его во встроенном редакторе.
/// </summary>
public static class RegistryHiveService
{
    /// <summary>Временная папка точек монтирования.</summary>
    public const string MountRootHklm = "AegisKitHives";
    public const string MountRootHku = "AegisKitHives";

    private static readonly List<MountedHive> Mounted = new();
    private static int _counter;

    public static List<MountedHive> GetMounted()
    {
        lock (Mounted) return Mounted.ToList();
    }

    /// <summary>Монтирует файл куста в HKLM\AegisKitHives\&lt;имя&gt;.</summary>
    public static MountedHive? Mount(string hiveFile, string? preferredName = null)
    {
        try
        {
            if (!File.Exists(hiveFile))
            {
                SimpleLog.Error($"Файл куста не найден: {hiveFile}");
                return null;
            }

            NativeMethods.EnableBackupRestorePrivileges();

            var fullFile = Path.GetFullPath(hiveFile);
            lock (Mounted)
            {
                if (Mounted.Any(m => m.HiveFile.Equals(fullFile, StringComparison.OrdinalIgnoreCase)))
                {
                    SimpleLog.Info($"Этот куст уже смонтирован: {fullFile}");
                    return Mounted.First(m => m.HiveFile.Equals(fullFile, StringComparison.OrdinalIgnoreCase));
                }

                var name = SanitizeName(preferredName ?? Path.GetFileNameWithoutExtension(hiveFile));
                string mountName = name;
                while (Mounted.Any(m => m.MountName.Equals(mountName, StringComparison.OrdinalIgnoreCase)))
                    mountName = $"{name}{++_counter}";

                var subKey = $"{MountRootHklm}\\{mountName}";

                // RegLoadKey требует, чтобы целевой подключ уже существовал: без явного
                // RegCreateKeyExW монтирование падало с ERROR_FILE_NOT_FOUND.
                int rc = NativeMethods.RegCreateKeyExW(NativeMethods.HKEY_LOCAL_MACHINE, subKey,
                    0, null, 0, NativeMethods.KEY_CREATE_SUB_KEY, IntPtr.Zero, out var createdKey, out _);
                if (rc != 0)
                {
                    SimpleLog.Error($"Не удалось создать точку монтирования {subKey}: " +
                                    $"{NativeMethods.GetWin32Message(rc)}");
                    return null;
                }
                NativeMethods.RegCloseKey(createdKey);

                rc = NativeMethods.RegLoadKey(NativeMethods.HKEY_LOCAL_MACHINE, subKey, fullFile);
                if (rc != 0)
                {
                    SimpleLog.Error($"RegLoadKey вернул {rc}: {NativeMethods.GetWin32Message(rc)}");
                    // Не оставляем пустой подключ после неудачного монтирования
                    NativeMethods.RegUnLoadKey(NativeMethods.HKEY_LOCAL_MACHINE, subKey);
                    return null;
                }

                var mh = new MountedHive(mountName,
                    $"HKLM\\{MountRootHklm}\\{mountName}", fullFile, "HKLM");
                Mounted.Add(mh);
                SimpleLog.Ok($"Куст смонтирован: {mh.HiveFile} → {mh.MountPoint}");
                return mh;
            }
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"Монтирование куста: {ex.Message}");
            return null;
        }
    }

    public static bool Unmount(MountedHive hive)
    {
        try
        {
            NativeMethods.EnableBackupRestorePrivileges();
            var subKey = hive.MountPoint["HKLM\\".Length..];
            int rc = NativeMethods.RegUnLoadKey(NativeMethods.HKEY_LOCAL_MACHINE, subKey);
            if (rc != 0)
            {
                SimpleLog.Error($"RegUnLoadKey вернул {rc}: {NativeMethods.GetWin32Message(rc)}. " +
                                "Закройте редактор реестра, просматривающий этот куст.");
                return false;
            }
            lock (Mounted) Mounted.Remove(hive);
            SimpleLog.Ok($"Куст выгружен: {hive.MountName}");
            return true;
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"Выгрузка куста: {ex.Message}");
            return false;
        }
    }

    /// <summary>Открывает ключ внутри смонтированного куста.</summary>
    public static RegistryKey? OpenMounted(string mountPath, bool writable = false)
    {
        try
        {
            // mountPath = "HKLM\AegisKitHives\Name\..."
            var rest = mountPath.StartsWith("HKLM\\", StringComparison.OrdinalIgnoreCase)
                ? mountPath[5..]
                : mountPath;
            return Microsoft.Win32.Registry.LocalMachine.OpenSubKey(rest, writable);
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"Открытие смонтированного куста: {ex.Message}");
            return null;
        }
    }

    /// <summary>Быстрый анализ смонтированного SYSTEM-куста: ключи автозапуска офлайн-системы.</summary>
    public static List<string> AuditMountedSystem(MountedHive hive)
    {
        var findings = new List<string>();
        try
        {
            var ctrlSet = FindCurrentControlSet(hive);
            if (ctrlSet is null) return findings;

            var servicesPath = $"{hive.MountPoint}\\{ctrlSet}\\Services";
            using var services = OpenMounted(servicesPath);
            if (services != null)
                foreach (var svc in services.GetSubKeyNames())
                {
                    using var k = services.OpenSubKey(svc);
                    var start = k?.GetValue("Start");
                    if (start is int s && s is 0 or 1)
                    {
                        // Драйвер/служба ранней загрузки: проверяем и ImagePath, и ServiceDll
                        var image = k?.GetValue("ImagePath")?.ToString();
                        if (!string.IsNullOrEmpty(image) && SuspiciousOfflinePath(image))
                            findings.Add($"Драйвер/служба {svc} (Start={s}) → {image}");
                        using var p = k?.OpenSubKey("Parameters");
                        var img = p?.GetValue("ServiceDll")?.ToString();
                        if (!string.IsNullOrEmpty(img) && SuspiciousOfflinePath(img))
                            findings.Add($"Драйвер/служба {svc} (Start={s}) → {img}");
                    }
                }
        }
        catch (Exception ex)
        {
            SimpleLog.Warn($"Аудит куста {hive.MountName}: {ex.Message}");
        }
        return findings;
    }

    private static string? FindCurrentControlSet(MountedHive hive)
    {
        using var select = OpenMounted($"{hive.MountPoint}\\Select");
        if (select?.GetValue("Current") is int current)
            return $"ControlSet{current:000}";
        // fallback: первый ControlSet00X
        using var root = OpenMounted(hive.MountPoint);
        return root?.GetSubKeyNames().FirstOrDefault(n => n.StartsWith("ControlSet00"));
    }

    private static bool SuspiciousOfflinePath(string path)
    {
        var expanded = Environment.ExpandEnvironmentVariables(path);
        var p = expanded.ToLowerInvariant();
        // Узко: только временные/пользовательские места, а не весь C:\Users
        return p.Contains("\\temp\\") || p.Contains("\\tmp\\") || p.Contains("\\appdata\\") ||
               p.Contains(":\\users\\public\\") ||
               (p.Contains(":\\programdata\\") && !p.Contains("\\microsoft\\"));
    }

    private static string SanitizeName(string name)
    {
        var sb = new System.Text.StringBuilder();
        foreach (var c in name.Where(char.IsLetterOrDigit).Take(40))
            sb.Append(c);
        return sb.Length == 0 ? "Hive" + Environment.TickCount % 1000 : sb.ToString();
    }
}

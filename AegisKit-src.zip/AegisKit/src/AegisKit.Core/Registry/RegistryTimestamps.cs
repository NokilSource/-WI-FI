using System.Runtime.InteropServices;
using AegisKit.Core.Native;

namespace AegisKit.Core.RegOps;

/// <summary>
/// Время последнего изменения ключа реестра. Управляемый API не отдаёт эту
/// информацию вообще, поэтому читаем её напрямую через RegQueryInfoKey —
/// это честная дата «когда запись автозапуска появилась или была изменена».
/// </summary>
public static class RegistryTimestamps
{
    [StructLayout(LayoutKind.Sequential)]
    private struct NativeFileTime
    {
        public uint Low;
        public uint High;
    }

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern int RegOpenKeyExW(UIntPtr hKey, string subKey, uint options,
        uint samDesired, out UIntPtr result);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern int RegQueryInfoKeyW(UIntPtr hKey, IntPtr className, IntPtr classLen,
        IntPtr reserved, IntPtr subKeys, IntPtr maxSubKeyLen, IntPtr maxClassLen,
        IntPtr values, IntPtr maxValueNameLen, IntPtr maxValueLen,
        IntPtr securityDescriptor, out NativeFileTime lastWriteTime);

    private const uint KEY_READ = 0x20019;
    private const int ErrorSuccess = 0;
    private static readonly UIntPtr HKEY_CURRENT_USER = new(0x80000001u);

    /// <summary>Время последней записи ключа или null, если ключ недоступен.</summary>
    public static DateTime? GetKeyWriteTime(UIntPtr hive, string subKey)
    {
        UIntPtr key = UIntPtr.Zero;
        try
        {
            if (RegOpenKeyExW(hive, subKey, 0, KEY_READ, out key) != ErrorSuccess) return null;
            if (RegQueryInfoKeyW(key, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero,
                    IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero,
                    IntPtr.Zero, out var ft) != ErrorSuccess)
                return null;

            long ticks = ((long)ft.High << 32) | ft.Low;
            if (ticks <= 0) return null;
            var utc = DateTime.FromFileTimeUtc(ticks);
            // Нулевые/битые даты (например 1601 год) не показываем — это отсутствие данных.
            return utc.Year < 1990 ? null : utc.ToLocalTime();
        }
        catch
        {
            return null;
        }
        finally
        {
            if (key != UIntPtr.Zero) NativeMethods.RegCloseKey(key);
        }
    }

    /// <summary>Время записи ключа по строке «HKLM\...» / «HKCU\...» / «HKU\...».</summary>
    public static DateTime? ForPath(string? hiveAndPath)
    {
        if (string.IsNullOrWhiteSpace(hiveAndPath)) return null;
        var text = hiveAndPath.Trim();
        int slash = text.IndexOf('\\');
        var hiveName = slash > 0 ? text[..slash] : text;
        var subKey = slash > 0 ? text[(slash + 1)..] : "";

        var hive = hiveName.ToUpperInvariant() switch
        {
            "HKLM" or "HKEY_LOCAL_MACHINE" => NativeMethods.HKEY_LOCAL_MACHINE,
            "HKU" or "HKEY_USERS" => NativeMethods.HKEY_USERS,
            "HKCU" or "HKEY_CURRENT_USER" => HKEY_CURRENT_USER,
            _ => UIntPtr.Zero
        };
        if (hive == UIntPtr.Zero) return null;
        return GetKeyWriteTime(hive, subKey);
    }
}

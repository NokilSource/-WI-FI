using System.Diagnostics;
using System.Text;
using System.Text.Json;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;

namespace AegisKit.Core.Scheduler;

/// <summary>Задача планировщика.</summary>
public class TaskRow
{
    public string FolderPath { get; set; } = "\\";   // "\Microsoft\Windows\..."
    public string Name { get; set; } = "";
    public string State { get; set; } = "";
    public bool Enabled { get; set; }
    public string Created { get; set; } = "";
    public string NextRun { get; set; } = "";
    public string LastRun { get; set; } = "";
    public string LastResult { get; set; } = "";
    public string Author { get; set; } = "";
    public string Description { get; set; } = "";
    public string Command { get; set; } = "";
    public string ResolvedPath { get; set; } = "";
    /// <summary>Полный путь к XML-файлу задачи (C:\Windows\System32\Tasks\...).</summary>
    public string TaskFile { get; set; } = "";
    public string Company { get; set; } = "";
    public bool Signed { get; set; }
    public bool SignatureChecked { get; set; }
    public bool Suspicious { get; set; }
    public string Reasons { get; set; } = "";
    public bool IsMicrosoft => FolderPath.Contains("\\Microsoft\\", StringComparison.OrdinalIgnoreCase);

    public string Verdict => Suspicious ? "Подозрительно" : SignatureChecked && !Signed ? "Без подписи" : "";
    /// <summary>Алиас для общей подсветки строк (красным).</summary>
    public bool Marked => Suspicious;
    /// <summary>Алиас для общего стиля VerdictCell (ToolTip с причинами).</summary>
    public string SuspiciousReasons => Reasons;

    public string FullPath => FolderPath.EndsWith("\\") ? FolderPath + Name : FolderPath + "\\" + Name;
}

/// <summary>
/// Бэкенд планировщика задач: Get-ScheduledTask через встроенный PowerShell с обменом
/// JSON. Вывод намеренно приводится к чистому ASCII (\uXXXX-escape) — иначе OEM-кодировка
/// консоли (cp866 на русской Windows) превращает JSON в мусор и разбор падает целиком.
/// </summary>
public static class TaskSchedulerService
{
    /// <summary>Общее начало всех скриптов: ASCII-безопасный экспорт JSON.</summary>
    private const string Prelude = """
        $ErrorActionPreference='SilentlyContinue'
        function ConvertTo-AsciiJson($obj) {
            $json = $obj | ConvertTo-Json -Depth 3 -Compress
            if ($null -eq $json) { return '[]' }
            $sb = New-Object System.Text.StringBuilder
            foreach ($ch in $json.ToCharArray()) {
                $code = [int]$ch
                if ($code -gt 127) { [void]$sb.AppendFormat('\u{0:x4}', $code) } else { [void]$sb.Append($ch) }
            }
            return $sb.ToString()
        }
        """;

    private const string ListScript = Prelude + """

        $out = Get-ScheduledTask | ForEach-Object {
            $t = $_
            $info = $null
            try { $info = $t | Get-ScheduledTaskInfo } catch {}
            $enabled = $true
            try { if ($t.Settings.Enabled -eq $false) { $enabled = $false } } catch {}
            try { if ($t.State -eq 'Disabled') { $enabled = $false } } catch {}
            $cmd = ''
            try { $cmd = ($t.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' ; ' } catch {}
            [PSCustomObject]@{
                Path = $t.TaskPath
                Name = $t.TaskName
                State = [string]$t.State
                Enabled = $enabled
                Date = "$($t.Date)"
                Author = "$($t.Author)"
                Description = "$($t.Description)"
                Command = $cmd
                NextRun = if ($info) { "$($info.NextRunTime)" } else { '' }
                LastRun = if ($info) { "$($info.LastRunTime)" } else { '' }
                LastResult = if ($info) { "$($info.LastTaskResult)" } else { '' }
            }
        }
        ConvertTo-AsciiJson $out
        """;

    public static List<TaskRow> ListTasks()
    {
        var fromPowerShell = ListTasksViaPowerShell();
        var list = fromPowerShell.Count > 0
            ? fromPowerShell
            // Запасной путь: PowerShell в WinRE и в урезанных сборках Windows
            // отсутствует или заблокирован политикой. schtasks.exe есть всегда.
            : FallbackToSchtasks();

        FillTaskFilesAndDates(list);
        return list;
    }

    private static List<TaskRow> FallbackToSchtasks()
    {
        SimpleLog.Warn("Планировщик: перехожу на schtasks.exe (PowerShell недоступен)");
        return ListTasksViaSchtasks();
    }

    /// <summary>Путь к XML-файлу задачи в C:\Windows\System32\Tasks.</summary>
    public static string TaskFilePath(TaskRow task)
    {
        var relative = (task.FolderPath ?? "\\").TrimStart('\\').Replace('\\', Path.DirectorySeparatorChar);
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),
            "Tasks", relative, task.Name);
    }

    /// <summary>
    /// Дополняет строки тем, что не всегда отдаёт планировщик: путь к файлу задачи и
    /// дату создания. Дата создания берётся из XML-файла задачи — это надёжнее,
    /// чем поле RegistrationInfo, которое часто пустое.
    /// </summary>
    private static void FillTaskFilesAndDates(List<TaskRow> list)
    {
        foreach (var t in list)
        {
            try
            {
                var file = TaskFilePath(t);
                t.TaskFile = file;
                if (string.IsNullOrWhiteSpace(t.Created) && File.Exists(file))
                    t.Created = File.GetCreationTime(file).ToString("dd.MM.yyyy HH:mm");
            }
            catch { /* метаданные не критичны */ }
        }
    }

    private static List<TaskRow> ListTasksViaPowerShell()
    {
        var json = RunPowerShell(ListScript, timeoutSec: 180);
        var list = new List<TaskRow>();
        if (string.IsNullOrWhiteSpace(json))
        {
            SimpleLog.Warn("Планировщик: PowerShell не вернул данные " +
                           "(проверьте, что powershell.exe доступен и не заблокирован политикой).");
            return list;
        }

        try
        {
            using var doc = JsonDocument.Parse(json);
            IEnumerable<JsonElement> elements = doc.RootElement.ValueKind switch
            {
                JsonValueKind.Array => doc.RootElement.EnumerateArray(),
                JsonValueKind.Object => new[] { doc.RootElement.Clone() },
                _ => Array.Empty<JsonElement>()
            };
            foreach (var el in elements)
            {
                var row = new TaskRow
                {
                    FolderPath = Str(el, "Path"),
                    Name = Str(el, "Name"),
                    State = Str(el, "State"),
                    Enabled = Bool(el, "Enabled"),
                    Created = Str(el, "Date"),
                    Author = Str(el, "Author"),
                    Description = Str(el, "Description"),
                    Command = Str(el, "Command"),
                    NextRun = Str(el, "NextRun"),
                    LastRun = Str(el, "LastRun"),
                    LastResult = Str(el, "LastResult")
                };
                if (string.IsNullOrEmpty(row.FolderPath)) row.FolderPath = "\\";
                row.ResolvedPath = ExtractPath(row.Command);
                list.Add(row);
            }
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"Разбор списка задач не удался: {ex.Message} " +
                            $"(получено символов: {json.Length})");
            return list;
        }

        // Метаданные файла и подпись считаются один раз на уникальный путь
        foreach (var group in list.Where(t => !string.IsNullOrEmpty(t.ResolvedPath) && File.Exists(t.ResolvedPath))
                                   .GroupBy(t => t.ResolvedPath, StringComparer.OrdinalIgnoreCase))
        {
            string company = "";
            bool signed = false;
            try { company = FileVersionInfo.GetVersionInfo(group.Key).CompanyName ?? ""; } catch { }
            try { signed = NativeMethods.VerifyFileSignature(group.Key); } catch { }
            foreach (var t in group)
            {
                t.Company = company;
                t.Signed = signed;
                t.SignatureChecked = true;
            }
        }

        foreach (var t in list) Evaluate(t);
        return Deduplicate(list);
    }

    /// <summary>
    /// Убирает дубли по полному пути. Get-ScheduledTask в теории уникален, но
    /// при смешанных представлениях реестра и повторных вызовах возможны повторы —
    /// в таблице они выглядели как «слишком много задач».
    /// </summary>
    private static List<TaskRow> Deduplicate(List<TaskRow> rows)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var result = new List<TaskRow>(rows.Count);
        foreach (var r in rows)
            if (seen.Add(r.FullPath)) result.Add(r);
        if (result.Count != rows.Count)
            SimpleLog.Warn($"Планировщик: отброшено дубликатов — {rows.Count - result.Count}");
        return result;
    }

    /// <summary>
    /// Чтение задач через schtasks.exe /query /xml ONE. Вывод пишется в файл
    /// (schtasks печатает в UTF-16LE с BOM), затем разбирается как XML.
    /// Ни один элемент не зависит от языка системы: пути берутся из &lt;URI&gt;.
    /// </summary>
    public static List<TaskRow> ListTasksViaSchtasks()
    {
        var list = new List<TaskRow>();
        var temp = Path.Combine(Path.GetTempPath(), $"aegiskit_tasks_{Environment.TickCount64}.xml");
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = "schtasks.exe",
                Arguments = $"/query /xml ONE /f",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true
            };
            // Перехватываем stdout и сохраняем своими средствами — BOM разберём сами.
            using var p = Process.Start(psi);
            if (p == null) return list;
            using (var fs = File.Create(temp))
            {
                p.StandardOutput.BaseStream.CopyTo(fs);
            }
            p.WaitForExit(180000);

            var text = ReadTextWithBom(temp);
            if (text.Length == 0)
            {
                SimpleLog.Warn("schtasks.exe не вернул данных");
                return list;
            }
            var doc = System.Xml.Linq.XDocument.Parse(text);
            foreach (var task in doc.Descendants().Where(e => e.Name.LocalName == "Task"))
            {
                var row = new TaskRow();
                var uri = task.Descendants().FirstOrDefault(e => e.Name.LocalName == "URI")?.Value ?? "";
                if (uri.Length == 0) continue;
                int slash = uri.TrimEnd('\\').LastIndexOf('\\');
                row.Name = slash >= 0 ? uri[(slash + 1)..] : uri;
                row.FolderPath = slash > 0 ? uri[..(slash + 1)] : "\\";
                if (row.FolderPath.Length == 0) row.FolderPath = "\\";

                var reg = task.Descendants().FirstOrDefault(e => e.Name.LocalName == "RegistrationInfo");
                row.Author = reg?.Descendants().FirstOrDefault(e => e.Name.LocalName == "Author")?.Value ?? "";
                row.Description = reg?.Descendants().FirstOrDefault(e => e.Name.LocalName == "Description")?.Value ?? "";

                var settings = task.Descendants().FirstOrDefault(e => e.Name.LocalName == "Settings");
                var enabled = settings?.Descendants().FirstOrDefault(e => e.Name.LocalName == "Enabled")?.Value;
                row.Enabled = enabled == null || enabled.Equals("true", StringComparison.OrdinalIgnoreCase);
                row.State = row.Enabled ? "Готово" : "Отключено";

                var start = task.Descendants().FirstOrDefault(e => e.Name.LocalName == "StartBoundary")?.Value;
                row.NextRun = start ?? "";

                var commands = task.Descendants().Where(e => e.Name.LocalName == "Exec").Select(e =>
                {
                    var cmd = e.Descendants().FirstOrDefault(x => x.Name.LocalName == "Command")?.Value ?? "";
                    var arg = e.Descendants().FirstOrDefault(x => x.Name.LocalName == "Arguments")?.Value ?? "";
                    return (cmd + " " + arg).Trim();
                }).Where(c => c.Length > 0).ToList();
                row.Command = string.Join(" ; ", commands);
                row.ResolvedPath = ExtractPath(row.Command);
                list.Add(row);
            }
            SimpleLog.Info($"schtasks.exe: получено задач — {list.Count}");

            foreach (var group in list.Where(t => !string.IsNullOrEmpty(t.ResolvedPath) && File.Exists(t.ResolvedPath))
                                       .GroupBy(t => t.ResolvedPath, StringComparer.OrdinalIgnoreCase))
            {
                string company = "";
                bool signed = false;
                try { company = FileVersionInfo.GetVersionInfo(group.Key).CompanyName ?? ""; } catch { }
                try { signed = NativeMethods.VerifyFileSignature(group.Key); } catch { }
                foreach (var t in group)
                {
                    t.Company = company;
                    t.Signed = signed;
                    t.SignatureChecked = true;
                }
            }
            foreach (var t in list) Evaluate(t);
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"schtasks.exe: {ex.Message}");
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch { }
        }
        return Deduplicate(list);
    }

    /// <summary>Читает файл, определяя кодировку по BOM (schtasks пишет UTF-16LE).</summary>
    private static string ReadTextWithBom(string path)
    {
        var bytes = File.ReadAllBytes(path);
        if (bytes.Length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE)
            return Encoding.Unicode.GetString(bytes, 2, bytes.Length - 2);
        if (bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF)
            return Encoding.UTF8.GetString(bytes, 3, bytes.Length - 3);
        return Encoding.UTF8.GetString(bytes);
    }

    /// <summary>Вердикт: сильные признаки — «Подозрительно», неподписанный файл — «Без подписи».</summary>
    public static void Evaluate(TaskRow t)
    {
        var strong = new List<string>();
        var weak = new List<string>();

        if (!string.IsNullOrEmpty(t.ResolvedPath))
        {
            var loc = Processes.SuspicionRules.ClassifyLocation(t.ResolvedPath);
            if (loc is Processes.SuspicionRules.LocTemp or Processes.SuspicionRules.LocDownload)
                strong.Add("Команда ведёт во временный каталог или загрузки");
            else if (loc == Processes.SuspicionRules.LocUser)
                weak.Add("Команда ведёт в пользовательский каталог");

            if (!File.Exists(t.ResolvedPath) && !t.ResolvedPath.Contains('%') &&
                !t.ResolvedPath.Contains("powershell", StringComparison.OrdinalIgnoreCase) &&
                !t.ResolvedPath.Contains("cmd", StringComparison.OrdinalIgnoreCase) &&
                !t.ResolvedPath.Contains("schtasks", StringComparison.OrdinalIgnoreCase) &&
                !t.ResolvedPath.Contains("rundll32", StringComparison.OrdinalIgnoreCase) &&
                !t.ResolvedPath.Contains("msiexec", StringComparison.OrdinalIgnoreCase))
                strong.Add("Файл команды не найден на диске");
        }

        var cmd = t.Command.ToLowerInvariant();
        if (cmd.Contains("-enc") || cmd.Contains("-encodedcommand") || cmd.Contains("frombase64"))
            strong.Add("Обфусцированная команда (encoded/base64)");
        if (cmd.Contains("hidden") && cmd.Contains("powershell"))
            strong.Add("Скрытый запуск PowerShell");
        if (cmd.Contains("downloadstring") || cmd.Contains("invoke-webrequest") ||
            cmd.Contains("downloadfile") || cmd.Contains("webclient") ||
            (cmd.Contains("http://") || cmd.Contains("https://")) && cmd.Contains("iex"))
            strong.Add("Признаки сетевой загрузки в команде");
        if (cmd.Contains("bypass") && cmd.Contains("hidden"))
            strong.Add("Обход политики выполнения");

        if (t.SignatureChecked && !t.Signed && !Processes.SuspicionRules.IsTrustedPublisher(t.Company))
            weak.Add("Нет действительной цифровой подписи");

        t.Reasons = string.Join("; ", strong.Concat(weak.Select(w => w + " (слабый признак)")));
        t.Suspicious = strong.Count > 0;
    }

    private static string Str(JsonElement el, string prop) =>
        el.TryGetProperty(prop, out var v) ? v.ToString() ?? "" : "";

    private static bool Bool(JsonElement el, string prop) =>
        el.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.True;

    private static string ExtractPath(string command)
    {
        if (string.IsNullOrWhiteSpace(command)) return "";
        var c = command.Trim();
        if (c.StartsWith('"'))
        {
            int end = c.IndexOf('"', 1);
            if (end > 0) return c[1..end];
        }
        // Жадный разбор незакавыченных путей с пробелами (C:\Program Files\...),
        // иначе возвращается пусто и эвристика слепнет
        var greedy = LongestExistingExePrefix(c);
        if (!string.IsNullOrEmpty(greedy)) return greedy;
        var space = c.IndexOf(' ');
        var token = space > 0 ? c[..space] : c;
        if (token.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && token.Contains('\\')) return token;
        return "";
    }

    private static string LongestExistingExePrefix(string command)
    {
        try
        {
            string best = "";
            for (int i = 0; i < command.Length; i++)
            {
                if (command[i] != ' ') continue;
                var candidate = command[..i].Trim().Trim('"').TrimEnd(',', ';');
                if (candidate.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && File.Exists(candidate))
                    best = candidate;
            }
            var whole = command.Trim().Trim('"').TrimEnd(',', ';');
            if (whole.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && File.Exists(whole))
                return whole;
            return best;
        }
        catch { return ""; }
    }

    public static bool SetEnabled(TaskRow task, bool enabled)
    {
        var action = enabled ? "Enable-ScheduledTask" : "Disable-ScheduledTask";
        var script = Prelude + "\n" +
            $"{action} -TaskPath '{Esc(task.FolderPath)}' -TaskName '{Esc(task.Name)}' -ErrorAction Stop | Out-Null; 'OK'";
        var res = RunPowerShell(script, timeoutSec: 60);
        var ok = res?.Contains("OK") == true;
        if (ok) SimpleLog.Ok($"{(enabled ? "Включена" : "Отключена")} задача: {task.FullPath}");
        else SimpleLog.Error($"Не удалось {(enabled ? "включить" : "отключить")} задачу {task.FullPath} (нужны права администратора)");
        return ok;
    }

    public static bool Delete(TaskRow task)
    {
        var script = Prelude + "\n" +
            $"Unregister-ScheduledTask -TaskPath '{Esc(task.FolderPath)}' -TaskName '{Esc(task.Name)}' -Confirm:$false -ErrorAction Stop; 'OK'";
        var res = RunPowerShell(script, timeoutSec: 60);
        var ok = res?.Contains("OK") == true;
        if (ok) SimpleLog.Ok($"Удалена задача: {task.FullPath}");
        else SimpleLog.Error($"Не удалось удалить задачу {task.FullPath}");
        return ok;
    }

    public static bool RunNow(TaskRow task)
    {
        var script = Prelude + "\n" +
            $"Start-ScheduledTask -TaskPath '{Esc(task.FolderPath)}' -TaskName '{Esc(task.Name)}' -ErrorAction Stop; 'OK'";
        var res = RunPowerShell(script, timeoutSec: 60);
        var ok = res?.Contains("OK") == true;
        if (ok) SimpleLog.Ok($"Задача запущена: {task.FullPath}");
        else SimpleLog.Error($"Не удалось запустить задачу {task.FullPath}");
        return ok;
    }

    private static string Esc(string s) => s.Replace("'", "''");

    public static void OpenTaskFile(TaskRow task)
    {
        // XML задач лежит в C:\Windows\System32\Tasks\<путь>
        var file = string.IsNullOrEmpty(task.TaskFile) ? TaskFilePath(task) : task.TaskFile;
        if (File.Exists(file))
        {
            try
            {
                Process.Start(new ProcessStartInfo("notepad.exe", $"\"{file}\"") { UseShellExecute = true });
                return;
            }
            catch { }
        }
        // fallback: открыть сам планировщик
        try
        {
            Process.Start(new ProcessStartInfo("taskschd.msc") { UseShellExecute = true });
        }
        catch (Exception ex) { SimpleLog.Error($"taskschd.msc: {ex.Message}"); }
    }

    private static string? RunPowerShell(string script, int timeoutSec)
    {
        try
        {
            // -EncodedCommand (UTF-16LE base64) — неуязвимо к кавычкам и переносам строк
            var encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
            var psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = $"-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand {encoded}",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            using var p = Process.Start(psi);
            if (p == null)
            {
                SimpleLog.Error("PowerShell: не удалось запустить процесс");
                return null;
            }
            // Оба потока читаются асинхронно — иначе переполнение буфера stderr даёт дедлок
            var outTask = p.StandardOutput.ReadToEndAsync();
            var errTask = p.StandardError.ReadToEndAsync();
            if (!p.WaitForExit(timeoutSec * 1000))
            {
                try { p.Kill(true); } catch { }
                SimpleLog.Error($"PowerShell: превышен таймаут {timeoutSec} с");
                return null;
            }
            var output = outTask.GetAwaiter().GetResult();
            var err = errTask.GetAwaiter().GetResult();
            if (string.IsNullOrWhiteSpace(output) && !string.IsNullOrWhiteSpace(err))
                SimpleLog.Warn($"PowerShell stderr: {FirstLines(err, 3)}");
            return output;
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"PowerShell: {ex.Message}");
            return null;
        }
    }

    /// <summary>stderr PowerShell приходит в CLIXML — для журнала оставляем только текст.</summary>
    private static string FirstLines(string text, int count)
    {
        var lines = text.Split('\n', StringSplitOptions.RemoveEmptyEntries)
                        .Select(l => l.Trim())
                        .Where(l => l.Length > 0 && !l.StartsWith("<") && !l.StartsWith("#<"))
                        .Take(count)
                        .ToList();
        return lines.Count > 0 ? string.Join(" / ", lines) : "(без подробностей)";
    }
}

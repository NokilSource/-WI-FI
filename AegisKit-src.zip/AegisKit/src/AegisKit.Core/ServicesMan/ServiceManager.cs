using System.Runtime.InteropServices;
using System.Text;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;

namespace AegisKit.Core.ServicesMan;

/// <summary>Служба Windows для таблицы.</summary>
public class ServiceRow
{
    public string Name { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string Description { get; set; } = "";
    public int Pid { get; set; }
    public int StartType { get; set; }
    public int CurrentState { get; set; }
    public string BinaryPath { get; set; } = "";
    public string Account { get; set; } = "";
    public int ServiceType { get; set; }
    public string Reasons { get; set; } = "";
    public bool Suspicious { get; set; }

    public string Verdict => Suspicious ? "Подозрительно" : SignatureChecked && !Signed ? "Без подписи" : "";
    /// <summary>Алиас для общей подсветки строк (красным).</summary>
    public bool Marked => Suspicious;
    public bool SignatureChecked { get; set; }
    public bool Signed { get; set; }
    /// <summary>Алиас для общего стиля VerdictCell (ToolTip с причинами).</summary>
    public string SuspiciousReasons => Reasons;

    public string StartTypeName => StartType switch
    {
        NativeMethods.SERVICE_AUTO_START => "Авто",
        NativeMethods.SERVICE_DEMAND_START => "Вручную",
        NativeMethods.SERVICE_DISABLED => "Отключена",
        NativeMethods.SERVICE_BOOT_START => "Загрузка",
        NativeMethods.SERVICE_SYSTEM_START => "Система",
        _ => $"({StartType})"
    };

    public string StateName => CurrentState switch
    {
        NativeMethods.SERVICE_RUNNING => "Работает",
        NativeMethods.SERVICE_STOPPED => "Остановлена",
        NativeMethods.SERVICE_START_PENDING => "Запускается…",
        NativeMethods.SERVICE_STOP_PENDING => "Останавливается…",
        NativeMethods.SERVICE_PAUSE_PENDING => "Приостанавливается…",
        NativeMethods.SERVICE_PAUSED => "Приостановлена",
        _ => $"({CurrentState})"
    };

    public bool IsDriver => (ServiceType & (NativeMethods.SERVICE_KERNEL_DRIVER | NativeMethods.SERVICE_FILE_SYSTEM_DRIVER)) != 0;

    public string TypeString => IsDriver ? "Драйвер" :
        (ServiceType & NativeMethods.SERVICE_WIN32_SHARE_PROCESS) != 0 ? "Общий процесс" : "Свой процесс";
}

/// <summary>Менеджер служб на API SCM: перечисление, старт/стоп, тип запуска, удаление.</summary>
public static class ServiceManager
{
    public static List<ServiceRow> Enumerate()
    {
        var rows = new List<ServiceRow>();
        // Для перечисления достаточно SC_MANAGER_CONNECT | SC_MANAGER_ENUMERATE_SERVICE:
        // с SC_MANAGER_ALL_ACCESS запрос падал с «Отказано в доступе» без полного админа.
        var scm = NativeMethods.OpenSCManager(null, null, NativeMethods.SC_MANAGER_CONNECT | NativeMethods.SC_MANAGER_ENUMERATE_SERVICE);
        if (scm == IntPtr.Zero)
        {
            SimpleLog.Error($"OpenSCManager: {NativeMethods.GetWin32Message(Marshal.GetLastWin32Error())}");
            return rows;
        }
        try
        {
            int size = 64 * 1024;
            int needed = 0;
            int returned = 0;
            IntPtr buffer = Marshal.AllocHGlobal(size);
            try
            {
                for (int attempt = 0; attempt < 4; attempt++)
                {
                    // Включаем драйверы ядра/ФС: руткиты и малварь-драйверы иначе невидимы.
                    // Чекбокс «Скрыть драйверы» в UI как раз рассчитан на их наличие.
                    bool ok = NativeMethods.EnumServicesStatusEx(
                        scm, NativeMethods.SC_ENUM_PROCESS_INFO,
                        NativeMethods.SERVICE_WIN32_OWN_PROCESS | NativeMethods.SERVICE_WIN32_SHARE_PROCESS | NativeMethods.SERVICE_INTERACTIVE_PROCESS |
                        NativeMethods.SERVICE_KERNEL_DRIVER | NativeMethods.SERVICE_FILE_SYSTEM_DRIVER,
                        NativeMethods.SERVICE_STATE_ALL,
                        buffer, size, out needed, out returned, out _, null);
                    if (ok) break;
                    int err = Marshal.GetLastWin32Error();
                    if (err == 234 /*ERROR_MORE_DATA*/) { size = needed; Marshal.FreeHGlobal(buffer); buffer = Marshal.AllocHGlobal(size); continue; }
                    SimpleLog.Error($"EnumServicesStatusEx: {NativeMethods.GetWin32Message(err)}");
                    return rows;
                }

                int structSize = Marshal.SizeOf<ENUM_SERVICE_STATUS_PROCESS_NATIVE>();
                for (int i = 0; i < returned; i++)
                {
                    IntPtr p = (IntPtr)((nint)buffer + i * structSize);
                    var s = Marshal.PtrToStructure<ENUM_SERVICE_STATUS_PROCESS_NATIVE>(p);
                    var row = new ServiceRow
                    {
                    Name = ReadSz(s.ServiceName),
                    DisplayName = ReadSz(s.DisplayName),
                    CurrentState = s.Status.CurrentState,
                    ServiceType = s.Status.ServiceType,
                    Pid = s.Status.ProcessId
                };
                FillConfig(row, scm);
                rows.Add(row);
                }
            }
            finally { Marshal.FreeHGlobal(buffer); }
        }
        finally { NativeMethods.CloseServiceHandle(scm); }

        return rows.OrderBy(r => r.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 0)]
    private struct ENUM_SERVICE_STATUS_PROCESS_NATIVE
    {
        public IntPtr ServiceName;
        public IntPtr DisplayName;
        public NativeMethods.SERVICE_STATUS_PROCESS Status;
    }

    private static string ReadSz(IntPtr ptr) => Marshal.PtrToStringUni(ptr) ?? "";

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 0)]
    private struct QUERY_SERVICE_CONFIG_NATIVE
    {
        public int ServiceType;
        public int StartType;
        public int ErrorControl;
        public IntPtr BinaryPathName;
        public IntPtr LoadOrderGroup;
        public uint TagId;
        public IntPtr Dependencies;
        public IntPtr ServiceStartName;
        public IntPtr DisplayName;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 0)]
    private struct SERVICE_DESCRIPTION_NATIVE
    {
        public IntPtr lpDescription;
    }

    private static void FillConfig(ServiceRow row, IntPtr scm)
    {
        var svc = NativeMethods.OpenService(scm, row.Name, NativeMethods.SERVICE_QUERY_CONFIG);
        if (svc == IntPtr.Zero) return;
        try
        {
            if (!NativeMethods.QueryServiceConfig(svc, IntPtr.Zero, 0, out int needed) && needed > 0)
                {
                    IntPtr buf = Marshal.AllocHGlobal(needed);
                    try
                    {
                        if (NativeMethods.QueryServiceConfig(svc, buf, needed, out _))
                        {
                            var cfg = Marshal.PtrToStructure<QUERY_SERVICE_CONFIG_NATIVE>(buf);
                            row.StartType = cfg.StartType;
                            row.ServiceType = cfg.ServiceType;
                            row.BinaryPath = ReadSz(cfg.BinaryPathName);
                            row.Account = ReadSz(cfg.ServiceStartName);
                            if (string.IsNullOrEmpty(row.Account)) row.Account = "LocalSystem";
                        }
                    }
                    finally { Marshal.FreeHGlobal(buf); }
                }

                if (!NativeMethods.QueryServiceConfig2(svc, NativeMethods.SERVICE_CONFIG_DESCRIPTION, IntPtr.Zero, 0, out int need2) && need2 > 0)
                {
                    IntPtr buf2 = Marshal.AllocHGlobal(need2);
                    try
                    {
                        if (NativeMethods.QueryServiceConfig2(svc, NativeMethods.SERVICE_CONFIG_DESCRIPTION, buf2, need2, out _))
                        {
                            var d = Marshal.PtrToStructure<SERVICE_DESCRIPTION_NATIVE>(buf2);
                            row.Description = ReadSz(d.lpDescription);
                        }
                    }
                    finally { Marshal.FreeHGlobal(buf2); }
                }
            }
            finally { NativeMethods.CloseServiceHandle(svc); }
    }

    public static bool Start(string name)
    {
        NativeMethods.EnableDebugPrivilege();
        var scm = NativeMethods.OpenSCManager(null, null, NativeMethods.SC_MANAGER_CONNECT);
        if (scm == IntPtr.Zero) return Fail("OpenSCManager");
        try
        {
            var svc = NativeMethods.OpenService(scm, name, NativeMethods.SERVICE_START | NativeMethods.SERVICE_QUERY_STATUS);
            if (svc == IntPtr.Zero) return Fail($"OpenService({name})");
            try
            {
                bool ok = NativeMethods.StartService(svc, 0, IntPtr.Zero);
                if (!ok) return Fail($"StartService({name})");
                SimpleLog.Ok($"Служба запущена: {name}");
                return true;
            }
            finally { NativeMethods.CloseServiceHandle(svc); }
        }
        finally { NativeMethods.CloseServiceHandle(scm); }
    }

    public static bool Stop(string name)
    {
        var scm = NativeMethods.OpenSCManager(null, null, NativeMethods.SC_MANAGER_CONNECT);
        if (scm == IntPtr.Zero) return Fail("OpenSCManager");
        try
        {
            var svc = NativeMethods.OpenService(scm, name,
                NativeMethods.SERVICE_STOP | NativeMethods.SERVICE_QUERY_STATUS);
            if (svc == IntPtr.Zero) return Fail($"OpenService({name})");
            try
            {
                var status = new NativeMethods.SERVICE_STATUS();
                bool ok = NativeMethods.ControlService(svc, 1 /*SERVICE_CONTROL_STOP*/, ref status);
                if (!ok) return Fail($"Stop({name})");
                SimpleLog.Ok($"Служба остановлена: {name}");
                return true;
            }
            finally { NativeMethods.CloseServiceHandle(svc); }
        }
        finally { NativeMethods.CloseServiceHandle(scm); }
    }

    public static bool SetStartType(string name, int startType)
    {
        var scm = NativeMethods.OpenSCManager(null, null, NativeMethods.SC_MANAGER_CONNECT);
        if (scm == IntPtr.Zero) return Fail("OpenSCManager");
        try
        {
            var svc = NativeMethods.OpenService(scm, name, NativeMethods.SERVICE_CHANGE_CONFIG);
            if (svc == IntPtr.Zero) return Fail($"OpenService({name})");
            try
            {
                bool ok = NativeMethods.ChangeServiceConfig(svc, -1, startType, -1,
                    null, null, IntPtr.Zero, null, null, null, null);
                if (!ok) return Fail($"ChangeServiceConfig({name})");
                SimpleLog.Ok($"Тип запуска изменён: {name} → {startType}");
                return true;
            }
            finally { NativeMethods.CloseServiceHandle(svc); }
        }
        finally { NativeMethods.CloseServiceHandle(scm); }
    }

    public static bool Delete(string name)
    {
        var scm = NativeMethods.OpenSCManager(null, null, NativeMethods.SC_MANAGER_CONNECT);
        if (scm == IntPtr.Zero) return Fail("OpenSCManager");
        try
        {
            var svc = NativeMethods.OpenService(scm, name, NativeMethods.DELETE);
            if (svc == IntPtr.Zero) return Fail($"OpenService({name})");
            try
            {
                bool ok = NativeMethods.DeleteService(svc);
                if (!ok) return Fail($"DeleteService({name})");
                SimpleLog.Ok($"Служба помечена к удалению: {name}");
                return true;
            }
            finally { NativeMethods.CloseServiceHandle(svc); }
        }
        finally { NativeMethods.CloseServiceHandle(scm); }
    }

    private static bool Fail(string what)
    {
        SimpleLog.Error($"{what}: {NativeMethods.GetWin32Message(Marshal.GetLastWin32Error())}" +
                        (Marshal.GetLastWin32Error() == 5 ? " (нужны права администратора)" : ""));
        return false;
    }

    // ---------- Эвристика «подозрительные службы» ----------

    /// <summary>
    /// Сильные признаки «плохой» службы. Раньше сюда попадали «Нет описания» и
    /// «Автозапуск, но не выполняется» — огромное число ложных срабатываний на
    /// совершенно нормальных службах, поэтому они убраны.
    /// </summary>
    public static List<string> EvaluateSuspicious(ServiceRow s)
    {
        var reasons = new List<string>();
        var bin = Environment.ExpandEnvironmentVariables(s.BinaryPath ?? "").Trim();
        var exe = ExtractExe(bin);
        if (string.IsNullOrEmpty(exe)) return reasons;

        var loc = Processes.SuspicionRules.ClassifyLocation(exe);
        if (loc is Processes.SuspicionRules.LocTemp or Processes.SuspicionRules.LocDownload or Processes.SuspicionRules.LocUser)
            reasons.Add("Двоичный файл в пользовательском/временном каталоге");

        if (!File.Exists(exe) && !exe.Contains('%') &&
            !bin.Contains("system32", StringComparison.OrdinalIgnoreCase) &&
            !bin.Contains("syswow64", StringComparison.OrdinalIgnoreCase))
            reasons.Add("Двоичный файл не найден на диске");

        if (s.SignatureChecked && !s.Signed && loc is not Processes.SuspicionRules.LocSystem)
            reasons.Add("Нет действительной цифровой подписи");
        return reasons;
    }

    /// <summary>Проверяет подпись службы и возвращает признак успешной проверки.</summary>
    public static bool VerifySignature(ServiceRow s)
    {
        var exe = ExtractExe(Environment.ExpandEnvironmentVariables(s.BinaryPath ?? "").Trim());
        s.SignatureChecked = true;
        s.Signed = !string.IsNullOrEmpty(exe) && File.Exists(exe) && NativeMethods.VerifyFileSignature(exe);
        return s.Signed;
    }

    public static string ExtractExe(string binaryPath)
    {
        if (string.IsNullOrWhiteSpace(binaryPath)) return "";
        var b = Environment.ExpandEnvironmentVariables(binaryPath).Trim();
        if (b.StartsWith("\\??\\")) b = b[4..];
        if (b.StartsWith('"'))
        {
            int end = b.IndexOf('"', 1);
            if (end > 0) return b[1..end];
        }
        int space = b.IndexOf(' ');
        var token = space > 0 ? b[..space] : b;
        if (token.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) || token.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
            return token;
        if (space > 0)
        {
            int space2 = b.IndexOf(' ', space + 1);
            var token2 = space2 > 0 ? b[(space + 1)..space2] : b[(space + 1)..];
            if (token2.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) return token2;
        }
        return token;
    }
}

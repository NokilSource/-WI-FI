using System.Diagnostics;
using AegisKit.Core.Logging;
using AegisKit.Core.Native;

namespace AegisKit.Core.SystemOps;

/// <summary>Системные действия: перезагрузка в диагностические режимы.</summary>
public static class BootActions
{
    private static void RunElevated(string exe, string args, bool wait = false)
    {
        try
        {
            SimpleLog.Command($"{exe} {args}");
            var psi = new ProcessStartInfo
            {
                FileName = exe,
                Arguments = args,
                UseShellExecute = true,
                Verb = "runas",
                WindowStyle = ProcessWindowStyle.Hidden
            };
            var p = Process.Start(psi)!;
            if (wait) p.WaitForExit(15000);
        }
        catch (System.ComponentModel.Win32Exception ex) when (ex.NativeErrorCode == 1223)
        {
            SimpleLog.Warn("Действие отменено пользователем (UAC)");
        }
        catch (Exception ex)
        {
            SimpleLog.Error($"{exe}: {ex.Message}");
        }
    }

    /// <summary>Включение безопасного режима при следующей загрузке (bcdedit /set safeboot).</summary>
    public static void EnableSafeMode(bool withNetwork)
    {
        RunElevated("bcdedit.exe", $"/set {{current}} safeboot {(withNetwork ? "network" : "minimal")}");
        SimpleLog.Ok($"Безопасный режим {(withNetwork ? "(с сетью) " : "")}будет активен при следующей перезагрузке. " +
                     "После диагностики нажмите «Вернуть обычную загрузку».");
    }

    public static void DisableSafeMode()
    {
        RunElevated("bcdedit.exe", "/deletevalue {current} safeboot");
        SimpleLog.Ok("Обычная загрузка восстановлена");
    }

    /// <summary>Перезагрузка в среду восстановления (WinRE).</summary>
    public static void RebootToWinre(int delaySec = 5)
    {
        NativeMethods.EnablePrivilege("SeShutdownPrivilege");
        RunElevated("shutdown.exe", $"/r /o /t {delaySec}");
        SimpleLog.Ok($"Перезагрузка в среду восстановления через {delaySec} сек.");
    }

    /// <summary>Перезагрузка в UEFI/BIOS (только для UEFI-систем).</summary>
    public static void RebootToUefi(int delaySec = 5)
    {
        NativeMethods.EnablePrivilege("SeShutdownPrivilege");
        RunElevated("shutdown.exe", $"/r /fw /t {delaySec}");
        SimpleLog.Ok($"Перезагрузка в UEFI/BIOS через {delaySec} сек. (если система загружена в UEFI-режиме)");
    }

    public static void RebootNow() => RunElevated("shutdown.exe", "/r /t 0");

    public static void ShutdownNow() => RunElevated("shutdown.exe", "/s /t 0");

    public static void OpenDiskManagement()
    {
        try
        {
            Process.Start(new ProcessStartInfo("diskmgmt.msc") { UseShellExecute = true });
            SimpleLog.Info("Открыто: Управление дисками");
        }
        catch (Exception ex) { SimpleLog.Error($"diskmgmt.msc: {ex.Message}"); }
    }

    public static void OpenTaskManager() => Process.Start(new ProcessStartInfo("taskmgr.exe") { UseShellExecute = true });

    public static void OpenMsconfig() => Process.Start(new ProcessStartInfo("msconfig.exe") { UseShellExecute = true });

    public static void OpenSystemInfo()
    {
        try { Process.Start(new ProcessStartInfo("msinfo32.exe") { UseShellExecute = true }); }
        catch (Exception ex) { SimpleLog.Error($"msinfo32: {ex.Message}"); }
    }

    public static void OpenWindowsUpdate()
    {
        try
        {
            Process.Start(new ProcessStartInfo("ms-settings:windowsupdate") { UseShellExecute = true });
        }
        catch (Exception ex) { SimpleLog.Error($"Windows Update: {ex.Message}"); }
    }

    public static void OpenDefender()
    {
        try
        {
            Process.Start(new ProcessStartInfo("windowsdefender:") { UseShellExecute = true });
        }
        catch (Exception ex) { SimpleLog.Error($"Defender: {ex.Message}"); }
    }
}

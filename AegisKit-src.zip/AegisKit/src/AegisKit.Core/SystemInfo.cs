using System.Security.Principal;

namespace AegisKit.Core;

/// <summary>Сведения о среде запуска.</summary>
public static class SystemInfo
{
    public static bool IsElevated
    {
        get
        {
            try
            {
                using var identity = WindowsIdentity.GetCurrent();
                return new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }
    }

    public static string WindowsVersion =>
        $"Windows {Environment.OSVersion.Version.Major}.{Environment.OSVersion.Version.Minor} " +
        $"(сборка {Environment.OSVersion.Version.Build}), {(Environment.Is64BitOperatingSystem ? "x64" : "x86")}";

    public static string ComputerName => Environment.MachineName;

    public static string UserName => Environment.UserName;

    /// <summary>Запущено ли окружение WinRE/WinPE (минимальный графический режим).</summary>
    public static bool IsWinRE =>
        Environment.GetEnvironmentVariable("WINPE_LAUNCHER") != null ||
        string.Equals(Environment.GetEnvironmentVariable("SYSTEMDRIVE"), "X:", StringComparison.OrdinalIgnoreCase);
}
